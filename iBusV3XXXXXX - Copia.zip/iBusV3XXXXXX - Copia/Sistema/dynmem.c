#define DYNNMEM_C

#include "Main/iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.

//#include "Main/SysUtils.h"

#include "Sistema/dynmem.h"

#define DYNMEM_TABLELEN 128

struct mmap_table
{
	unsigned short int size;
	unsigned short int pos;
};

unsigned int membuf[DYNAMIC_MEMORY_SIZE];//vetor usado para a aloca��o de mem�ria (int = blocos 4 bytes)
struct mmap_table mmap[DYNMEM_TABLELEN];//no m�ximo 64 segmentos de mem�ria alocados ao mesmo tempo

void dynmem_Init(void)
{
	unsigned char ch;
	for(ch=0;ch<DYNMEM_TABLELEN;ch++)
	{
		mmap[ch].size=0;//libera toda a mem�ria
	}
}

void* malloc(unsigned int size)
{
	unsigned char ch, i;
	unsigned int gap, pos_candidate;
	unsigned int best_gap, best_pos, tab_pos;

	//Transformo o tamanho de bytes em inteiros
	if(size==0)size++;//aloca ao menos um byte
	size = ((size -1)/4)+1;//o size eh em bytes, mas somente aloco mem�ria em words 32 bits

	pos_candidate = 0;
	tab_pos = 0;
	best_gap = DYNAMIC_MEMORY_SIZE;
	best_pos=0xFFFF;
	
	for(ch=0;ch<DYNMEM_TABLELEN;ch++)
	{
		if(mmap[ch].size!=0)
		{//mem�ria alocada?
			gap = mmap[ch].pos - pos_candidate;
		}
		else
		{
			gap = DYNAMIC_MEMORY_SIZE - pos_candidate;			
		}
		if(gap>=size)
		{
			//cabe aqui. calcular o gap
			if((gap-size)<best_gap)
			{//achei uma posi��o que essa mem�ria encaixa melhor?
				best_gap = gap - size;//salva a sobra de mem�ria detectada
				best_pos = pos_candidate;
				tab_pos = ch;
			}
			
		}
		pos_candidate = mmap[ch].pos + mmap[ch].size;
		if(mmap[ch].size==0)break;//fim da lista, ou alocou ou nao tem espa�o
	}
	
	if(	(best_pos==0xFFFF)||//n�o achou espaco para alocar
			(mmap[DYNMEM_TABLELEN-1].size!=0)//nao h� espaco suficiente na tabela de aloca��o
	){
		return NULL;
	}

	//tem que inserir a entrada ordenadamente na tabela	
	for(i=DYNMEM_TABLELEN-1;i>tab_pos;i--)
	{//come�a jogando a penultima na ultima
		mmap[i].pos = mmap[i-1].pos;
		mmap[i].size = mmap[i-1].size;		
	}
	
	mmap[tab_pos].pos = best_pos;
	mmap[tab_pos].size = size;
	
	return &membuf[best_pos];//devolve o ponteiro do local alocado
}

void free (void* ptr)
{
	unsigned char ch, i;	
	
	if(ptr==NULL)return;//desalocando o imposs�vel
	
	for(ch=0;ch<DYNMEM_TABLELEN;ch++)
	{
		if(mmap[ch].size!=0)
		{//mem�ria alocada?
			if(ptr == &membuf[mmap[ch].pos])
			{//achei a posi��o de mem�ria
				for(i=ch;i<(DYNMEM_TABLELEN-1);i++)
				{//remover a posi��o eliminada
					mmap[i].pos = mmap[i+1].pos;
					mmap[i].size = mmap[i+1].size;							
				}
				mmap[DYNMEM_TABLELEN-1].size=0;//limpa a �ltima posi��o
				break;
			}
		}
	}	
}
