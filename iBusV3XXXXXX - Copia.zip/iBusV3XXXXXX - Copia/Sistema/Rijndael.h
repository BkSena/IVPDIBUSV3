#ifndef RIJNDAEL_H
#define RIJNDAEL_H
#ifndef RIJNDAEL_C

extern void AESEncode(unsigned char* block, unsigned char *chave);
extern void AESDecode(unsigned char* block, unsigned char *chave);

extern void AES_SetKey_Enc(unsigned char *cKey);
extern void AES_SetKey_Dec(unsigned char *cKey);

#endif
#endif
