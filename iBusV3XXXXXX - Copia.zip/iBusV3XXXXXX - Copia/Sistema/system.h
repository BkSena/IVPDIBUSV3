#ifndef SYSTEM_H
#define SYSTEM_H

#ifndef SYSTEM_C

extern void system_Init(void);

extern void system_pressed(unsigned char tecla);
extern void system_release(unsigned char tecla);

extern void system_resultado(unsigned char resultado);

extern void system_macAddress(unsigned char *macbuf);//passar um buffer com no m�nimo 3 posi��es

#ifdef IBUSMANAGER_C
extern const unsigned char DEBUGKEY[16];
extern unsigned char DEBUGREC[3];

extern void system_TimeStampTick(void);//informa o sistema para avan�ar no tempo dos timestamps
extern unsigned char system_IsMyReceptor(unsigned char *rec_address);
extern unsigned char *system_GetChaveCripto(unsigned char *rec_address);
extern unsigned long system_GetTimestampSincronizado(unsigned char *receptor_add);
extern unsigned char system_ValidaTimestamp(unsigned long timestamp, unsigned char *receptor_add);

extern void system_resultado(unsigned char resultado);
#endif

#endif

#endif
