#ifndef DYNMEM_H
#define DYNMEM_H

#define DYNAMIC_MEMORY_SIZE (0x900/4)

#ifndef DYNMEM_C
extern void dynmem_Init(void);//libera toda memoria alocada

extern void* malloc(unsigned int size);
extern void free (void* ptr);
#endif

#endif
