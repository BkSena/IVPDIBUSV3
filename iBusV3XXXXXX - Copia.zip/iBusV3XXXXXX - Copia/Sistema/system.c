#define SYSTEM_C

#include "Main\iBUSv3.h"
#include "system.h"

const unsigned char DEBUGKEY[16]={0x6f, 0x1d, 0xb7, 0x30, 0xce, 0x42, 0x8d, 0xb1, 0x97, 0xe3, 0xa3, 0x76, 0xa4, 0x28, 0x81, 0xbb};
const unsigned char DEBUGREC[3]={0x08,0x4A,0x45};

unsigned long Timestamp_Sincronizado;
unsigned long Timestamp_UltimoTransmitido;

void system_Init(void)
{
	Timestamp_Sincronizado = 0;
	Timestamp_UltimoTransmitido = 0;
}

void system_pressed(unsigned char tecla)
{
}

void system_release(unsigned char tecla)
{
}

void system_resultado(unsigned char resultado)
{
}

void system_macAddress(unsigned char *macbuf)//passar um buffer com no m�nimo 3 posi��es
{
	unsigned char pos;
	//static unsigned char const MAC_ADDRESS[3]={0xC0,0x8B,0x6F};//nosso range oficial IEEE
	unsigned char ch;
	unsigned long serial=0;
	
	//for(pos=0;pos<3;pos++)macbuf[pos] = MAC_ADDRESS[pos];
	
	//O restante do MAC � definido pelo n�mero de s�rie
	for(ch=1;ch<7;ch++)
	{//Exemplo 11179955 .: 117995 .: 01CCEB
		serial*=10;
		if(ch%2)serial += ((unsigned char *)NUMSERIE)[ch/2]&0x0F;
		else serial+=((unsigned char *)NUMSERIE)[ch/2]>>4;
	}
	for(pos=0;pos<3;pos++)
	{
		macbuf[pos] = (serial>>(8*(2-pos)))&0xFF;
	}
}

void system_TimeStampTick(void)//informa o sistema para avan�ar no tempo dos timestamps
{//chamado periodicamente pelo iBUSManager para avancar com o tick do timestamp
	Timestamp_Sincronizado++;
}

unsigned char system_IsMyReceptor(unsigned char *rec_address)
{
	#ifdef SOU_RECEPTOR
	#warning "implementar"
	#else
	unsigned char aux;
	for(aux=0;aux<3;aux++)if(rec_address[aux]!=DEBUGREC[aux])return 0;
	#endif
	return 1;
}

unsigned char *system_GetChaveCripto(unsigned char *rec_address)
{
	return (unsigned char *)DEBUGKEY;
}
	
unsigned long system_GetTimestampSincronizado(unsigned char *receptor_add)
{
	unsigned long timestamp;
	
	
	//Calculando melhor TIMESTAMP
	if(Timestamp_Sincronizado>Timestamp_UltimoTransmitido)
	{
		timestamp=Timestamp_Sincronizado-Timestamp_UltimoTransmitido;
		if(timestamp>3000)
		{//virou a janela, na verdade o ultimo transmitido � maio que o timestamp
			Timestamp_UltimoTransmitido++;//se o transmitido � maior, incrementa e usa ele
		}
		else
		{//Se o ultimo transmitido � realmente menor que o sincronizado, vamos usar o sincronizado
			Timestamp_UltimoTransmitido=Timestamp_Sincronizado;
		}
	}
	else
	{
		timestamp=Timestamp_UltimoTransmitido-Timestamp_Sincronizado;
		if(timestamp>3000)
		{//virou a janela, o sincronizado � maior que o transmtidio
			Timestamp_UltimoTransmitido=Timestamp_Sincronizado;
		}
		else
		{
			Timestamp_UltimoTransmitido++;//se o transmitido � maior, incrementa e usa ele
		}
	}
	timestamp=Timestamp_UltimoTransmitido;
	
	return timestamp;
}

unsigned char system_ValidaTimestamp(unsigned long timestamp, unsigned char *receptor_add)
{
	unsigned long diferenca;

	//Calculando melhor TIMESTAMP
	if(Timestamp_Sincronizado>timestamp)
	{
		diferenca=Timestamp_Sincronizado-timestamp;
	}
	else
	{
		diferenca=timestamp-Timestamp_Sincronizado;
	}
	
	return (diferenca<3000);//retorna verdadeiro se a diferen�a for menor que +-5 minutos.
}

