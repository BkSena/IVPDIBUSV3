#ifndef PIR_H
#define PIR_H

extern void pir_Main(void);
extern void pir_Init(void);
extern void pirto_Radio(void);
extern void verificaDisparo(void);

extern unsigned char flag_RadioEnviado;

#endif /*ADC_H*/
