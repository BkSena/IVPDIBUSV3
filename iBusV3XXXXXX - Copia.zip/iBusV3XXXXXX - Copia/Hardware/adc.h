#ifndef ADC_H
#define ADC_H

#define ADCTIMEOUT 					3 // por enquanto em segundos

extern void adc_mainA(void);
extern void adc_mainB(void);
extern void adc_init(void);
extern void adctoRadio(void);
extern void verificaDisparo(void);

extern unsigned char flag_RadioEnviado;



#endif /*ADC_H*/
