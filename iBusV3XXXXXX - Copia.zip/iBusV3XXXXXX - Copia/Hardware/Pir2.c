/*---------------------------------------------------*/
//| AD | ID | NM | NADs | DATA |
//AD 	 - Identificador 												1 byte
//ID 	 - ID de quem est� mandando as medidas	1 byte
//NM 	 - N�mero de medidas para cada adc			1 byte
//NADs - N�mero de ADCs sendo medidos 				1 byte
//DATA - Leitura dos ADCs											NM*NADs bytes	
/*---------------------------------------------------*/

#ifndef PIR_C
#define PIR_C

#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.

//#include "adc.h"
#include "Pir2.h"
#include "configADC.h"

#include "Radio.h"
#include "iBUSManager.h"

#define NUM_PIR			2
#define AMOSTRAS		40								//Quantas amostras
#define PIR_BUFLEN	NUM_PIR*AMOSTRAS	 
#define LENDADO	CHANNELS              //Quando um pacote de DATA estiver pronto para ser salvo seu tamanho ser� LENDADO 

#define VALORMAX 	 	0x01
#define MEDMAX			0x02

//Estados da m�quina de controle do m�dulo
#define PMAQ_BUFERIZA					0x00
#define PMAQ_TRATA						0x10
#define PMAQ_FILTRA						0x20
#define PMAQ_VERIFICADISPARO	0x30
#define PMAQ_ENVIADADOS				0x40
#define PMAQ_ZERABUFFER				0x50

#define SENSIBILIDADE 14

unsigned char index_pir;//Salva a posi��o para novo incremento do buffer

unsigned char pir_Maquina;
unsigned char flag_RadioEnviado;
unsigned char flag_BuffMaximo;

struct PIR_VALOMEDIDO
{
	unsigned short int pirRX[PIR_BUFLEN];//Salva valores de PIR
	unsigned short int pirRxMaX[PIR_BUFLEN/2];//Vetor para armazenar medidas maximas do pirRX2
	unsigned char pirTX[4 + PIR_BUFLEN*2]; //preciso manda id e quantas conversoes realizei 2*pois mando char
	unsigned char pirDisp[PIR_BUFLEN];//Aqui � o vetor de disparos
}pir_sBuf[NUM_PIR];

struct PIR_FILTRORC
{
	unsigned short int sinalFiltrado;//contem o valor atual
	unsigned char 		cResto;//o resto do filtro
}pir_filtrorc[NUM_PIR];

struct PIR_SMAX
{
	unsigned int maxpirRX;
	unsigned int medBufMax;
}pir_sMax[NUM_PIR];

unsigned char countPct;

unsigned char adcTimeout;


/*------------------------------- Prototipo de funcoes---------------------------*/
void pir_Init(void);
void pir_main(void);
void zera_Buffer(void);
void pir_ConvertValue(void);
void pir_Timeout(void);
void pirto_Radio(void);
void trata_Vetor(void);

unsigned short int encontraValores(unsigned short int *buff, unsigned char opcao);
void ordenaVetor(unsigned short int *buff);

void terminal_Printf_E(const unsigned char *mensagem);
void DebugHex_E(unsigned char c);
/*--------------------------------- Prototipo de funcoes---------------------------*/

void pir_Init(){
	
	unsigned char aux, auxPir;
	
	pir_Maquina = PMAQ_BUFERIZA;
	
	adc_Init(AD_PIR1);//Inicia leitura PIR1
	adc_Init(AD_PIR2);//Inicia leitura PIR2
	
	flag_RadioEnviado = 1;
	flag_BuffMaximo = 0;
	
	index_pir = 0;
	countPct = 0;
	
	for(aux = 0; aux < NUM_PIR; aux++){
		pir_filtrorc[aux].sinalFiltrado=0;
		pir_filtrorc[aux].cResto=0;
		
		pir_sMax[aux].maxpirRX = 0;
		pir_sMax[aux].medBufMax = 0;
	}
	
	for(auxPir = 0; auxPir < NUM_PIR; auxPir++){//varre por pir
		
		for(aux = 0; aux < 2*PIR_BUFLEN+4; aux++){//varre por tamanho de vetor
			
			pir_sBuf[auxPir].pirTX[aux] = 0;
			
			if(aux < PIR_BUFLEN){
				pir_sBuf[auxPir].pirDisp[aux] = 0;
				pir_sBuf[auxPir].pirRX[aux] = 0;
			}
			
			if(aux < PIR_BUFLEN/2){
				pir_sBuf[auxPir].pirRxMaX[aux] = 0;
			}
		}
	}
}

void pir_Main()
{//enche o buffer com medidas
	
	unsigned char aux;
	
	switch(pir_Maquina){
		case PMAQ_BUFERIZA:
			for(aux = 0; aux < NUM_PIR; aux++){
				pir_sBuf[aux].pirRX[index_pir] = adc_GetMiliVolts((enum ADC_ENTRADAS)(AD_PIR1 + aux));
			}
			
			if(index_pir++ >= AMOSTRAS)
			{ 
				index_pir = 0;
				pir_Maquina = PMAQ_TRATA; //para de encher o buffer
			}
			break;
		
		case PMAQ_TRATA:
			trata_Vetor();
			verificaDisparo();
			break;
		
		case PMAQ_ENVIADADOS:
			pirto_Radio();
			break;
		
		case PMAQ_ZERABUFFER:
			zera_Buffer();
			break;
	}
}

void trata_Vetor(){//trata o buffer cheio
		
	unsigned char aux;
	unsigned char posMax = (AMOSTRAS/2) - 1; //quando necess�rio apagar a �ltima posicao do buffer max
	
	for(aux = 0; aux < NUM_PIR; aux++){//varre por pir
		//aqui tenho o maior valor do valor lido em 1 'seg ou (ciclo)' de PIR
		pir_sMax[aux].maxpirRX = encontraValores(pir_sBuf[aux].pirRX, VALORMAX);//nao posso ordenar o buff PIR

		//aqui come�a o primeiro fitro criando um vetor de m�xima 
		//depois a media das medidas de m�xima complementam o filtro de deteccao
		if(flag_BuffMaximo)
		{//j� encheu o buffer de maximos agora apago apenas uma por vez
			pir_sMax[aux].medBufMax = encontraValores(pir_sBuf[aux].pirRxMaX, MEDMAX);//nao posso ordenar o buff PIR
			
			if (pir_sMax[aux].maxpirRX < pir_sBuf[aux].pirRxMaX[posMax])
			{//para elminar a medidas maximas dentro do buffer
				pir_sBuf[aux].pirRxMaX[posMax] = pir_sMax[aux].maxpirRX; //quarda maximo na pos final
				ordenaVetor(pir_sBuf[aux].pirRxMaX);
			}
			else if ((pir_sMax[aux].maxpirRX < pir_sMax[aux].medBufMax * (SENSIBILIDADE)))
			{//para elminar a medidas minimas dentro do buffer
				pir_sBuf[aux].pirRxMaX[0] = pir_sMax[aux].maxpirRX; //quarda media na pos 0
				ordenaVetor(pir_sBuf[aux].pirRxMaX);
			}
		}
		else if(pir_sMax[aux].maxpirRX != 0)
		{//primeiro encho o buffer de max para criar o filtro
			pir_sBuf[aux].pirRxMaX[countPct] = pir_sMax[aux].maxpirRX;
			if(aux >= AD_PIR2)countPct++;//s� pode aumentar depois do for pois estamos preenchendo os dois PIR
			
			if(countPct >= AMOSTRAS/2)
			{ 
				ordenaVetor(pir_sBuf[aux].pirRxMaX);
				flag_BuffMaximo = 1;
			}
		}
	}
}

void verificaDisparo() {
	
	unsigned char aux, auxPir;
	unsigned int filtro;
	unsigned char constante = 5;
	
	if (pir_sMax[auxPir].medBufMax != 0)
	{//s� entro aqui se o buffer de maximos estiver cheio
		for(auxPir = 0; auxPir < NUM_PIR; auxPir++){//varre por pir
			
			unsigned int filtroBorda = (pir_sMax[auxPir].medBufMax * SENSIBILIDADE)/10;
			
			for (aux = 0; aux < AMOSTRAS; aux++) //Filtro RC simples
			{//primeiro vamos filtrar o sinal do PIR e depois fazer decisoes sobre disparo
				filtro = (pir_sBuf[auxPir].pirRX[aux] + (constante * pir_filtrorc[auxPir].sinalFiltrado) + pir_filtrorc[auxPir].cResto);
				pir_filtrorc[auxPir].cResto = filtro % (constante + 1);
				pir_filtrorc[auxPir].sinalFiltrado = (filtro / (constante + 1));
				
				if (pir_filtrorc[auxPir].sinalFiltrado > filtroBorda)
				{
					pir_sBuf[auxPir].pirDisp[aux] = 1;
				}
				else
				{
					pir_sBuf[auxPir].pirDisp[aux] = 0;
				}
			} //Aqui temos um pre filtro, porem ainda nao esta bom.
			//ent�o vamos passar por mais uma analise, so � disparo se tiver pelo menos 2 disparos seguidos 
			
			unsigned char posInicial = 0;
			unsigned char posFinal = 0;

			for (aux = 0; aux < AMOSTRAS; aux++)
			{//vamos ver quantos disparos foram detetados e tomar decisoes
				if (pir_sBuf[auxPir].pirDisp[aux] != 0)
				{
					posInicial = aux;
					while((pir_sBuf[auxPir].pirDisp[aux] != 0) && (aux < (AMOSTRAS - 1))){
						aux++;
					}
					posFinal = aux;
					
					if((posFinal - posInicial) < 4){//4disparos para ser disparo real
						while(posInicial < posFinal)
							pir_sBuf[auxPir].pirDisp[posInicial++] = 0;
					}
				}
			}//end for
		}//end for por pir
		pir_Maquina = PMAQ_ENVIADADOS;
	}//end if condicao de entrada
}

void pirto_Radio(){
			
	unsigned char aux, pos;
	unsigned char lenDados; //aqui vamos os dados referente as leituras que temos
	
	pos = 4; //Default do pirTX
	lenDados = PIR_BUFLEN*2+pos; //*2 pois o buffer esta em int e o envio sera em char
	
	pir_sBuf[AD_PIR1].pirTX[0] = 0xAD;//identificador de pacote
	pir_sBuf[AD_PIR1].pirTX[1] = 0x07; //ID POR HORA DEIXA ASSIM
	pir_sBuf[AD_PIR1].pirTX[2] = AMOSTRAS-1; //Quantas leituras de PIR foram feitas
	pir_sBuf[AD_PIR1].pirTX[3] = NUM_PIR;//Quantos PIRs estou enviando

	for(aux = 0; aux<PIR_BUFLEN-1; aux++)
	{
		pir_sBuf[AD_PIR1].pirTX[pos + aux*2] = pir_sBuf[AD_PIR1].pirRX[aux+1] >> 8 & 0xFF;
		pir_sBuf[AD_PIR1].pirTX[pos + aux*2 + 1] =  pir_sBuf[AD_PIR1].pirRX[aux+1] & 0xFF;		
	}
	for(aux=0; aux<lenDados-2; aux++) DebugHex_E(pir_sBuf[AD_PIR1].pirTX[aux]);
	terminal_Printf_E("\r\n");
	//iBUSManager_EnviaDado(pirTX, lenDados); //precido do ID e quantidade de convers�es de adc realizada
	pir_Maquina = PMAQ_ZERABUFFER;//zera quem tem que zerar
}

void zera_Buffer()
{//
	unsigned int aux;
	//index = 0;

	for(aux=0; aux < PIR_BUFLEN; aux++){
		pir_sBuf[AD_PIR1].pirRX[aux] = 0;
		pir_sBuf[AD_PIR1].pirDisp[aux] = 0;
	}
	flag_RadioEnviado = 0;//aqui eu paro as medidas at� que o radio mande informa��o
	pir_Maquina = PMAQ_BUFERIZA;
}
//
void ordenaVetor(unsigned short int *buff)
{//metodo de insercao, como o vetor e relativamente pequeno
 //nao precisa de um metedo mais sofisticado como quick

	unsigned char i;
	int j;//para poder comparar (j >= 0)
	short int atual;

	for (i = 1; i < AMOSTRAS/2; i++) {
		
		atual = buff[i];
	
		for (j = i - 1; (j >= 0) && (atual < buff[j]); j--) {
			buff[j + 1] = buff[j];
    }
		
		buff[j + 1] = atual;		
	}
}
//
unsigned short int encontraValores(unsigned short int *buff, unsigned char opcao){

	unsigned char aux;
	unsigned short int value;

	value = 0;
	
	if(opcao&VALORMAX)
	{//pega valor maximo
		for(aux = 0; aux < AMOSTRAS; aux++)
			if(buff[aux] > value)
				value = buff[aux];
	}
	else
	{//retorna media
		for(aux = 0; aux < AMOSTRAS/2; aux++){
			value+= buff[aux];
		}
		value = value/(AMOSTRAS/2);
	}
	return value;
}
//
#endif //PIR_C

