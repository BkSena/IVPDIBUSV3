#ifndef LED_C
#define LED_C

#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.
#include "../Radio/Radio.h"
#include "adc.h"
#include "../Configuracao/configADC.h"
#include "iBUSv3/iBUSManager.h"

/*---------------------------------------------------*/
//| AD | ID | NM | NADs | DATA |
//AD 	 - Identificador 												1 byte
//ID 	 - ID de quem est� mandando as medidas	1 byte
//NM 	 - N�mero de medidas para cada adc			1 byte
//NADs - N�mero de ADCs sendo medidos 				1 byte
//DATA - Leitura dos ADCs											NM*NADs bytes	
/*---------------------------------------------------*/
#define AMOSTRAS		40								//Quantas amostras
#define ADC_BUFLEN	CHANNELS*AMOSTRAS	 
//Quando um pacote de DATA estiver pronto para ser salvo seu tamanho ser� LENDADO 
#define LENDADO	CHANNELS

#define VALORMAX 	 	0x01
#define MEDMAX			0x02
#define INDMAX  		0x04
#define INDMIN  		0x08

#define SENSIBILIDADE 14




unsigned short int bufADC[ADC_BUFLEN];//Salva valores de ADC
unsigned short int bufADCmaX[ADC_BUFLEN/2];//Vetor para armazenar medidas maximas do bufADC
unsigned char sendADC[4 + ADC_BUFLEN*2]; //preciso manda id e quantas conversoes realizei 2*pois mando char
unsigned char bufADCDisparos[ADC_BUFLEN];//Aqui � o vetor de disparos

unsigned char index_adc;//Salva a posi��o para novo incremento do buffer

unsigned char flag_RadioEnviado;
unsigned char flag_BuffMaximo;

unsigned char resto;
unsigned int sinalFiltrado;

unsigned char countPct;
unsigned int mediaMax;

unsigned char adcTimeout;

void adc_init(void);
void adc_mainA(void);
void adc_mainB(void);
void adc_ConvertValue(void);
void adc_Timeout(void);
void adctoRadio(void);

unsigned short int encontraValores(unsigned short int *buff, unsigned char opcao);
void ordenaVetor(unsigned short int *buff);

void adc_init(){
	
	unsigned char aux;
	
	flag_RadioEnviado = 1;
	flag_BuffMaximo = 0;
	
	index_adc = 0;
	countPct = 0;
	mediaMax = 0;
	
	resto = 0;
	sinalFiltrado = 0;
		
	for(aux = 0; aux < 2*ADC_BUFLEN+4; aux++){
		
		sendADC[aux] = 0;
		
		if(aux < ADC_BUFLEN){
			bufADCDisparos[aux] = 0;
			bufADC[aux] = 0;
		}
		
		if(aux < ADC_BUFLEN/2){
			bufADCmaX[aux] = 0;
		}
	}
}

void adc_mainA()
{//chamo a cada 25ms para salvar max e min
	adc_Start();
	if (adcConvOK){//J� li todos os canais?
		adcConvOK = 0;//Vou aguardar ler novamente todos os canais
		adc_ConvertValue();
		adc_Start();
	}	
}

void adc_ConvertValue()
{//chama a cada x ms
	unsigned char aux;
	for(aux = 0; aux < CHANNELS; aux++)
	{//vamos colocar  valores para cada adc nesse buffer
		bufADC[index_adc++] = (adcMed[aux]);
	}
	if(index_adc >= AMOSTRAS)
	{ 
		index_adc = 0;
		verificaDisparo();
	}	
}

void verificaDisparo(){

	unsigned int maxBufferADC;
	unsigned int mediaBufferMax;
	unsigned char constante = 5;
	unsigned char aux;
	
	unsigned char posMax = (AMOSTRAS/2) - 1;
	
	mediaBufferMax = 0;
	
	//aqui tenho o maior valor do valor lido em 1 'seg ou (ciclo)' de ADC
	maxBufferADC = encontraValores(bufADC, VALORMAX);//nao posso ordenar o buff ADC
	
	//aqui come�a o primeiro fitro criando um vetor de m�xima 
	//depois a media dos m�ximo complementa nosso filtro de deteccao
	if(flag_BuffMaximo)
	{//j� encheu o buffer de maximos agora apago apenas uma por vez
		mediaBufferMax = encontraValores(bufADCmaX, MEDMAX);//pego o valor medio do buffer de maximos
		
		if (maxBufferADC < bufADCmaX[posMax])
		{//para elminar a medidas maximas dentro do buffer
			bufADCmaX[posMax] = maxBufferADC;
			ordenaVetor(bufADCmaX);
		}
		else if ((maxBufferADC < mediaBufferMax * (SENSIBILIDADE)))
		{//para elminar a medidas minimas dentro do buffer
			bufADCmaX[0] = maxBufferADC;
			ordenaVetor(bufADCmaX);
		}
	}
	else if(maxBufferADC != 0)
	{//primeiro encho o buffer de max para criar o filtro
		bufADCmaX[countPct++] = maxBufferADC;
		
		if(countPct >= AMOSTRAS/2)
		{ 
			ordenaVetor(bufADCmaX);
			flag_BuffMaximo = 1;
		}
	}
	
	if (mediaBufferMax != 0)
	{//s� entro aqui se o buffer de maximos estiver cheio
		unsigned int filtro;
		unsigned int filtroBorda = (mediaBufferMax * SENSIBILIDADE)/10;
		
		for (aux = 0; aux < AMOSTRAS; aux++) //Filtro RC simples
		{//primeiro vamos filtrar o sinal do ADC e depois fazer decisoes sobre disparo
			filtro = (bufADC[aux] + (constante * sinalFiltrado) + resto);
			resto = filtro % (constante + 1);
			sinalFiltrado = (filtro / (constante + 1));
			
			if (sinalFiltrado > filtroBorda)
			{
				bufADCDisparos[aux] = 1;
			}
			else
			{
				bufADCDisparos[aux] = 0;
			}
		} //Aqui temos um pre filtro, porem ainda nao esta bom.
		//ent�o vamos passar por mais uma analise, so � disparo se tiver pelo menos 2 disparos seguidos 
		
		//unsigned char disparosSeq = 0;
		unsigned char posInicial = 0;
		unsigned char posFinal = 0;

		for (aux = 0; aux < AMOSTRAS; aux++)
		{//vamos ver quantos disparos foram detetados e tomar decisoes
			if (bufADCDisparos[aux] != 0)
			{
				posInicial = aux;
				while((bufADCDisparos[aux] != 0) && (aux < (AMOSTRAS - 1))){
					aux++;
				}
				posFinal = aux;
				
				if((posFinal - posInicial) < 4){
					while(posInicial < posFinal)
						bufADCDisparos[posInicial++] = 0;
				}
			}
			//disparosSeq = 0;
		}//end for
		
		adctoRadio();
	}//end if
}




/*

while (bufADCDisparos[aux] != 0 )
{
	if (aux < AMOSTRAS - 1) {
		aux++;
		disparosSeq++;
	}
	else break;
}
if (disparosSeq > 3)
{
	aux += disparosSeq - 1;
}
else bufADCDisparos[aux] = 0;
*/



void ordenaVetor(unsigned short int *buff)
{//metodo de insercao, como o vetor e relativamente pequeno
 //nao precisa de um metedo mais sofisticado como quick

	unsigned char i;
	int j;//para poder comparar (j >= 0)
	short int atual;

	for (i = 1; i < AMOSTRAS/2; i++) {
		
		atual = buff[i];
	
		for (j = i - 1; (j >= 0) && (atual < buff[j]); j--) {
			buff[j + 1] = buff[j];
    }
		buff[j + 1] = atual;
				
	}
}

unsigned short int encontraValores(unsigned short int *buff, unsigned char opcao){

	unsigned char aux;
	unsigned short int value;

	value = 0;
	
	if(opcao&VALORMAX)
	{//pega valor maximo
		for(aux = 0; aux < AMOSTRAS; aux++)
		{
			if(buff[aux] > value){ 
				value = buff[aux];
			}
		}
		return value;
	}
	else
	{
		for(aux = 0; aux < AMOSTRAS/2; aux++){
			value+= buff[aux];
		}
		value = value/(AMOSTRAS/2);

		return value;
	}

}

void adctoRadio(){
			
	unsigned char aux, pos;
	unsigned char lenDados; //aqui vamos os dados referente as leituras que temos
	
	pos = 4; //Default do sendADC
	lenDados = ADC_BUFLEN*2+pos; //*2 pois o buffer esta em int e o envio sera em char
	
	sendADC[0] = 0xAD;//identificador de pacote
	sendADC[1] = 0x07; //ID POR HORA DEIXA ASSIM
	sendADC[2] = AMOSTRAS-1; //Quantas leituras de ADC foram feitas
	sendADC[3] = CHANNELS;//Quantos ADCs estou enviando

	for(aux = 0; aux<ADC_BUFLEN-1; aux++)
	{	//bufADC
		//sendADC[pos + aux*2] = bufADCDisparos[aux] >> 8 & 0xFF;
		//sendADC[pos + aux*2 + 1] =  bufADCDisparos[aux] & 0xFF;
		
		sendADC[pos + aux*2] = bufADC[aux+1] >> 8 & 0xFF;
		sendADC[pos + aux*2 + 1] =  bufADC[aux+1] & 0xFF;
		
//		sendADC[pos + aux*2] = (unsigned int)(*VREFINT_CAL_ADDR) >> 8 & 0xFF;
//		sendADC[pos + aux*2 + 1] =  (unsigned int)(*VREFINT_CAL_ADDR) & 0xFF;
		
	}
	for(aux=0; aux<lenDados-2; aux++) DebugHex_E(sendADC[aux]);
	terminal_Printf_E("\r\n");
	//iBUSManager_EnviaDado(sendADC, lenDados); //precido do ID e quantidade de convers�es de adc realizada
	adc_mainB();//zera quem tem que zerar
}

void adc_mainB()
{//
	unsigned int aux;
	//index = 0;
	for(aux = 0; aux<CHANNELS; aux++){
			adcMin[aux] = 0xFFFF;
			adcMax[aux] = 0;
			adcMed[aux] = 0;
	}
	for(aux=0; aux < ADC_BUFLEN; aux++){
	
		bufADC[aux] = 0;
		bufADCDisparos[aux] = 0;
	}
	flag_RadioEnviado = 0;//aqui eu paro as medidas at� que o radio mande informa��o
}


void adc_Timeout(void){
	
	if(adcTimeout > ADCTIMEOUT){ 
		adc_Reset(); 
	}
}
#endif //ADC_C
