#ifndef HAL_SPI_H

#define HAL_SPI_H

#include <stdint.h>
#include "regmap.h"
#include "HAL_GPIO.h"

typedef enum {
	RADIO 			 = 1U,
	SERIAL_FLASH = 2U,
	ETHERNET 		 = 4U
}DEVICE_SPI;

extern void HAL_SPI_Init(DEVICE_SPI dev);
extern void HAL_SPI_CSLow(DEVICE_SPI dev);
extern void HAL_SPI_CSHigh(DEVICE_SPI dev);
extern void HAL_SPI_TransmitReceive(uint8_t *pTxData, uint8_t *pRxData, uint16_t Size, uint32_t Timeout);

#endif

