#ifndef HAL_SPI_H

#define HAL_SPI_H

#include <stdint.h>

enum DEVICE_SPI{
	RADIO,
	SERIAL_FLASH,
	ETHERNET
};

extern void HAL_SPI_Init(enum DEVICE_SPI dev);
extern void HAL_SPI_CSLow(enum DEVICE_SPI dev);
extern void HAL_SPI_CSHigh(enum DEVICE_SPI dev);
extern void HAL_SPI_TransmitReceive(uint8_t *pTxData, uint8_t *pRxData, uint16_t Size, uint32_t Timeout);

#endif

