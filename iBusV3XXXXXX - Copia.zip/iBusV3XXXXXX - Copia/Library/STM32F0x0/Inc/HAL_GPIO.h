#ifndef HAL_GPIO_H

#define HAL_GPIO_H

#include <stdint.h>
#include "regmap.h"

/** 
  * @brief   GPIO Init structure definition  
  */
typedef struct
{
  uint32_t Pin;       /*!< Specifies the GPIO pins to be configured.
                           This parameter can be any value of @ref GPIO_pins */

  uint32_t Mode;      /*!< Specifies the operating mode for the selected pins.
                           This parameter can be a value of @ref GPIO_mode */
	
	uint32_t Otyper;      /*!< Specifies the push-pull or open-drain for the selected pins.
                           This parameter can be a value of @ref GPIO_Otyper */

  uint32_t Pull;      /*!< Specifies the Pull-up or Pull-Down activation for the selected pins.
                           This parameter can be a value of @ref GPIO_pull */

  uint32_t Speed;     /*!< Specifies the speed for the selected pins.
                           This parameter can be a value of @ref GPIO_speed */

  uint32_t Alternate;  /*!< Peripheral to be connected to the selected pins 
                            This parameter can be a value of @ref GPIOEx_Alternate_function_selection */
}GPIO_InitTypeDef;

typedef struct
{
  uint16_t Pin; 								/*!< Specifies the GPIO pins to be configured.
																			This parameter can be any value of @ref GPIO_pins */
  GPIO_TypeDef *Port;								/*!< Specifies the GPIO ports to be configured.
																		This parameter can be any value of @ref GPIO_port */
}defPIN_InitTypeDef;

typedef enum
{
  GPIO_PIN_RESET = 0,
  GPIO_PIN_SET = 1,
	GPIO_PIN_TOGGLE = 2
}GPIO_PinState;

#define MODE_GPIO_IN  	0   /*!< Work as GPIO input */
#define MODE_EXTI_IN		1   /*!< Work as EXTI */
#define MODE_GPIO_OUT		2   /*!< Work as GPIO output */		

/** @defgroup GPIO_pins GPIO pins
  * @{
  */
//#define GPIO_PIN_0                 ((uint16_t)0x0001U)  /* Pin 0 selected    */
//#define GPIO_PIN_1                 ((uint16_t)0x0002U)  /* Pin 1 selected    */
//#define GPIO_PIN_2                 ((uint16_t)0x0004U)  /* Pin 2 selected    */
//#define GPIO_PIN_3                 ((uint16_t)0x0008U)  /* Pin 3 selected    */
//#define GPIO_PIN_4                 ((uint16_t)0x0010U)  /* Pin 4 selected    */
//#define GPIO_PIN_5                 ((uint16_t)0x0020U)  /* Pin 5 selected    */
//#define GPIO_PIN_6                 ((uint16_t)0x0040U)  /* Pin 6 selected    */
//#define GPIO_PIN_7                 ((uint16_t)0x0080U)  /* Pin 7 selected    */
//#define GPIO_PIN_8                 ((uint16_t)0x0100U)  /* Pin 8 selected    */
//#define GPIO_PIN_9                 ((uint16_t)0x0200U)  /* Pin 9 selected    */
//#define GPIO_PIN_10                ((uint16_t)0x0400U)  /* Pin 10 selected   */
//#define GPIO_PIN_11                ((uint16_t)0x0800U)  /* Pin 11 selected   */
//#define GPIO_PIN_12                ((uint16_t)0x1000U)  /* Pin 12 selected   */
//#define GPIO_PIN_13                ((uint16_t)0x2000U)  /* Pin 13 selected   */
//#define GPIO_PIN_14                ((uint16_t)0x4000U)  /* Pin 14 selected   */
//#define GPIO_PIN_15                ((uint16_t)0x8000U)  /* Pin 15 selected   */
//#define GPIO_PIN_All               ((uint16_t)0xFFFFU)  /* All pins selected */

/** @defgroup GPIO_pins GPIO deslocamento
  * @{
  */
#define GPIO_PIN_0                 (0U)  /* Pin 0 selected    */
#define GPIO_PIN_1                 (2U)  /* Pin 1 selected    */
#define GPIO_PIN_2                 (4U)  /* Pin 2 selected    */
#define GPIO_PIN_3                 (6U)  /* Pin 3 selected    */
#define GPIO_PIN_4                 (8U)  /* Pin 4 selected    */
#define GPIO_PIN_5                 (10U)  /* Pin 5 selected    */
#define GPIO_PIN_6                 (12U)  /* Pin 6 selected    */
#define GPIO_PIN_7                 (14U)  /* Pin 7 selected    */
#define GPIO_PIN_8                 (16U)  /* Pin 8 selected    */
#define GPIO_PIN_9                 (18U)  /* Pin 9 selected    */
#define GPIO_PIN_10                (20U)  /* Pin 10 selected   */
#define GPIO_PIN_11                (22U)  /* Pin 11 selected   */
#define GPIO_PIN_12                (24U)  /* Pin 12 selected   */
#define GPIO_PIN_13                (26U)  /* Pin 13 selected   */
#define GPIO_PIN_14                (28U)  /* Pin 14 selected   */
#define GPIO_PIN_15                (30U)  /* Pin 15 selected   */
#define GPIO_PIN_All               ((uint16_t)0xFFFFU)  /* All pins selected */

/** @defgroup GPIO_mode GPIO mode
  * @brief GPIO Configuration Mode 
  *        Elements values convention: 0xX0yz00YZ
  *           - X  : GPIO mode or EXTI Mode
  *           - y  : External IT or Event trigger detection 
  *           - z  : IO configuration on External IT or Event
  *           - Y  : Output type (Push Pull or Open Drain)
  *           - Z  : IO Direction mode (Input, Output, Alternate or Analog)
  * @{
  */ 
#define  GPIO_MODE_INPUT                        (0x00000000U)   /*!< Input Floating Mode                   */
#define  GPIO_MODE_OUTPUT                       (0x00000001U)   /*!< Output Push Pull Mode                 */
#define  GPIO_MODE_AF                           (0x00000002U)   /*!< Alternate Function Push Pull Mode     */
#define  GPIO_MODE_ANALOG                       (0x00000003U)   /*!< Analog Mode  */  

#define  GPIO_MODE_OUTPUT_PP                    (0x00000001U)   /*!< Output Push Pull Mode                 */
#define  GPIO_MODE_OUTPUT_OD                    (0x00000011U)   /*!< Output Open Drain Mode                */
#define  GPIO_MODE_AF_PP                        (0x00000002U)   /*!< Alternate Function Push Pull Mode     */
#define  GPIO_MODE_AF_OD                        (0x00000012U)   /*!< Alternate Function Open Drain Mode    */ 
#define  GPIO_MODE_IT_RISING                    (0x10110000U)   /*!< External Interrupt Mode with Rising edge trigger detection          */
#define  GPIO_MODE_IT_FALLING                   (0x10210000U)   /*!< External Interrupt Mode with Falling edge trigger detection         */
#define  GPIO_MODE_IT_RISING_FALLING            (0x10310000U)   /*!< External Interrupt Mode with Rising/Falling edge trigger detection  */
#define  GPIO_MODE_EVT_RISING                   (0x10120000U)   /*!< External Event Mode with Rising edge trigger detection               */
#define  GPIO_MODE_EVT_FALLING                  (0x10220000U)   /*!< External Event Mode with Falling edge trigger detection              */
#define  GPIO_MODE_EVT_RISING_FALLING           (0x10320000U)   /*!< External Event Mode with Rising/Falling edge trigger detection       */
/**
  * @}
  */
	
/** @defgroup GPIO_Private_Defines GPIO Private Defines
  * @{
  */
#define GPIO_MODE             (0x00000003U)
#define EXTI_MODE             (0x10000000U)
#define GPIO_MODE_IT          (0x00010000U)
#define GPIO_MODE_EVT         (0x00020000U)
#define RISING_EDGE           (0x00100000U)
#define FALLING_EDGE          (0x00200000U)
#define GPIO_OUTPUT_TYPE      (0x00000010U)
/**
  * @}
  */
	
/**@defgroup GPIO alternate function register
	*
	*/
#define GPIO_AF0     ((uint8_t)0x0U) 		/* AF 0 EVENTOUT, TIM15, SPI1, MCO, TIM17, SWDIO, SWCLK, TIM14, USART1, IR_OUT, SPI2, USART4   */ 
#define GPIO_AF1     ((uint8_t)0x1U) 		/* AF 1 USART2, TIM3, USART1, IR_OUT, EVENTOUT, I2C1, I2C2, TIM15   */
#define GPIO_AF2     ((uint8_t)0x2U) 		/* AF 2 TIM1, EVENTOUT, TIM16, TIM17, TIM1, USB */ 
#define GPIO_AF3     ((uint8_t)0x3U) 		/* AF 3 EVENTOUT, I2C1, TIM15 */
#define GPIO_AF4     ((uint8_t)0x4U) 		/* AF 4 USART4, TIM14, USART3, I2C1, TIM15*/
#define GPIO_AF5     ((uint8_t)0x5U) 		/* AF 5 TIM 15 / 16 / 17, SPI2, I2C2*/
#define GPIO_AF6     ((uint8_t)0x6U) 		/* AF 6 EVENTOUT */  
#define GPIO_AF7     ((uint8_t)0x7U) 		/* AF 7 */
/**
  * @}
  */	
     
/** 
	* @defgroup GPIO port output type register (GPIOx_OTYPER) (x = A..D, F)
	*@{
	*/
#define  GPIO_OTYPER_PP      (0x00000000U)  /*!< Output push-pull */
#define  GPIO_OTYPER_OD			 (0x00000001U)  /*!< Output open-drain */

/**
  * @}
  */

/** @defgroup GPIO_speed GPIO speed
  * @brief GPIO Output Maximum frequency
  * @{
  */  
#define  GPIO_SPEED_FREQ_LOW      (0x00000000U)  /*!< range up to 2 MHz, please refer to the product datasheet */
#define  GPIO_SPEED_FREQ_MEDIUM   (0x00000001U)  /*!< range  4 MHz to 10 MHz, please refer to the product datasheet */
#define  GPIO_SPEED_FREQ_HIGH     (0x00000003U)  /*!< range 10 MHz to 50 MHz, please refer to the product datasheet */
/**
  * @}
  */

 /** @defgroup GPIO_pull GPIO pull
   * @brief GPIO Pull-Up or Pull-Down Activation
   * @{
   */  
#define  GPIO_NOPULL        (0x00000000U)   /*!< No Pull-up or Pull-down activation  */
#define  GPIO_PULLUP        (0x00000001U)   /*!< Pull-up activation                  */
#define  GPIO_PULLDOWN      (0x00000002U)   /*!< Pull-down activation                */
/**
  * @}
  */

extern void HAL_GPIO_Init(GPIO_TypeDef  *GPIOx, GPIO_InitTypeDef *GPIO_Init);
extern void HAL_GPIO_WritePin(uint16_t Pin, GPIO_TypeDef* GPIO_Port, GPIO_PinState PinState);
extern uint8_t HAL_GPIO_GetLevel(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);

#endif

