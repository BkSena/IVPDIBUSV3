#ifndef HAL_SPI_C
#define HAL_SPI_C

#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.
#include "SysUtils.h"

#include "HAL_SPI.h"

unsigned char maskSPI = 0;
	
uint8_t SPI1_send(uint8_t data);

void HAL_SPI_Init(DEVICE_SPI dev){
	if(dev == RADIO){ //configura enable para r�dio
		maskSPI|= RADIO;
	} 
}
void HAL_SPI_CSLow(DEVICE_SPI dev){
	if((maskSPI & RADIO) == RADIO)		HAL_GPIO_WritePin(RD_CS, GPIOF, GPIO_PIN_SET); /*todos os existentes em High*/
	if(dev == RADIO)									HAL_GPIO_WritePin(RD_CS, GPIOF, GPIO_PIN_RESET); //RDCS
}
	
void HAL_SPI_CSHigh(DEVICE_SPI dev){
	HAL_GPIO_WritePin(RD_CS, GPIOF, GPIO_PIN_SET);//RDCS										
}
	
void HAL_SPI_TransmitReceive(uint8_t *pTxData, uint8_t *pRxData, uint16_t Size, uint32_t Timeout){
	
	unsigned int aux, time;
	unsigned char dataPrint;
	
	for(aux = 0; aux < Size; aux++){
		dataPrint = SPI1_send(pTxData[aux]);
		pRxData[aux] = dataPrint;
	}
	for(time = 0; time < 0x3F; time++){}
}

uint8_t SPI1_send(uint8_t data){
	
	unsigned int aux;
	unsigned char dataRx = 0;

	for(aux = 0; aux < 0xFFF; aux++) if((SPI1->SR & SPI_SR_TXE) == SPI_SR_TXE)break;//fica em loop ateh o buffer de transmiss�o ficar vazio
	*(uint8_t *)&(SPI1->DR) = data; // write data to be transmitted to the SPI data register
	for(aux = 0; aux < 0xFFF; aux++) if((SPI1->SR & SPI_SR_BSY) != SPI_SR_BSY)break; // wait until SPI is not busy anymore
	for(aux = 0; aux < 0xFFF; aux++) if((SPI1->SR & SPI_SR_RXNE) == SPI_SR_RXNE)break;//fica em loop ateh o buffer de recep��o receber o byte
	dataRx = (uint8_t)SPI1->DR; 
	return dataRx;	

}
#endif
