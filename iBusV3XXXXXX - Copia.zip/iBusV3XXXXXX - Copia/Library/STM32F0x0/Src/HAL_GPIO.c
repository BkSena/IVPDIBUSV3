#ifndef HAL_GPIO_C
#define HAL_GPIO_C

#include "Main/iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.
#include "Main/SysUtils.h"

#include "HAL_GPIO.h"

void HAL_GPIO_WritePin(uint16_t Pin, GPIO_TypeDef* GPIO_Port, GPIO_PinState PinState);


void HAL_GPIO_Init(GPIO_TypeDef *GPIOx, GPIO_InitTypeDef *GPIO_Init){
		
	uint8_t position = 0U;
  uint32_t temp;
	uint16_t GPIO_PinAUX; 
	
	GPIO_PinAUX = GPIO_Init->Pin / 2; /*Mascara para funcao alternada e exti*/
	
	/*--------------------- GPIO Mode Configuration ------------------------*/
  
	/* para setar modo alternativo  */
	if(GPIO_PinAUX > 7U){
		position = 1U;	 /*AFH ou AFL AF[0] ou AF[1]*/
	}
	/* Configurando modo alternativo  */
	if(GPIO_Init->Mode == GPIO_MODE_AF) 
	{
		temp = GPIOx->AFR[position];
		CLEAR_BIT(temp, 0x0FU << (((uint32_t)GPIO_PinAUX & 0x07U) * 4U));      
    SET_BIT(temp, (GPIO_Init->Alternate) << (((uint32_t)GPIO_PinAUX & 0x07U) * 4U)); 
		GPIOx->AFR[position] = temp;
	}
	
	/* Configure IO Direction mode (Input, Output, Alternate or Analog) */
	temp = GPIOx->MODER;
	CLEAR_BIT(temp, 0x3U << (GPIO_Init->Pin));      
  SET_BIT(temp, (GPIO_Init->Mode & GPIO_MODE) << (GPIO_Init->Pin)); 
	GPIOx->MODER = temp;
		
	/* In case of Output or Alternate function mode selection */
	if((GPIO_Init->Mode == GPIO_MODE_OUTPUT) || (GPIO_Init->Mode == GPIO_MODE_AF)){
		
		/* Configure the IO Output Type */
		temp = GPIOx->OTYPER;
		CLEAR_BIT(temp, 0x1U << (GPIO_Init->Pin / 2U));      
    SET_BIT(temp, (GPIO_Init->Otyper) << (GPIO_Init->Pin / 2U)); 
		GPIOx->OTYPER = temp;
		
		/* Configure the IO Speed */
		temp = GPIOx->OSPEEDR;
		CLEAR_BIT(temp, 0x3U << (GPIO_Init->Pin));      
    SET_BIT(temp, (GPIO_Init->Speed) << (GPIO_Init->Pin)); 
		GPIOx->OTYPER = temp;
	}	
	/* Activate the Pull-up or Pull down resistor for the current IO */
  temp = GPIOx->PUPDR;
  CLEAR_BIT(temp, 0x3U << (GPIO_Init->Pin));
  SET_BIT(temp, (GPIO_Init->Pull) << (GPIO_Init->Pin));
  GPIOx->PUPDR = temp;
		
	if((GPIO_Init->Mode & EXTI_MODE) == EXTI_MODE) 
  {
		temp = SYSCFG->EXTICR[GPIO_PinAUX >> 2];
		CLEAR_BIT(temp, (0x0FU) << (4U * (GPIO_PinAUX & 0x03U)));
		SET_BIT(temp, (GPIO_GET_INDEX(GPIOx)) << (4U * (GPIO_PinAUX & 0x03U)));
		SYSCFG->EXTICR[GPIO_PinAUX >> 2] = temp;
		
		/* Clear EXTI line configuration */
    temp = EXTI->IMR;
		CLEAR_BIT(temp, 1U << (uint32_t)GPIO_PinAUX);
		if((GPIO_Init->Mode & GPIO_MODE_IT) == GPIO_MODE_IT)
		{
			SET_BIT(temp, 1U << (uint32_t)GPIO_PinAUX); 
    }
    EXTI->IMR = temp;
		
		temp = EXTI->EMR;
    CLEAR_BIT(temp, 1U << (uint32_t)GPIO_PinAUX);      
    if((GPIO_Init->Mode & GPIO_MODE_EVT) == GPIO_MODE_EVT)
    { 
			SET_BIT(temp, 1U << (uint32_t)GPIO_PinAUX); 
    }
    EXTI->EMR = temp;
		
		/* Clear Rising Falling edge configuration */
		temp = EXTI->RTSR;
		CLEAR_BIT(temp, 1U << (uint32_t)GPIO_PinAUX); 
		if((GPIO_Init->Mode & RISING_EDGE) == RISING_EDGE)
		{
			SET_BIT(temp, 1U << (uint32_t)GPIO_PinAUX); 
		}
		EXTI->RTSR = temp;

		temp = EXTI->FTSR;
		CLEAR_BIT(temp, 1U << (uint32_t)GPIO_PinAUX); 
		if((GPIO_Init->Mode & FALLING_EDGE) == FALLING_EDGE)
		{
			SET_BIT(temp, 1U << (uint32_t)GPIO_PinAUX); 
		}
		EXTI->FTSR = temp;

		/* Configure NVIC for External Interrupt */
		/* (1) Enable Interrupt on EXTI0_1 */
		/* (2) Set priority for EXTI0_1 */
		NVIC->ISER[0U] |= (uint32_t)(1UL << (((uint32_t)(int32_t)EXTI0_1_IRQn) & 0x1FUL));
		NVIC->ISER[0U] |= (uint32_t)(1UL << (((uint32_t)(int32_t)EXTI4_15_IRQn) & 0x1FUL));
		NVIC->IP[1] &= 0x00FFFFFF; // RCC_IRQn, EXTI0_1_IRQn, EXTI2_3_IRQn, EXTI4_15_IRQn
	}
}
	
void HAL_GPIO_WritePin(uint16_t Pin, GPIO_TypeDef* GPIO_Port, GPIO_PinState PinState){
  
	unsigned char bitStat;
	uint16_t GPIO_PinW;
	
	GPIO_PinW = (1U << ((Pin) / 2));//mascara necessaria para o pino
	
	if (PinState == GPIO_PIN_RESET)
  {
    (GPIO_Port)->BRR = GPIO_PinW;
  }
  else if (PinState == GPIO_PIN_SET)
  {
    (GPIO_Port)->BSRR = GPIO_PinW;
  }
	else{ /*toggle pin*/
		bitStat = HAL_GPIO_GetLevel(GPIO_Port, Pin);
		
		if (bitStat == GPIO_PIN_RESET)
		{
			(GPIO_Port)->BSRR = GPIO_PinW;
		}
		else if (bitStat == SET)
		{
			(GPIO_Port)->BRR = GPIO_PinW;
		}
	}
}
	
uint8_t HAL_GPIO_GetLevel(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin){

	GPIO_PinState bitstatus;
	GPIO_Pin = (1U << (GPIO_Pin / 2));

	if (((GPIOx->IDR & (GPIO_Pin))) != (uint32_t)GPIO_PIN_RESET)
  {
    bitstatus = GPIO_PIN_SET;
  }
  else
  {
    bitstatus = GPIO_PIN_RESET;
  }
  return bitstatus;

}

#endif

