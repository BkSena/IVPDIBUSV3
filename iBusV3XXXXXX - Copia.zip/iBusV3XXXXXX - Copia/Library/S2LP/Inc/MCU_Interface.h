/**
 *
 *
 *	Arquivo para a interface das estruturas superiores com o HAL
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MCU_INTERFACE_H
#define __MCU_INTERFACE_H


/* Includes ------------------------------------------------------------------*/
#include "S2LP_Config.h"
#include "HAL_SPI.h"


/* S2LP ------------------------------------------------------------------*/
void S2LPSpiInit(void);
S2LPStatus S2LPSpiWriteRegisters(uint8_t cRegAddress, uint8_t cNbBytes, uint8_t* pcBuffer);
S2LPStatus S2LPSpiReadRegisters(uint8_t cRegAddress, uint8_t cNbBytes, uint8_t* pcBuffer);
S2LPStatus S2LPSpiCommandStrobes(uint8_t cCommandCode);
S2LPStatus S2LPSpiWriteFifo(uint8_t cNbBytes, uint8_t* pcBuffer);
S2LPStatus S2LPSpiReadFifo(uint8_t cNbBytes, uint8_t* pcBuffer);

void S2LPEnterShutdown(void);
void S2LPExitShutdown(void);
unsigned char S2LPCheckShutdown(void);

//mascaramento das funcoes de comunicacao com as classes externas
#define HAL_GPIO_ExternInterrupt()		S2LP_CallExternInterrupt()
#define PILHA_SendBuffer(buf, len)		S2LP_SendBuffer(buf, len)
#define S2LP_SendResult(result)			PILHA_SendResult(result)
#define S2LP_ReceiveBuffer(buf, len)	PILHA_ReceiveBuffer(buf, len)

//j� est� no regmap
/*
typedef enum 
{
  RESET = 0, 
  SET = !RESET
} FlagStatus;
*/
#endif


