#ifndef S2LP_SPI_C
#define S2LP_SPI_C

/*-------------INCLUDE------------*/

#include "Main/iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.
#include "Main/SysUtils.h"

#include "S2LP_Types.h"
#include "MCU_Interface.h"

/*-------------DEFINES------------*/
#define HEADER_WRITE_MASK     0x00 /*!< Write mask for header byte*/
#define HEADER_READ_MASK      0x01 /*!< Read mask for header byte*/
#define HEADER_ADDRESS_MASK   0x00 /*!< Address mask for header byte*/
#define HEADER_COMMAND_MASK   0x80 /*!< Command mask for header byte*/

#define LINEAR_FIFO_ADDRESS 0xFF  /*!< Linear FIFO address*/

#define BUILT_HEADER(add_comm, w_r) (add_comm | w_r)  /*!< macro to build the header byte*/
#define WRITE_HEADER    BUILT_HEADER(HEADER_ADDRESS_MASK, HEADER_WRITE_MASK) /*!< macro to build the write header byte*/
#define READ_HEADER     BUILT_HEADER(HEADER_ADDRESS_MASK, HEADER_READ_MASK)  /*!< macro to build the read header byte*/
#define COMMAND_HEADER  BUILT_HEADER(HEADER_COMMAND_MASK, HEADER_WRITE_MASK) /*!< macro to build the command header byte*/


/*-------------VARIAVEIS------------*/


/*-------------FUNCOES------------*/
void S2LPSpiInit(void){
	//aqui vamos chamar o HAL para configurar o SPI
	//ver como definir as configs, fase, modo, velocidade, etc...se por struct ou parametros fixos
	HAL_SPI_Init(RADIO);
	
}

S2LPStatus S2LPSpiWriteRegisters(uint8_t cRegAddress, uint8_t cNbBytes, uint8_t* pcBuffer){
	
	uint8_t tx_buff[2]={WRITE_HEADER,cRegAddress};
	uint8_t rx_buff[255];
	S2LPStatus status;
	
	/* Puts the SPI chip select low to start the transaction */
	HAL_SPI_CSLow(RADIO);	
	HAL_SPI_TransmitReceive(tx_buff, rx_buff, 2, 1000);
	HAL_SPI_TransmitReceive(pcBuffer, &rx_buff[2], cNbBytes, 1000);
	/* Puts the SPI chip select high to end the transaction */
	HAL_SPI_CSHigh(RADIO);
	
	((uint8_t*)&status)[1]=rx_buff[0];
	((uint8_t*)&status)[0]=rx_buff[1];

	return status;
}

S2LPStatus S2LPSpiReadRegisters(uint8_t cRegAddress, uint8_t cNbBytes, uint8_t* pcBuffer){
	uint8_t tx_buff[255]={READ_HEADER,cRegAddress};
	uint8_t rx_buff[2];
	S2LPStatus status;

	HAL_SPI_CSLow(RADIO);
	HAL_SPI_TransmitReceive(tx_buff, rx_buff, 2, 1000);
	HAL_SPI_TransmitReceive(tx_buff, pcBuffer, cNbBytes, 1000);
	HAL_SPI_CSHigh(RADIO);
	
	((uint8_t*)&status)[1]=rx_buff[0];
	((uint8_t*)&status)[0]=rx_buff[1]; 

	return status;	
}

S2LPStatus S2LPSpiCommandStrobes(uint8_t cCommandCode){
	uint8_t tx_buff[2]={COMMAND_HEADER,cCommandCode};
	uint8_t rx_buff[2];
	S2LPStatus status;

	HAL_SPI_CSLow(RADIO);
	HAL_SPI_TransmitReceive(tx_buff, rx_buff, 2, 1000);
	HAL_SPI_CSHigh(RADIO);
	
	((uint8_t*)&status)[1]=rx_buff[0];
	((uint8_t*)&status)[0]=rx_buff[1];

	return status;
}

S2LPStatus S2LPSpiWriteFifo(uint8_t cNbBytes, uint8_t* pcBuffer){
	uint8_t tx_buff[2]={WRITE_HEADER,LINEAR_FIFO_ADDRESS};
	uint8_t rx_buff[130];
	S2LPStatus status;

	HAL_SPI_CSLow(RADIO);
	HAL_SPI_TransmitReceive(tx_buff, rx_buff, 2, 1000);
	HAL_SPI_TransmitReceive(pcBuffer, &rx_buff[2], cNbBytes, 1000);
	HAL_SPI_CSHigh(RADIO);
	
	((uint8_t*)&status)[1]=rx_buff[0];
	((uint8_t*)&status)[0]=rx_buff[1];

	return status;
}

S2LPStatus S2LPSpiReadFifo(uint8_t cNbBytes, uint8_t* pcBuffer){
	uint8_t tx_buff[130]={READ_HEADER,LINEAR_FIFO_ADDRESS};
	uint8_t rx_buff[2];
	S2LPStatus status;

	HAL_SPI_CSLow(RADIO);
	HAL_SPI_TransmitReceive(tx_buff, rx_buff, 2, 1000);
	HAL_SPI_TransmitReceive(tx_buff, pcBuffer, cNbBytes, 1000);
	HAL_SPI_CSHigh(RADIO);
 
	((uint8_t*)&status)[1]=rx_buff[0];
	((uint8_t*)&status)[0]=rx_buff[1];

	return status;
}

#endif
