#define CONFIGUART_C

#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.

#include "SysUtils.h"
#include "HAL_GPIO.h"



GPIO_InitTypeDef GPIO_InitStruct;

void gpio_GPIO(void);
void adc_GPIO(void);
void uart_GPIO(void);
void spi_GPIO(void);


void gpio_Init(void){
		
	//aqui chama todo mundo e nos xxx_GPIO ve os defines
	gpio_GPIO();
	adc_GPIO();
	uart_GPIO();
	spi_GPIO();

}
	
void gpio_GPIO(void){

		GPIO_InitStruct.Pin = TAMPER; //Tamper
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
		GPIO_InitStruct.Otyper = GPIO_OTYPER_OD;
		GPIO_InitStruct.Pull = GPIO_PULLDOWN;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);
				
		GPIO_InitStruct.Pin = LED2; //led2
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	
		GPIO_InitStruct.Pin = LED1; //Led1
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}


void adc_GPIO(void){

		GPIO_InitStruct.Pin = PIR1; //Pir1
		GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
	
		GPIO_InitStruct.Pin = PIR2;//Pir2
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);//Pir2
	
//		GPIO_InitStruct.Pin = LED1; //Led1
//		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void uart_GPIO(){
	
			
		GPIO_InitStruct.Pin 			= TXPC;
		GPIO_InitStruct.Mode			= GPIO_MODE_AF;
		GPIO_InitStruct.Otyper		= GPIO_OTYPER_OD;
		GPIO_InitStruct.Pull 			= GPIO_PULLDOWN;
		GPIO_InitStruct.Speed 		= GPIO_SPEED_FREQ_HIGH;
		GPIO_InitStruct.Alternate = GPIO_AF1;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		
		GPIO_InitStruct.Pin = RXPC;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		

}


void spi_GPIO(){
	
		//ent�o configura o b�sico para todos
		GPIO_InitStruct.Pin = CLK;  //CONFIG PB3 SPI-SCK
		GPIO_InitStruct.Mode = GPIO_MODE_AF;
		GPIO_InitStruct.Otyper = GPIO_OTYPER_PP;
		GPIO_InitStruct.Pull = GPIO_PULLUP;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
		GPIO_InitStruct.Alternate = GPIO_AF0;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		
		GPIO_InitStruct.Pin = MISO; //MIso
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		
		GPIO_InitStruct.Pin = MOSI; // MOSI.Pin;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

		GPIO_InitStruct.Pin = WAKEUP; //WAKE.Pin; /* Configurando pino de Wake para interrup��o externa*/
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT | GPIO_MODE_IT_FALLING;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
			
		GPIO_InitStruct.Pin = SDN; //SDN.Pin; /* Configurando pino de SDN para Output*/
		GPIO_InitStruct.Pull = GPIO_PULLDOWN;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT;
		GPIO_InitStruct.Otyper = GPIO_OTYPER_PP;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		
		GPIO_InitStruct.Pin = RD_CS; //RDCS.Pin; /* Radio select*/
		HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);
		
}

