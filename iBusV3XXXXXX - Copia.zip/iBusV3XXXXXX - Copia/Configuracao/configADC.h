#ifndef CONFIGADC_H
#define CONFIGADC_H

#include "HAL_GPIO.h"

#define VREFINT_CAL_ADDR ((uint16_t*) ((uint32_t) 0x1FFFF7BA))

enum ADC_ENTRADAS
{
	AD_LEDVM, 
	AD_PIR1,
	AD_PIR2,
	AD_TEMPERATURA,
	AD_VREF,
	
	ADC_QTD //indica quantas entradas de ADC possui
};

#ifndef ADC_C
extern void adc_PowerUp(void);//inicializa��es necess�rias assim que alimenta a placa

extern void adc_FastLoop(void);//a cada 3ms
extern void adc_Main(void);//a cada 10ms, para manter o ADC sempre convertendo

extern void adc_Init(enum ADC_ENTRADAS channel_adc);//come�a a ler a tens�o nessa entrada
extern void adc_Deinit(enum ADC_ENTRADAS channel_adc);//p�ra de ler a tens�o nessa entrada

extern unsigned short int adc_GetMiliVolts(enum ADC_ENTRADAS channel_adc);
#endif

#define CHANNELS	1
	
extern unsigned int adcValue[CHANNELS];

//extern unsigned char adcConvOK;
//extern unsigned int numMedidas;
//extern unsigned int adcMin[CHANNELS];
//extern unsigned int adcMax[CHANNELS];
//extern unsigned int adcMed[CHANNELS];

//extern void configAdc_Init(void); /*Inicializacao do ADC*/
//extern void adc_getRawValue(void);/*para salvar valores de adc*/
//extern void adc_Start(void);/**/
//extern void adc_Stop(void);/**/
//extern void adc_HabilitaFlag(void);

//extern void adc_Reset(void);/*Reseta var adc, como se fosse init*/


#endif /*CONFIGADC_H*/
