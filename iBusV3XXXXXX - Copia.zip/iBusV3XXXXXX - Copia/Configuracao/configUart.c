#define CONFIGUART_C

#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.

#include "configADC.h"
#include "SysUtils.h"

void uart_Init(void){

	USART2->BRR = SysUtils_ClockGet()/115200; //BAUD RATE
	USART2->CR1 = USART_CR1_TE | USART_CR1_UE | USART_CR1_RE; //habilita tx rx e uart
	NVIC->ISER[0U] |= (uint32_t)(1UL << (((uint32_t)(int32_t)USART2_IRQn) & 0x1FUL));//habilita interrup��o de uart
	//USART1->CR1 |= USART_CR1_TXEIE; //habilita interrup��o por tx
		
	if(RCC_CR_HSIRDY) /* Se o clock HSI estive habilitado*/
	RCC->CFGR3 |= (RCC_CFGR3_USART1SW_HSI); /*Clock para usart1 8Mhz*/	
}



