#ifndef CONFIGGPIO_H
#define CONFIGGPIO_H

#include "HAL_GPIO.h"

#define RESET				0x00

#define TAMPER			GPIO_PIN_0
#define LED1				GPIO_PIN_0
#define LED2				GPIO_PIN_1
#define PIR2				GPIO_PIN_4
#define PIR1 				GPIO_PIN_1

#define TXPC				GPIO_PIN_2
#define RXPC 				GPIO_PIN_3

#define CLK					GPIO_PIN_5
#define MISO				GPIO_PIN_6
#define MOSI 				GPIO_PIN_7
#define RD_CS				GPIO_PIN_1
#define SDN					GPIO_PIN_9
#define WAKEUP			GPIO_PIN_10


extern GPIO_InitTypeDef GPIO_InitStruct;

extern void gpio_Init(void); /*Inicializacao do Systick*/

#endif /*CONFIGGPIO_H*/
