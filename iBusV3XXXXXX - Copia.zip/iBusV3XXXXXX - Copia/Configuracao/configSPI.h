#ifndef CONFIGSPI_H
#define CONFIGSPI_H



extern void spi_Init(void); /*Inicializacao do Systick*/


#endif /*CONFIGSPI_H*/
