#ifndef CONFIGADC_C
#define CONFIGADC_C

#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.

#include "configADC.h"
//#include "adc.h"

#define ADC_OFF		0x0001F
#define ADC_INT		0x00040

static const unsigned int adc_registro[ADC_QTD]=
{
	ADC_CHSELR_CHSEL0,//	LEDVM,  			PA0
	ADC_CHSELR_CHSEL1,//	PIR1,   			PB1 
	ADC_CHSELR_CHSEL4,//	PIR2,   			PA4
	ADC_CHSELR_CHSEL16,//	TEMPERATURA,
	ADC_CHSELR_CHSEL17,//	VREF,
};

struct adc_strc {
	unsigned short int 	iValor;//contem o valor atual
	unsigned char enabled;//indica se este adc est� habilitado para efetuar convers�o
}adc[ADC_QTD];

unsigned int adcMax[CHANNELS], adcMin[CHANNELS], adcMed[CHANNELS];

/*
VDDa = (3300 * VREFINT_CAL_ADDR)/VREF
Vchannelx = (VDDa/4095)*Adc_Data
*/

unsigned char conversion_pos;

void adc_Enable(void);
void adc_calibracao(void);
void adc_Init(enum ADC_ENTRADAS channel_adc);

void adc_PowerUp(void)//inicializa��es necess�rias assim que alimenta a placa
{
	unsigned char aux = 0;
		
	RCC->APB2ENR |= RCC_APB2ENR_ADCEN; /* Habilitando clock para adc */
	ADC1->CR = RESET;
	ADC1->CFGR1 = RESET;
	ADC1->CFGR2 = 0x00000000;
	ADC1->SMPR = RESET;
	ADC1->TR = 0x0FFF0000;
	ADC1->CHSELR = RESET;
	
	adc_Enable();
	adc_calibracao();
	
	ADC1->SMPR |= ADC_SMPR_SMP_0 | ADC_SMPR_SMP_1 | ADC_SMPR_SMP_2; /* (4) */
	ADC1->IER = ADC_IER_EOCIE; /* (5) */
	
	adc_Enable();
	
	for(aux=0;aux<ADC_QTD;aux++)
	{//desabilita todos os canais
		adc[aux].iValor=0;
		adc[aux].enabled=0;//desabilitada
	}
	
	conversion_pos=ADC_QTD;//n�o estou convertendo nada agora

	NVIC->ISER[0U] |= (uint32_t)(1UL << (((uint32_t)(int32_t)ADC1_IRQn) & 0x1FUL)); /*Habilita interrup��o de ADC*/
}

void adc_FastLoop(void)//a cada 3ms
{
}

void adc_Main(void)//a cada 10ms, para manter o ADC sempre convertendo
{
	if(conversion_pos>=ADC_QTD)
	{//sem conversoes ativas? Starta novo loop de conversoes
		for(conversion_pos=0;conversion_pos<ADC_QTD;conversion_pos++)
		{
			if(adc[conversion_pos].enabled!=0)//achei uma entrada habilitada a convers�o?
			{//come�a a converter daqui
				ADC1->CHSELR = adc_registro[conversion_pos];
				ADC1->CR |= ADC_CR_ADSTART;
				break;
			}
		}
	}
}

void adc_Init(enum ADC_ENTRADAS channel_adc)//come�a a ler a tens�o nessa entrada
{
	if(channel_adc<ADC_QTD)adc[channel_adc].enabled=0x01;
	
	switch(channel_adc)
	{
		case AD_LEDVM:
			GPIOA->MODER |= GPIO_MODER_MD0_ANALOG;
			break;
		case AD_PIR1:
			GPIOB->MODER |= GPIO_MODER_MD1_ANALOG;
			break;
		case AD_PIR2:
			GPIOA->MODER |= GPIO_MODER_MD4_ANALOG;
			break;
		case AD_TEMPERATURA:
			break;
		case AD_VREF:
			break;				
		case ADC_QTD://Just for avoid the warning
			break;
	}
}

void adc_Deinit(enum ADC_ENTRADAS channel_adc)//para de ler a tens�o nessa entrada
{
	if(channel_adc<ADC_QTD)adc[channel_adc].enabled=0x00;
}

unsigned short int adc_GetMiliVolts(enum ADC_ENTRADAS channel_adc)
{
	return adc[channel_adc].iValor;
}

void adc_calibracao(void){
	
	/* (1) Ensure that ADEN = 0 */
	/* (2) Clear ADEN by setting ADDIS*/
	/* (3) Clear DMAEN */
	/* (4) Launch the calibration by setting ADCAL */
	/* (5) Wait until ADCAL=0 */
	
	if ((ADC1->CR & ADC_CR_ADEN) != 0) /* (1) */
	{
		ADC1->CR |= ADC_CR_ADDIS; /* (2) */
	}

	while ((ADC1->CR & ADC_CR_ADEN) != 0)
	{
	/* For robust implementation, add here time-out management */
	}
	
	ADC1->CFGR1 &= ~ADC_CFGR1_DMAEN; /* (3) */
	ADC1->CR |= ADC_CR_ADCAL; /* (4) */

	while ((ADC1->CR & ADC_CR_ADCAL) != 0) /* (5) */
	{
	/* For robust implementation, add here time-out management */
	}
}

void adc_Enable(void){
	
	/* (1) Ensure that ADRDY = 0 */
	/* (2) Clear ADRDY */
	/* (3) Enable the ADC */
	/* (4) Wait until ADC ready */
	ADC1->CR &= ~ADC_CR_ADDIS;
	if ((ADC1->ISR & ADC_ISR_ADRDY) != 0) /* (1) */
	{
		ADC1->ISR |= ADC_ISR_ADRDY; /* (2) */
	}
	ADC1->CR |= ADC_CR_ADEN; /* (3) */
	while ((ADC1->ISR & ADC_ISR_ADRDY) == 0) /* (4) */
	{
		int i = 0;
		for(i = 0; i<2000; i++){}
	}
}

void ADC1_IRQHandler(void){
	//unsigned long adc_leitura;
	unsigned int VDDA;

	NVIC->ICPR[0U] |= (uint32_t)(1UL << (((uint32_t)(int32_t)ADC1_IRQn) & 0x1FUL)); /*limpa interrup��o de ADC*/
		
	ADC1->CR |= ADC_CR_ADSTP;//stop adc

	if(conversion_pos>=ADC_QTD)return;//por algum motivo n�o sei que entrada converti. Retorna
	
	//VREFINT_CAL_ADDR
	//VDDa = (3300 * VREFINT_CAL_ADDR)/VREF
	//Vchannelx = (VDDa/4095)*Adc_Data
	if(adc[AD_VREF].iValor > 0) VDDA = 3300 * (*VREFINT_CAL_ADDR)/adc[AD_VREF].iValor;
	else VDDA = 3300;
	
	adc[conversion_pos].iValor = (VDDA * ((uint16_t)ADC1->DR))/4095;//leio e converto para milivolts
	
	//adc[conversion_pos].iValor = ((((uint16_t)ADC1->DR)*3300)/4096);//leio e converto para milivolts
	
	for(conversion_pos++;conversion_pos<ADC_QTD;conversion_pos++)
	{
		if(adc[conversion_pos].enabled!=0)
		{
			ADC1->CHSELR = adc_registro[conversion_pos];
			ADC1->CR |= ADC_CR_ADSTART;
			break;//for			
		}
	}
}

#endif //CONFIG_ADC

