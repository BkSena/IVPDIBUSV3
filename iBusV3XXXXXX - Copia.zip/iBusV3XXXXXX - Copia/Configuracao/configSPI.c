#define CONFIGSPI_C

#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.

#include "SysUtils.h"

void spi_Interrupt(void);

void spi_Init(void){

	/* (1) Master selection, BR: Fpclk/256 (due to C27 on the board, SPI_CLK is
	set to the minimum) CPOL and CPHA at zero (rising first edge) */
	/* (2) Slave select output enabled, RXNE IT, 8-bit Rx fifo */
	/* (3) Enable SPI1 */
//	SPI1->CR1 = 0;
//	SPI1->CR2 = 0x0700;
	
	SPI1->CR1 = SPI_CR1_MSTR | SPI_CR1_BR; /* (1) */
	SPI1->CR2 = SPI_CR2_SSOE | SPI_CR2_RXNEIE | SPI_CR2_FRXTH
							| SPI_CR2_DS_2 | SPI_CR2_DS_1 | SPI_CR2_DS_0; /* (2) */
	SPI1->CR1 |= SPI_CR1_SPE; /* (3) */

	//spi_Interrupt();

}


void spi_Interrupt(){
	/*Habilita interrup��o de externa*/
	
//	EXTI->IMR = 0x0001; /* (3) */
//	EXTI->RTSR = 0x0001; /* (4) */
//	EXTI->FTSR = 0x0001; /* (5) */
//	/* Configure NVIC for External Interrupt */
//	/* (1) Enable Interrupt on EXTI0_1 */
//	/* (2) Set priority for EXTI0_1 */
//	NVIC->ISER[0U] |= (uint32_t)(1UL << (((uint32_t)(int32_t)EXTI0_1_IRQn) & 0x1FUL));

}

