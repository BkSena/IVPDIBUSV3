#ifndef CONFIGUART_H
#define CONFIGUART_H



extern void uart_Init(void); /*Inicializacao do Systick*/


#endif /*CONFIGUART_H*/
