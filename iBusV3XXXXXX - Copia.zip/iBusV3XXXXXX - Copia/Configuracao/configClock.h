#ifndef CONFIGCLOCK_H
#define CONFIGCLOCK_H

#define MAX_DELAY      							0xFFFFFFFFU

extern void clock_Init(void); /*Inicializacao do Systick*/


#endif /*CONFIGCLOCK_H*/
