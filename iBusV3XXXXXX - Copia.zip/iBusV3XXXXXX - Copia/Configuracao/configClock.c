#define CONFIGCLOCK_C

#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.
#include "configClock.h"

#include "Main/SysUtils.h" //SysUtils_ClockGet()

void SysTick_Config(uint32_t);

//uint32_t uwTick = 0;

void clock_Init(void){
	
	RCC->APB1ENR = RCC_APB1ENR_PWREN;/* Enable Power Control clock */
	/* Set HSION bit, HSITRIM[4:0] bits to the reset value PLL OFF*/
	RCC->CR |= (RCC_CR_HSION | RCC_CR_HSITRIM_4) & ~(RCC_CR_PLLON);
	SysTick_Config(SysUtils_ClockGet()/1000);/*Habilita Systick*/
	
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;	/* Enable SYSCFG Clock */
	RCC->APB2ENR |= RCC_APB2ENR_SPI1EN; 	/* Habilitando clock para SPI1 */
	RCC->APB2ENR |= RCC_APB2ENR_ADCEN; 		/* Habilitando clock para adc */
	
	RCC->APB1ENR |= RCC_APB1ENR_USART2EN; /* Habilitando clock para USART2 */

	
	//Habilita clock GPIO para PTA/PTB/PTF
	RCC->AHBENR |= (RCC_AHBENR_GPIOAEN | RCC_AHBENR_GPIOBEN | 
									RCC_AHBENR_GPIOFEN);	
	

}
//
void SysTick_Config(uint32_t ticks){
	//Inicializa��o do System Timer, SysTick
	ticks = (uint32_t)(ticks - 1UL);//clocks de 1ms
	ticks -=3;/*Corre��o de 2,64579 na contagem de 48000. (Atrasou 20s em 100h47m20s)*/
	SysTick->LOAD  = ticks;                       											/* set reload register RVR */ 
  //NVIC_SetPriority (SysTick_IRQn, (1UL << __NVIC_PRIO_BITS) - 1UL); /* set Priority for Systick Interrupt */
  SysTick->VAL   = 1UL; /*j� inicia estourando o timer*/              /* Load the SysTick Counter Value CV4 */
  SysTick->CTRL  = SysTick_CTRL_CLKSOURCE_Msk |
                   SysTick_CTRL_TICKINT_Msk   |	
                   SysTick_CTRL_ENABLE_Msk;                         	/* Enable SysTick IRQ and SysTick Timer CSR */

}


////
//void main_SysTick(void){
//	uwTick++;
//}
////
//uint32_t get_Tick(void){
//	return uwTick;
//}
///** 
//  * @brief Delay 1ms
//  */
//void delay(uint32_t Delay){
//		
//  uint32_t wait = Delay;
//	uint32_t tickstart = get_Tick();
//	
//	if (wait < MAX_DELAY)
//  {
//     wait++;
//  }
//	while((get_Tick() - tickstart) < wait)
//  {
//  }
//}
