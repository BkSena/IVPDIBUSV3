#ifndef S2LP_C
#define S2LP_C

#include "Main/iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.
#include "Main/SysUtils.h"

#include "Radio.h"
#include "../Hardware/adc.h"
#include "iBUSv3/iBUSenlace.h"

//#include "S2LP_RegMap.h"
#include "S2LP.h"
#include "S2LP_Commands.h"
#include "S2LP_Gpio.h"
#include "S2LP_PktBasic.h"
#include "S2LP_Qi.h"
#include "S2LP_Radio.h"
#include "S2LP_Timer.h"

#include "S2LP_Fifo.h"

#include "MCU_Interface.h"

#include "HAL_GPIO.h"

//Definicoes do radio
#undef PREAMBLE_LENGTH
#define PREAMBLE_LENGTH                 40//(64*4)
#define MIN_PERIOD_WAKEUP ((8000*((PREAMBLE_LENGTH/4)-2))/DATARATE)

/**
* @brief Tx buffer declaration: data to transmit
*/
//uint8_t vectcTxBuff[20]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,'\0'};

unsigned char tmpBuffer[4];

#define RSSI_THR -70//-70 //-86 //-60	//esse valor foi pego do exemplo CSMA_A. VERIFICAR!!

static unsigned int s_lXtalFrequency = 50000000;//50000000; //no IVP usamos cristal de 25MHz

SRadioInit xRadioInit = {
  BASE_FREQUENCY,
  MODULATION_SELECT,
  DATARATE,
  FREQ_DEVIATION,
  BANDWIDTH
};

PktBasicInit xBasicInit={
  PREAMBLE_LENGTH,
  SYNC_LENGTH,
  SYNC_WORD,
  VARIABLE_LENGTH,
  EXTENDED_LENGTH_FIELD,
  CRC_MODE,
  EN_ADDRESS,
  EN_FEC,
  EN_WHITENING
};

S2LPIrqs xIrqStatus;
FlagStatus irq_raised = RESET;

/**
* @brief Tx buffer declaration: data to transmit
*/
//uint8_t tx_data[20], rx_data[20];
//uint8_t rx_data[20];
////uint8_t tx_data_size=0, rx_data_size=0;
//uint8_t rx_data_size=0;

//#define MAX_BUF 30
//uint8_t tx_data[MAX_BUF], rx_data[MAX_BUF];
//uint8_t tx_data_size=0, rx_data_size=0;

uint8_t vectcRxBuff[96], cRxData;
//uint8_t xtal[2];

unsigned char rssi_latched, transmitindo;

/*
	PROTOTIPOS DE FUNCAO
*/

void S2LP_Config(void);
void S2LP_ManagementRcoCalibration(void);
void S2LP_ManagementTcxoInit(void);
void imprimeRadio(void);
//void PILHA_SendResult(uint8_t result){}
//void PILHA_ReceiveBuffer(uint8_t *buf, uint8_t len){}

/*
	FUNCOES
*/

void radio_Init(void){
	//definir e confirgurar a interrup�ao do uC para tratar as IRQ do S2LP!
	#warning Implementar
	//configurar o pino q estiver ligado no 'Wakeup', para interrupcao externa, � aqui que o radio avisa qdo chegar algum PKT
	
	//Inicializar SPI ou garantir q ja esteja inicializado //configurar o pino SDN para saida dig
	S2LPSpiInit();
	
	//Inicializa��o do Radio
	S2LPEnterShutdown();
	S2LPExitShutdown();
	S2LP_Config();//RETURN
	
}

void radio_Timer(void){
}



void S2LPEnterShutdown(void){
	//aqui vamos chamar o GPIO responsavel por ativar o SDN do radio - nivel 1, radio em shutdown
	HAL_GPIO_WritePin(GPIO_PIN_9, GPIOA, GPIO_PIN_SET);
}

void S2LPExitShutdown(void){
	//aqui vamos chamar o GPIO responsavel por desativar o SDN do radio - nivel 0, radio ativo
	HAL_GPIO_WritePin(GPIO_PIN_9, GPIOA, GPIO_PIN_RESET);
	/* Delay to allow the circuit POR, about 700 us */
  for(volatile uint32_t i=0;i<0x1E00;i++);
}

unsigned char S2LPCheckShutdown(void){
	//aqui vamos ler o GPIO responsavel pelo SDN
	return  HAL_GPIO_GetLevel(GPIOA, GPIO_PIN_9);
	//return 0;
}

void S2LP_CallExternInterrupt(void){
	//verificar se precisa validar o pino q gerou a interrupt
	irq_raised=SET;
}

//ok

void S2LP_Config(void)
{

  S2LPRadioSetXtalFrequency(s_lXtalFrequency);
	
//	xRadioInit.lFrequencyBase = xRadioInit.lFrequencyBase;// + S2LPManagementGetOffset();
//	//S2LP_ManagementTcxoInit();// n�o usar
//	
//	/* initialize GPIO_0 IRQ configuration */	/* S2LP gpio config */
	S2LPGpioInit(&(SGpioInit){S2LP_GPIO_0, S2LP_GPIO_MODE_DIGITAL_OUTPUT_LP, S2LP_GPIO_DIG_OUT_IRQ});

	 /* S2LP Radio config */
  S2LPRadioInit(&xRadioInit);
//	
	/* Perform an offline calibration of RCO */
	S2LP_ManagementRcoCalibration();
//	
	/* S2LP Radio set power */
	S2LPRadioSetMaxPALevel(S_DISABLE);
	/* if we haven't an external PA, use the library function */
	S2LPRadioSetPALeveldBm(7,POWER_DBM); //7
//	
	S2LPRadioSetPALevelMaxIndex(7);
//			
	/* S2LP Packet config */
	S2LPPktBasicInit(&xBasicInit);
	
		/* S2LP IRQs enable */
  S2LPGpioIrqDeInit(NULL);
  S2LPGpioIrqConfig(TX_DATA_SENT , S_ENABLE);
  S2LPGpioIrqConfig(RX_DATA_READY, S_ENABLE);
	S2LPGpioIrqConfig(RX_DATA_DISC , S_ENABLE);
		
	/* payload length config */
  S2LPPktBasicSetPayloadLength(20);
	
		/* IRQ registers blanking */
  S2LPGpioIrqClearStatus();  
	
	SRssiInit xSRssiInit = {
    .cRssiFlt = 14,
    .xRssiMode = RSSI_STATIC_MODE,
    .cRssiThreshdBm = RSSI_THR,
  };
  S2LPRadioRssiInit(&xSRssiInit);
	
	/* the RX command */
	S2LPCmdStrobeRx();

	transmitindo=0;

}

void radio_Run(void)//chamar em tempo de loop para tratar do r�dio.
{
	if(irq_raised)
	{//Interrup��o detectada

		irq_raised = RESET;

		/* Get the IRQ status */
    S2LPGpioIrqGetStatus(&xIrqStatus);
	
		/* Check the SPIRIT TX_DATA_SENT IRQ flag */	
    if(xIrqStatus.IRQ_TX_DATA_SENT)
    {
			//flag_RadioEnviado = 0;
			//terminal_Printf_E("TX ");//para avisar quando interrompe
			#ifdef SOU_SNIFFER
			//terminal_Printf_E("{ ");//para avisar quando interrompe
			#endif
			transmitindo=0;

				
			#ifdef radio_AvisaFimTransmissao
			radio_AvisaFimTransmissao();
			#endif

    }//IF TX
		
    if(xIrqStatus.IRQ_RX_DATA_READY)
    {	
      /* Get the RX FIFO size */
			//flag_RadioEnviado = 0;
      cRxData=S2LPFifoReadNumberBytesRxFifo();		
			/* Read the RX FIFO */
			S2LPSpiReadFifo(cRxData, vectcRxBuff);
			
			//S2LPCmdStrobeSleep();
			
			/* Flush the RX FIFO */
      S2LPCmdStrobeFlushRxFifo();
			
			S2LPSpiReadRegisters(RSSI_LEVEL_ADDR, 1, &rssi_latched); 
			
			#ifdef SOU_SNIFFER

			
			#ifndef IBUSV3_REPETIDOR //economiza
			S2LPSpiReadRegisters(CRC_FIELD3_ADDR, 4, tmpBuffer);

			
			if(xIrqStatus.IRQ_CRC_ERROR){
			//	terminal_Printf_E(" - CRC Error");
			}
			#endif
			#endif
			
			#ifdef radio_receivePacket
			radio_receivePacket(vectcRxBuff,cRxData);
			#endif
			
			/* RX command */
			//S2LPCmdStrobeRx();				
    }

		if(xIrqStatus.IRQ_CRC_ERROR)
		{
			#ifdef radio_CRCErrorHandle
			radio_CRCErrorHandle(); //informa pacote recebido com erro
			#endif

		}
		S2LPCmdStrobeRx();//toda vez que interrompe, d� o comando para voltar a receber
	}
}

unsigned char radio_sendPacket(unsigned char *data, unsigned char len)//0 se conseguiu enviar, dif. de zero se erro
{
	
	/* payload length config */
	S2LPPktBasicSetPayloadLength(len);
	/* fit the TX FIFO */
	S2LPCmdStrobeFlushTxFifo();
	S2LPSpiWriteFifo(len, data);

	S2LPGpioIrqConfig(RX_DATA_DISC,S_DISABLE);
	S2LPCmdStrobeSabort();
	for(uint32_t i=0;i<0xFFF;i++);
	S2LPGpioIrqClearStatus();
	S2LPGpioIrqConfig(RX_DATA_DISC,S_ENABLE);
 // S2LPGpioIrqConfig(RX_DATA_READY,S_ENABLE);

	/* send the TX command */
	S2LPCmdStrobeTx();
	
	transmitindo=1;

	return 1;
}

void radio_powerOn(void)
{
	transmitindo=0;
	#ifndef DEBUGAR
	#error "IMPLEMENTAR"
	#endif
}

void radio_shutdown(void)
{
	#ifndef DEBUGAR
	#error "IMPLEMENTAR"
	#endif
}

void radio_SetChannel(unsigned char channel)
{
	S2LPRadioSetChannel(channel*2);//troca o canal
	
	S2LPCmdStrobeSabort();//vai gerar interrup��o e for�ar StrobeRx novamente reativando a recep��o no canal certo.
	for(uint32_t i=0;i<0xfff;i++);
	S2LPGpioIrqClearStatus();
	
}

unsigned char radio_portadora(void)//zero se sem portadora, RSSI se com portadora
{
	//static unsigned char debousing=0;//para evitar a primeira leitura errada e ainda 
	uint8_t tmpBuffer[2];
	unsigned char rssi;
	if(transmitindo==0)
	{
		//O S2LP possui mecanismo interno de CSMA, modificar enlace para suporter o mecanismo interno que � melhor
		
		for(rssi=0;rssi<3;rssi++)
		{//vou ler 3 vezes pra ter certeza que n�o tem portadora
			if(S2LPQiGetCs()!=0)
			{//uma vez j� diz que tem portadora? j� avisa e aborta
				S2LPSpiReadRegisters(RSSI_LEVEL_RUN_ADDR, 2, tmpBuffer);
				rssi = tmpBuffer[1];
				return rssi;
			}
		}
		return 0;//chegou aqui, n�o temos portadora detectada

	}
	return 0;//sem portadora, estou transmitindo
}

unsigned char radio_GetRSSI(void)//retorna o Lacth RSSI
{
	return rssi_latched;//valor obtido no momento do sync word
}

void S2LP_ManagementRcoCalibration(void)
{
	uint8_t tmp[2],tmp2 = 0;
	uint16_t aux;
  
	//S2LPTimerCalibrationRco(S_ENABLE);
	S2LPSpiReadRegisters(XO_RCO_CONF0_ADDR, 1, &tmp2);
	tmp2 |= RCO_CALIBRATION_REGMASK;
	S2LPSpiWriteRegisters(XO_RCO_CONF0_ADDR, 1, &tmp2);  

	//S2LPCmdStrobeStandby();
	S2LPSpiCommandStrobes(CMD_STANDBY);

	//S2LPCmdStrobeReady();
  S2LPSpiCommandStrobes(CMD_READY);

	do
	{
		for(aux = 0; aux < 0x3FF; aux++){}//SdkDelayMs(100);
		S2LPSpiReadRegisters(MC_STATE1_ADDR, 1, tmp);
	}
	while((tmp[0]&RCO_CAL_OK_REGMASK)==0);
  
	S2LPSpiReadRegisters(0x94, 2, tmp);
	S2LPSpiReadRegisters(0x6F, 1, &tmp2);
	tmp[1]=(tmp[1]&0x80)|(tmp2&0x7F);
  
	S2LPSpiWriteRegisters(RCO_CALIBR_CONF3_ADDR, 2, tmp);
  
	//S2LPTimerCalibrationRco(S_DISABLE);
	S2LPSpiReadRegisters(XO_RCO_CONF0_ADDR, 1, &tmp2);
	tmp2 &= 0xFE;
	S2LPSpiWriteRegisters(XO_RCO_CONF0_ADDR, 1, &tmp2);
}

//void S2LP_ManagementTcxoInit(void)
//{
//    uint8_t tmp;
//    S2LPSpiReadRegisters(0x6D, 1, &tmp);
//    tmp|=0x80;
//    S2LPSpiWriteRegisters(0x6D, 1, &tmp);
//}

#endif
