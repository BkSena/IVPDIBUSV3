#ifndef RADIO_H
#define RADIO_H

//A camada superior pode ajustar uma fun��o aqui para ser informada quando a transmiss�o for concluida
#define radio_AvisaFimTransmissao iBUSenlace_AvisaFimTransmissao

//A camada superior deve ajustar uma fun��o para tratar os dados recebidos
#define radio_receivePacket(packet, len) iBUSenlace_ReceivePacket(packet, len)

//A camada superior pode ajustar uma fun��o para ser informada em caso de CRC erro.
#define radio_CRCErrorHandle iBUSenlace_CRCErrorHandle

#ifndef RADIO_C
extern void radio_Init(void);//Inicializa��o do r�dio
extern void radio_Run(void);//chamar em tempo de loop para tratar do r�dio.

extern unsigned char radio_sendPacket(unsigned char *data, unsigned char len);//0 se conseguiu enviar, dif. de zero se erro

extern void radio_powerOn(void);
extern void radio_shutdown(void);

extern void radio_SetChannel(unsigned char channel);

extern unsigned char radio_portadora(void);//zero se sem portadora, RSSI se com portadora
extern unsigned char radio_GetRSSI(void);//retonna o Lacth RSSI

extern void S2LP_CallExternInterrupt(void);

#endif
#endif
