#ifndef S2LP_H
#define S2LP_H

/** @defgroup Configuration_Exported_Constants  Configuration Exported Constants
 * @{
 */
#define DIG_DOMAIN_XTAL_THRESH  30000000        /*!< Digital domain logic threshold for XTAL in MHz */

#define BASE_FREQUENCY              431000000

#define MODULATION_SELECT           MOD_2FSK
#define DATARATE                    10000
#define FREQ_DEVIATION              20000
#define BANDWIDTH                   150000
#define POWER_DBM                   12/*.0*/
  
/*  Packet configuration parameters  */
#define PREAMBLE_LENGTH             PREAMBLE_BYTE(4)
#define SYNC_LENGTH                 SYNC_BYTE(2)
#define SYNC_WORD                   0x2DD4// 0x88888888
#define VARIABLE_LENGTH             S_ENABLE
#define EXTENDED_LENGTH_FIELD       S_DISABLE
#define CRC_MODE                   	PKT_CRC_MODE_16BITS_1 // x16+x15+x2+1    //old - PKT_CRC_MODE_8BITS
#define EN_ADDRESS                  S_DISABLE
#define EN_FEC                      S_DISABLE
#define EN_WHITENING                S_DISABLE

/* Wake Up timer in ms for LDC mode */
#define WAKEUP_TIMER                100/*.0*/

#define PREAMBLE_BYTE(v)        	(4*v)
#define SYNC_BYTE(v)            	(8*v)

#endif
