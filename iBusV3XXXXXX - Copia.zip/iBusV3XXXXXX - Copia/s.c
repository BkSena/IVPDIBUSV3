close all
clear all
clc
////
//Aqui s�o carregados todos os dados principais
//PotenciaMedida --- Traz o vetor de potencia medido

//Parametros     --- Traz o vetor de parametros puro -
//Tecn(�m) | Freq.Uso(GHz) |
//Freq.Cen(GHz)|BW(GHz)|Fmin(GHz)|Fmax(GHz)|g(lin)|(1/nf-1)|iip3(W)

//ParametrosAlterados     --- Traz o vetor de parametros atualizados -
// ganho*fmax | 1/(nf-1) | iip3^(1/2)
////

load dadosMixer
Parametros = ParameMedidos;
Potencia = PotenciaMedida;
vetIndex = [1:length(Potencia)]';

Coef = regress(Potencia, Parametros);
[Amostras,colParam] = size(Parametros);

//Aqui se faz a rela��o da potencia calculada atraves da regress�o
for linha = 1:Amostras
    for coluna = 1 : colParam
        if coluna == 1
            soma = Coef(coluna);
        else
            soma = soma + Coef(coluna)*Parametros(linha,coluna);
        end
    end
    PotenciaCalcMedida(linha) = soma;
end

erroAmostra = abs((Potencia-PotenciaCalcMedida')./(Potencia));
erroMed = mean(erroAmostra)*100;

figure
plot(Potencia.*1000,'*','linewidth',2); hold on; grid
plot(PotenciaCalcMedida.*1000,'*','linewidth',2)
title(['\fontsize{20}Erro Relativo M�dio ',num2str(erroMed),'//']);
legend('Pot�ncia  Medida','Pot�ncia Calculada','FontSize',14)
xlabel('Amostras','FontSize',20);
ylabel('Pot�ncia(mW)','FontSize',20);
set(gca,'fontsize',18)

ind =0;
tentativas = 100;
while ind < tentativas
    
    //Agora que j� temos o erro de cada amostra vamos eliminar quem tem
    //erro maior que 70//
    PotenciaCalc = 0;
    index=0;
    
    if (length(erroAmostra) < 2)
        ind = tentativas+1;
    else
        for k=1:length(erroAmostra)
            if(erroAmostra(k)>(1-(ind/100)))
                index=index+1;
                erro40(index) = k;
            end
        end
    end
    
    if (erro40 == 0)//se n�o tiver mais ninguem para tirar para o codigo
        //ind = tentativas+1;
    else
        Parametros(erro40,:) = [];
        Potencia(erro40,:) = [];
        vetIndex(erro40,:) = [];

        Param = Parametros;
        Param(:,1) = Potencia;
        correlacao = corrcoef(Param);
        
        Coef = regress(Potencia, Parametros);
        [Amostras,colParametros] = size(Parametros);
        
        for linha = 1:Amostras
            for coluna = 1 : colParametros
                if coluna == 1
                    soma = Coef(coluna);
                else
                    soma = soma + Coef(coluna)*Parametros(linha,coluna);
                end
            end
            
            PotenciaCalc(linha) = soma;
        end

        erroAmostra = abs((Potencia-PotenciaCalc')./(Potencia));
        erroMed = mean(erroAmostra)*100;
        
        if(erroMed < 12)
            ind = tentativas+1;
        end
        
        if(erroMed < 15 && erroMed > 10)
            figure
            plot(Potencia.*1e3,'*','linewidth',2); hold on; grid
            plot(PotenciaCalc.*1e3,'*','linewidth',2)
            title(['\fontsize{20}Erro Relativo M�dio ',num2str(erroMed),'//']);
            legend('Pot�ncia  Medida','Pot�ncia Calculada','FontSize',14)
            xlabel('Amostras','FontSize',20);
            ylabel('Pot�ncia(mW)','FontSize',20);
            set(gca,'fontsize',18)
        end
    end
    
    ind = ind+1;
    erro40 = 0;
    erroMed = 0;
    soma = 0;
    
end
PotenciasmW = [Potencia.*1000,PotenciaCalc'.*1000];
Potencias87mW = [PotenciaMedida.*1000,PotenciaCalcMedida'.*1000];

ParamdB = Parametros;
ParamdB(:,8) = 10*log10(ParamdB(:,8)); //g
ParamdB(:,9) = 10*log10(ParamdB(:,9))+30; //iip3
ParamdB(:,10) = 10*log10((1./ParamdB(:,10))+1); //nf
//Tec|F.U|F.C|BW|Fmin|Fmax|g|iip3|(1/nf-1)|

FMIN_MAX = max(ParamdB(:,6));
FMIN_MIN = min(ParamdB(:,6));

FMAX_MAX = max(ParamdB(:,7));
FMAX_MIN = min(ParamdB(:,7));

GMAX = max(ParamdB(:,8));
GMIN = min(ParamdB(:,8));

IIP3MAX = max(ParamdB(:,9));
IIP3MIN = min(ParamdB(:,9));

NFMAX = max(ParamdB(:,10));
NFMIN = min(ParamdB(:,10));

clc;

//mdl1 = fitlm(Param, Potencia, 'constant')
// mdl1 = fitlm(ParamMedido, PotenciaMedida, 'linear');
// mdl2 = fitlm(Param, Potencia, 'linear');
//mdl3 = fitlm(Param, Potencia, 'interactions')
//mdl4 = fitlm(Param, Potencia, 'purequadratic')
