#define IBUSREDE_C

#include "Main/iBUSv3.h"
#include "iBUSrede.h"

#include "iBUSv3/iBUSManager.h"
#include "iBUSv3/iBUStransporte.h"

#include "Sistema/System.h"
#include "Sistema/dynmem.h"
#include "Sistema/Rijndael.h"

#ifdef SOU_SNIFFER
//#include "S2LP_SDK_Util.h"
#endif

#define IBUSREDE_TEMPOMAXTX 250 //ms para transmitir o pacote
#define IBUSREDE_VERSAO 0x10

struct ir_filaRepeticao
{
	unsigned char timeout;//em decimos de segundo
	unsigned short int crc;
	struct iRedePack *pack;
	struct ir_filaRepeticao *next;
};


/************************** variaveis internas ******************************/
const unsigned char INITVECTOR[16]={0xbf, 0x69, 0x4f, 0x59, 0x44, 0x0b, 0xee, 0x38, 0xe1, 0x02, 0x4b, 0xfd, 0xad, 0x21, 0x7d, 0x1c};
const unsigned char CHAVEPADRAO[16]={0x5f, 0x1d, 0xb7, 0x30, 0xce, 0x42, 0x8d, 0xb1, 0x97, 0xe3, 0xa3, 0x76, 0xa4, 0x28, 0x81, 0xbb};
const unsigned char MULTICAST_RECEPTORES[3] = {0x00, 0x00, 0x02};
const unsigned char MULTICAST_DISPOSITIVOS[3] = {0x00, 0x00, 0x01};

unsigned short int iBUSrede_TxTimer;

void ir_Decrypt(struct iRedePack *pack);//descriptografa o pacote

void iBUSrede_Init(void)
{
	iBUSrede_TxTimer=0;
}

void iBUSrede_Main(void)
{//chamar peri�dicamente (a cada 1ms)
	if(iBUSrede_TxTimer)iBUSrede_TxTimer--;//tempo ate�que a camada inferior retorne que o pacote foi enviado
}

void iBUSrede_receiveData(struct iEnlacePack *dados){
	unsigned char aux;
	struct iRedePack *pack;
	unsigned char my_address[3];
	unsigned char tratar=0;

	if(dados->len>=23)
	{//tem que ter recebido no minimo RECMAC(3) + SENDMAC(3) + VerCripSchTTL(1) + CRIPTO(16)
		pack = malloc(sizeof(struct iRedePack));//aloco mem�ria para receber
		
		if(pack!=NULL)
		{//temos espaco para receber? - Destrinchar o pacote!
			for(aux=0;aux<3;aux++)
			{
				pack->receiver_add[aux]=dados->data[0+aux];
				pack->sender_add[aux]=dados->data[3+aux];
			}
			pack->versao=(dados->data[6]>>4);
			pack->cripto_scheme=((dados->data[6]&0x08)!=0);
			pack->ttl=dados->data[6]&0x07;
			
			pack->rssi = dados->rssi;
			
			if(((dados->len-7)%16)==0)
			{//bloco de criptografia AES128 v�lido
				pack->cripto=malloc(dados->len-7);
				if(pack->cripto!=NULL)
				{
					pack->len=(dados->len-7);
					for(aux=0;aux<(dados->len-7);aux++)pack->cripto[aux]=dados->data[7+aux];//copia o pacote criptografado
				
					system_macAddress(my_address);//carrego o endere�o
					
					if(iBUSManager_CompararAddress(my_address, pack->receiver_add)!=0)//eh meu endere�o?
					{//recebi um pacote pra mim
						tratar=1;//marca para tratar o pacote recebido
					}
					else //repetidores se importam com pacotes que n�o s�o pra eles.
					{
						if(iBUSManager_CompararAddress(my_address, pack->sender_add)==0)
						{//n�o repito meus pr�prios pacotes
							tratar = iBUSManager_CompararAddress((unsigned char *)MULTICAST_DISPOSITIVOS, pack->receiver_add);//verifica se eu trato esse pacote
						}
					}

					if(tratar)
					{//camadas superiores tem que dar tratamento a este pacote
					
						ir_Decrypt(pack);//descriptografa o pacote
						iBUStransporte_receiveDecripto(pack);
					}			
					free(pack->cripto);//libera memoria
				}
			}
			free(pack);//libera memoria
		}
	}
}

void iBUSrede_enlaceResult(enum RESULTS result)
{
	if(result == IBUSENLACE_RESULT_TRANSMISSAO_OK)
	{
		iBUSrede_TxTimer=0;//transmti, pronto pra outra
	}
	iBUStransporte_redeResult(result);
}

//LOW POWER routines
void iBUSrede_Wakeup(void)
{//acorda sistema 
	iBUSenlace_Wakeup();
}
void iBUSrede_Shutdown(void)
{//prepara tudo para entrar em modo sleep
	#ifdef SOU_REPETIDOR
	struct ir_filaRepeticao *fila, *prox;
	#endif
	
	iBUSenlace_Shutdown();
	
	iBUSrede_TxTimer=0;
	
	#ifdef SOU_REPETIDOR
	//libera a fila toda de repeticao	
	fila=iBUSrede_FilaRepeticao;
	while(fila!=NULL)
	{
		prox = fila->next;
		//Desaloco as mem�rias desse pacote
		free(fila->pack->cripto);
		free(fila->pack);
		free(fila);
		
		fila = prox;
	}
	iBUSrede_FilaRepeticao=NULL;
	#endif
}

//Interface com camadas superiores
unsigned char iBUSrede_canIsend(void)
{//retorna diferente de zero se pronto para enviar pacotes.
	if(iBUSrede_TxTimer==0)
	{//n�o estou transmitindo
		if(iBUSenlace_canIsend())
		{//posso transmitir
			return 1;
		}
	}
	return 0;
}

unsigned char iBUSrede_Send(struct iRedePack *packet)
{//envia um pacote na camada de enlace, retorna 0 se ok
	struct iEnlacePack enlace;
	unsigned char len_16;
	unsigned char cipherval[16];
	unsigned char aux, ch;//ch �h char, permite descriptografar at� 16*256 bytes.
	
	if(iBUSrede_TxTimer==0)
	{//n�o estou transmitindo
		iBUSrede_TxTimer=IBUSREDE_TEMPOMAXTX;//quanto tempo temos para a camad inferior responder que a transmiss�o foi bem sucedida
		
		//Vamos criptografar e montar o pacote de enlace

		//Calcula que tamanho fica multiplo de 16
		len_16 = (((packet->len-1)/16)+1)*16;
		
		enlace.data = malloc(len_16+7);
		
		if(enlace.data!=NULL)
		{//tenho espa�o para enviar isso?
			enlace.len=len_16+7;
			
			for(aux=0;aux<3;aux++)
			{
				enlace.data[aux]=packet->receiver_add[aux];
				enlace.data[3+aux]=packet->sender_add[aux];
			}
			
			enlace.data[6]=IBUSREDE_VERSAO|(0x03)|((packet->cripto_scheme&0x01)<<3);//Vers�o 0x1; TTL 3; cripto scheme from transport layer.
			
			//Copiar dados
			for(aux=0;aux<packet->len;aux++)enlace.data[7+aux]=packet->cripto[aux];
			//Acrescentar padding de zeros
			for(;aux<len_16;aux++)enlace.data[7+aux]=0;//padding
			
			//Criptografia
			for(aux=0;aux<16;aux++)cipherval[aux]=INITVECTOR[aux];//copia IV

			for(ch=0;ch<(len_16/16);ch++)
			{
				for(aux=0;aux<16;aux++)enlace.data[7+ch*16+aux] = enlace.data[7+ch*16+aux]^cipherval[aux];//xor com cipherval
				AESEncode(&enlace.data[7+ch*16], (packet->cripto_scheme==0)?iBUSManager_GetChaveCripto(packet->receiver_add):(unsigned char *)CHAVEPADRAO);//criptografa o bloco
				for(aux=0;aux<16;aux++)cipherval[aux]=enlace.data[7+ch*16+aux];//preenche lastcipher com o valor original do bloco
			}
			
			iBUSenlace_Send(&enlace);
			
			free(enlace.data);//j� foi copiado, posso liberar a ram
			return 1;
		}
	}
	return 0;
}

void ir_Decrypt(struct iRedePack *pack)//descriptografa o pacote
{//S� descriptografa buffers multiplos de 16 
	unsigned char lastcipher[16];
	unsigned char copy[16];
	unsigned char aux, ch;//ch �h char, permite descriptografar at� 16*256 bytes.

	for(aux=0;aux<16;aux++)lastcipher[aux]=INITVECTOR[aux];//copia IV

	for(ch=0;ch<(pack->len/16);ch++)
	{
		for(aux=0;aux<16;aux++)copy[aux]=pack->cripto[ch*16+aux];//copia o valor original do bloco, antes de descriptografar
		AESDecode(&pack->cripto[ch*16],(pack->cripto_scheme==0)?iBUSManager_GetChaveCripto(pack->sender_add):(unsigned char *)CHAVEPADRAO);//descriptografa o bloco
		for(aux=0;aux<16;aux++)pack->cripto[ch*16+aux] = pack->cripto[ch*16+aux]^lastcipher[aux];//xor com lastcipher
		for(aux=0;aux<16;aux++)lastcipher[aux]=copy[aux];//preenche lastcipher com o valor original do bloco
	}
}

#ifdef SOU_REPETIDOR
unsigned char iBUSrede_JaRepetiu(struct iRedePack *pack)
{
	struct ir_filaRepeticao *fila;
	unsigned short int local_crc;
	unsigned char aux;
	
	local_crc=0;
	for(aux=0;aux<pack->len;aux++)local_crc+=pack->cripto[aux];//calculo crc
	
	fila = iBUSrede_FilaRepeticao;
	while(fila!=NULL)
	{
		if(fila->crc==local_crc)
		{//checksum igual? vamos ver os endere�os
			if( iBUSManager_CompararAddress(fila->pack->sender_add, pack->sender_add)
				&&iBUSManager_CompararAddress(fila->pack->receiver_add, pack->receiver_add))
			{
				return 1;//achei ele na fila, j� est� repetido
			}
		}
		fila = fila->next;//proximo
	}
	return 0;//chegou aqui, n�o encontrei similares, ent�o n�o repetiu esse
}

unsigned char iBUSrede_PacoteEhValido(struct iRedePack *pack)
{//chave privada, mas � conhecida nossa e o pacote est� ok.
	struct iRedePack *copia;
	unsigned char aux, ok;
	
	ok=0;
	copia = malloc(sizeof(struct iRedePack));
	if(copia!=NULL)
	{
		copia->cripto = malloc(pack->len);
		if(copia->cripto!=NULL)
		{
			copia->cripto_scheme=pack->cripto_scheme;
			copia->len=pack->len;
			for(aux=0;aux<pack->len;aux++)copia->cripto[aux] = pack->cripto[aux];
			for(aux=0;aux<3;aux++)copia->sender_add[aux] = pack->sender_add[aux];
			
			//Para chamar ir_Decrypt precisamos preencher o iRedePack com no m�nimo:
			//cripto, len, sender_add e cripto_scheme
			ir_Decrypt(copia);//descriptografa o pacote
			
			ok = iBUStransporte_isAValidyPack(copia->cripto);//testa se os dados s�o coerentes
			free(copia->cripto);
		}
		free(copia);
	}
	return ok;//qualquer problema melhor considerar inv�lido.
}

void iBUSrede_AdicionarParaRepeticao(struct iRedePack *pack)
{//vai salvar uma c�pia desse pacote na lista de repetidos e colocar na fila de repeti��o

	struct ir_filaRepeticao *repetido, *fila;
	unsigned char aux;
	
	repetido = malloc(sizeof(struct ir_filaRepeticao));//aloco mem�ria para receber
	if(repetido!=NULL)
	{
		repetido->pack = malloc(sizeof(struct iRedePack));//aloco mem�ria para receber
		if(repetido->pack!=NULL)
		{//temos espaco para receber? - Destrinchar o pacote!
			repetido->pack->cripto=malloc(pack->len);
			if(repetido->pack->cripto!=NULL)
			{//temos espaco pra guardar tudo?
				repetido->timeout=50;//5 segundos de timeout para essa pe�a
				repetido->next=NULL;//sou novo, logo sou o �ltimo da fila
				repetido->crc=0;//vai calcular em baixo
				
				//Copia o pacote
				repetido->pack->cripto_scheme=pack->cripto_scheme;
				repetido->pack->len=pack->len;
				repetido->pack->versao=pack->versao;
				for(aux=0;aux<3;aux++)
				{//copia os endere�os
					repetido->pack->receiver_add[aux] = pack->receiver_add[aux];
					repetido->pack->sender_add[aux] = pack->sender_add[aux];
				}
				for(aux=0;aux<pack->len;aux++)
				{
					repetido->pack->cripto[aux]=pack->cripto[aux];//copia os dados
					repetido->crc+=pack->cripto[aux];//e calcula o CRC
				}
				
				repetido->pack->ttl=pack->ttl-1;//conta um salto, quando chegar a zero n�o ser� mais repetido
				
				if(iBUSrede_FilaRepeticao==NULL)iBUSrede_FilaRepeticao=repetido;//fila vazia, assume inicio
				else
				{//varrer at� o fim da fila
					fila = iBUSrede_FilaRepeticao;
					while(fila->next!=NULL)fila = fila->next;//vai at� o fim
					fila->next = repetido;//adiciona
				}
			}
			else
			{
				free(repetido->pack);
				free(repetido);
			}
		}
		else free(repetido);
	}
}
#endif

