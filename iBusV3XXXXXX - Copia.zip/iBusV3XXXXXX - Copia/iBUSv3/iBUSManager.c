#define IBUSMANAGER_C

#include "Main\iBUSv3.h"
#include "iBUSManager.h"
#include "iBUSprotocolo.h"

#include "Sistema/system.h"	//defini��es do sistema "Target" padr�o

#include "Sistema/dynmem.h"
#include "Radio/Radio.h" //para trocar o canal

#include "Sistema/dynmem.h"


#ifdef SOU_SNIFFER
//#include "S2LP_SDK_Util.h"
#endif

struct option options[10];

unsigned char iBUSManager_CurrentChannel;
unsigned char iBUSManager_ContaDelay, iBUSManager_DelayMemory;

void iBUSManager_Shutdown(void);//prepara tudo para entrar em modo sleep

void iBUSManager_Init(void)
{
	unsigned char aux;
	
	for(aux=0;aux<10;aux++)
	{
		options[aux].opcao=0;//padding indica fim
	}
	
	iBUSManager_CurrentChannel=0;
	iBUSManager_DelayMemory=0;
}

void iBUSManager_Main(void)
{//chamado a cada 1ms
	static unsigned char decimos_sec=0;
	
	if(iBUSManager_ContaDelay!=255)iBUSManager_ContaDelay++;
		
	decimos_sec++;
	if(decimos_sec>=100)
	{
		decimos_sec=0;
		
		system_TimeStampTick();//informa o sistema para avan�ar no tempo dos timestamps
		
	}
}

void iBUSManager_InformarEstado(struct ControleEstado estado)
{
}

unsigned char iBUSManager_CompararAddress(unsigned char *add1, unsigned char *add2)
{
	unsigned char aux;
	for(aux=0;aux<3;aux++)
	{
		if(add1[aux]!=add2[aux])return 0;
	}
	return 1;
}

unsigned char iBUSManager_IsMyReceptor(unsigned char *rec_address)
{
	return system_IsMyReceptor(rec_address);
}

unsigned char *iBUSManager_GetChaveCripto(unsigned char *rec_address)
{//retorna a chave criptografica privada definida no cadastro com o receptor
	return system_GetChaveCripto(rec_address);
}

unsigned long iBUSManager_GetTimestampSincronizado(struct iTransportePack *pack)
{
	return system_GetTimestampSincronizado(pack->receiver_add);
}

unsigned char iBUSManager_ValidaTimestamp(struct iTransportePack *received)
{
	#ifdef SOU_RECEPTOR
	#warning "implementar atualiza��o de timestamp se o equipamento estiver dessincronizado e pertencer ao receptor"
	#endif
	return system_ValidaTimestamp(received->timestamp, received->receiver_add); //perif�ricos s� aceitam timestamp coerente
}

unsigned char iBUSManager_TestaSeguranca(unsigned char opcao, unsigned char cript_scheme)
{
	unsigned char inseguro=0x01;//a principio n�o tratar
	
	#warning "implementar: seguran�a analisando a op��o e tipo de criptografia"
	//Para incrementar a seguran�a tamb�m podemos ver se o endere�o veio correto ou multicast
	
	/*
OP��O: 0x06 ( Estado do controle remoto recebido)
OP��O: 0x07 (Aberto para cadastros)
OP��O: 0x08 (Requisi��o de chave privada) 
OP��O: 0x09 (Estado do sensor)
	*/
	
	if(cript_scheme==0)
	{//chave �nica!
		if(
			//(opcao==)||
			(opcao==IBUS_PADDING)||
			(opcao==IBUS_CONTROLE_REMOTO_PRESENTE)||
			(opcao==IBUS_CHAVE_CRIPTOGRAFICA_PRIVADA)||
			(opcao==IBUS_RECEPTOR_PRESENTE)||
			(opcao==IBUS_CADASTRO_ACEITO)||
			(opcao==IBUS_ESTADO_CONTROLE_REMOTO) ||
			(opcao==IBUS_ESTADO_RECEBIDO)
		){
			inseguro=0;
		}
	}
	if(cript_scheme==1)
	{//chave padr�o
		if(
			//(opcao==)||
			(opcao==IBUS_PADDING)||
			(opcao==IBUS_CONTROLE_REMOTO_PRESENTE)||
			(opcao==IBUS_CHAVE_CRIPTOGRAFICA_PRIVADA)
		){
			inseguro=0;
		}
	}
	return inseguro;//se n�o for seguro n�o trata
}
#warning "sou snifer"
extern unsigned char menulido;
#ifdef SOU_SNIFFER
extern unsigned char menulido;
#endif
void iBUSManager_TrataOption(struct iTransportePack *dados, struct option opcao)
{
	
	#ifdef SOU_RECEPTOR
	struct iTransportePack resposta;
	/**
	Sempre que recebe de algum perif�rico seu, vale a pena salvar o n�vel de bateria e sinal, para futuras refer�ncias
	**/
	//terminal_Printf_E("TrataOption");
	#endif
	#warning "timestamp correto usa?"
//	unsigned char aux;
//	unsigned long int timestamp_correto;
	
	if(iBUSManager_TestaSeguranca(opcao.opcao, dados->cript_scheme))return;//se n�o for seguro n�o trata

	#ifdef SOU_RECEPTOR
	//Preenche campos que devem ficar na resposta
	resposta.rssi = dados->rssi;//informa o n�vel de sinal do comando que gerou essa resposta.
	#endif
	
	switch(opcao.opcao)
	{
	#ifdef SOU_RECEPTOR
		case IBUS_CONTROLE_REMOTO_PRESENTE://OP��O: 0x01 (Controle Remoto Presente)
			/**Como deve funcionar as coisas aqui:
		a) Verificar se este controle est� pendente de cadastro. Se estiver retornar pacote 0x02
		b) Se o receptor estiver aberto a cadastro, ent�o retorna 0x02, mesmo que o controle j� tenha sido cadastrado, permitindo o recadastro em caso de reset
		c) Caso o receptor n�o tenha ele como pendente, mas ele fa�a parte da rede (deveria conhecer a chave cripto) retorna 0x03
		d) Se o controle n�o faz parte do receptor e ele n�o est� aceitando cadastros, ignora esse pacote.		
			**/
		
		/*
		//primeira op��o ser� para informar timestamp
		options[0].opcao=IBUS_INFORMA_TIMESTAMP;
		options[0].tamanho=4;
		options[0].dado=malloc(4);
		
		if(options[0].dado==NULL)return;//nao aloca n�o informa
		timestamp_correto = system_GetTimestampSincronizado(dados->receiver_add);
		options[0].dado[0] = (timestamp_correto>>(8*3))&0xFF;
		options[0].dado[1] = (timestamp_correto>>(8*2))&0xFF;
		options[0].dado[2] = (timestamp_correto>>(8*1))&0xFF;
		options[0].dado[3] = (timestamp_correto>>(8*0))&0xFF;
		*/
		
		//APENAS COMO TESTE, vou devolver alguma coisa ao controle remoto
		if(menulido=='c')
		{
			
			resposta.aplicacao=NULL;		
			resposta.aplic_len=0;
			resposta.cript_scheme=1;
			resposta.id=dados->id;//mesmo id recebido, ou seja, vou confirmar o pacote
			//resposta.rssi = dados->rssi;//informa o n�vel de sinal do comando que gerou essa resposta.
			resposta.modo_transmissao=0;//Responde no canal que estou ativo
			for(aux=0;aux<3;aux++)resposta.receiver_add[aux]=dados->receiver_add[aux];//para quem � a resposta (o endereco de receiver na recep��o eh guardado ao contr�rio)
			
			resposta.tipo=PACOTE_TIPO_INFORMACAO;//PACOTE_TIPO_COMANDO;//demanda um PACOTE_TIPO_RESPOSTA
			
			//N�o adianta enviar PACOTE_TIPO_COMANDO para um controle remoto, 
			//Se o controle remoto n�o receber, ir� requisitar de novo ou entrar em sleep, o que torna
			//inocuo tentar retransmitir. O receptor s� � eficiente no envio de comandos para o repetidor
			//todos os outros podem estar dormindo e n�o adianta repetir.
			
			resposta.timestamp = dados->timestamp;//salva o timestamp recebido para que Transporte possa diferenciar repeti��es de retransmiss�es
			
			options[0].opcao=IBUS_CHAVE_CRIPTOGRAFICA_PRIVADA;
			options[0].tamanho=16;
			
			options[0].dado=malloc(16);
			if(options[0].dado!=NULL)
			{
				for(aux=0;aux<16;aux++)options[0].dado[aux]=DEBUGKEY[aux];
				options[1].opcao=IBUS_PADDING;
				iBUSAplicacao_sendOptions(&resposta, options);//responde o cara
				
				free(options[0].dado);
			}
		}
		else{
			resposta.aplicacao=NULL;		
			resposta.aplic_len=0;
			resposta.cript_scheme=0;
			resposta.id=dados->id;//mesmo id recebido, ou seja, vou confirmar o pacote
			resposta.modo_transmissao=1;//Channel Hopping, just for future tests
			for(aux=0;aux<3;aux++)resposta.receiver_add[aux]=dados->receiver_add[aux];//para quem � a resposta (o endereco de receiver na recep��o eh guardado ao contr�rio)
			
			resposta.tipo=PACOTE_TIPO_INFORMACAO;//informo que estou presente, assim ele pode atualizar seu timestamp
			resposta.timestamp = dados->timestamp;//salva o timestamp recebido para que Transporte possa diferenciar repeti��es de retransmiss�es
			
			options[0].opcao=IBUS_RECEPTOR_PRESENTE;
			options[0].tamanho=0;
			options[0].dado=NULL;
			options[1].opcao=IBUS_PADDING;
			iBUSAplicacao_sendOptions(&resposta, options);//responde o cara
		}
		//free(options[0].dado);//desaloca a memoria reservada a primeira op��o		
		break;
		case IBUS_ESTADO_CONTROLE_REMOTO://recebi o estado do controle remoto ! tratar
		resposta.aplicacao=NULL;		
		resposta.aplic_len=0;
		resposta.cript_scheme=0;
		resposta.id=dados->id;//mesmo id recebido, ou seja, vou confirmar o pacote
		//resposta.rssi = dados->rssi;//informa o n�vel de sinal do comando que gerou essa resposta.
		resposta.modo_transmissao=0;//ultimo canal que deu certo
		for(aux=0;aux<3;aux++)resposta.receiver_add[aux]=dados->receiver_add[aux];//para quem � a resposta (o endereco de receiver na recep��o eh guardado ao contr�rio)
		
		resposta.tipo=PACOTE_TIPO_RESPOSTA;
		resposta.timestamp = dados->timestamp;//salva o timestamp recebido para que Transporte possa diferenciar repeti��es de retransmiss�es
		
		options[0].opcao=IBUS_ESTADO_RECEBIDO;
		options[0].tamanho=0;
		options[0].dado=NULL;
		options[1].opcao=IBUS_PADDING;
		iBUSAplicacao_sendOptions(&resposta, options);//responde o cara
		
			break;
	#elif defined(IBUSV3_CR)
		case IBUS_CHAVE_CRIPTOGRAFICA_PRIVADA://recebi a chave criptogr�fica de algum receptor, informar o sistema
		system_aceitaCadastro(dados, opcao.dado);	
		break;
		case IBUS_RECEPTOR_PRESENTE:
		system_receptorPresente(dados);
		break;
		case IBUS_INFORMA_TIMESTAMP://meu timestamp est� errado, ajustar!
		timestamp_correto = 0;
		for(aux=0;aux<4;aux++)
		{
			timestamp_correto*=0x100;
			timestamp_correto += opcao.dado[aux];
		}
		system_atualizarTimestamp(dados->receiver_add, timestamp_correto);
		break;
	#endif
	}
}

void iBUSManager_AplicacaoResult(enum RESULTS result)
{
	#ifdef SOU_SNIFFER
	//terminal_Printf_E("\r\nAPLICACAO RESULT: ");
	const char resultados[6][33]={
		"IE_REC_AB",//"IE_RECEPCAO_ABORTADA",
		"IE_REC_DC",//"IE_RECEPCAO_DESCARTADA",
		"IE_TX_OK",//"IE_TRANSMISSAO_OK",
		"IE_TX_SUC",//"IT_TRANSMISSAOCONCLUIDASUCESSO",  //indica que transmitiu e recebeu confirma��o
		"IE_TX_ERR",//"IT_TRANSMISSAOESTOUROUTENTATIVAS", //indica que desistiu de enviar o pacote
	};
	//terminal_Printf_E(resultados[result]);
	#endif
	
	#ifdef IBUSV3_CR
	if(result == IBUSTRANSPORTE_RESULT_TRANSMISSAOCONCLUIDASUCESSO)
	{
		iBUSManager_DelayMemory = iBUSManager_ContaDelay;//salva quanto tempo levou para esse sucesso
	}		
	
	system_resultado(result);
	#endif
	
}

void iBUSManager_Wakeup(void)//acorda sistema 
{
	iBUSAplicacao_Wakeup();
}

void iBUSManager_Shutdown(void)//prepara tudo para entrar em modo sleep
{
	iBUSAplicacao_Shutdown();
}

/***
iBUSManager_AnunciarControlePresente:
	O controle envia no modo channel hopping, com criptografia padr�o um anuncio que est� presente
	Como � comando, repetir� 4 vezes at� recebe respostas
***/
void iBUSManager_AnunciarControlePresente(void)
{
	unsigned char aux;
	struct iTransportePack anuncio;
	
	anuncio.aplicacao=NULL;		
	anuncio.aplic_len=0;
	anuncio.cript_scheme=1; //esquema de criptografia padr�o de conhecimento de todos, todos podem ver esse pacote
	anuncio.id=0;//como � comando, n�o preciso me preocupar com ID, transporte define um para mim.
	anuncio.rssi = 0;//como � multicast, o sinal n�o interessa
	anuncio.modo_transmissao=1;//Channel Hopping, para transmitir nos dois canais at� que alguem responda
	for(aux=0;aux<3;aux++)anuncio.receiver_add[aux]=MULTICAST_RECEPTORES[aux];//para todos os receptores ao alcance
	
	anuncio.tipo=PACOTE_TIPO_INFORMACAO;//PACOTE_TIPO_COMANDO;//como � um comando que n�o tem resposta, vai for�ar repeti��o nos dois canais.
	anuncio.timestamp = 0;//comando n�o interessa o timestamp
	
	options[0].opcao=IBUS_CONTROLE_REMOTO_PRESENTE;
	options[0].tamanho=0;
	options[0].dado=NULL;
	options[1].opcao=IBUS_PADDING;
	iBUSAplicacao_sendOptions(&anuncio, options);//informa que estou aqui
}

void iBUSManager_CadastroAceito(struct iTransportePack *pack)
{
	unsigned char aux;
	struct iTransportePack anuncio;
	
	anuncio.aplicacao=NULL;		
	anuncio.aplic_len=0;
	anuncio.cript_scheme=0; //esquema de criptografia chave �nica
	anuncio.id=pack->id;//resposta
	anuncio.rssi = pack->rssi;//responde o sinal recebido
	anuncio.modo_transmissao=0;//Ultimo canal que deu certo
	for(aux=0;aux<3;aux++)anuncio.receiver_add[aux]=pack->receiver_add[aux];//para todos os receptores ao alcance
	
	anuncio.tipo=PACOTE_TIPO_RESPOSTA;//
	anuncio.timestamp = pack->timestamp;
	
	options[0].opcao=IBUS_CADASTRO_ACEITO;
	options[0].tamanho=0;
	options[0].dado=NULL;
	options[1].opcao=IBUS_PADDING;
	iBUSAplicacao_sendOptions(&anuncio, options);//responde o cara
}

void iBUSManager_BotaoPressionado(struct iTransportePack *pack, unsigned char botao)
{
	unsigned char aux;
	unsigned short int qtd;
	struct iTransportePack anuncio;
	
	anuncio.aplicacao=NULL;		
	anuncio.aplic_len=0;
	anuncio.cript_scheme=0; //esquema de criptografia do receptor (chave �nica)
	anuncio.id=0;//como � comando, n�o preciso me preocupar com ID, transporte define um para mim.
	anuncio.rssi = pack->rssi;//se tem sinal recebido, informa
	anuncio.modo_transmissao=0;//ultimo canal que deu certo
	for(aux=0;aux<3;aux++)anuncio.receiver_add[aux]=pack->receiver_add[aux];//para o receptor que se apresentou
	
	anuncio.tipo=PACOTE_TIPO_COMANDO;//como � um comando que n�o tem resposta, vai for�ar repeti��o nos dois canais.
	anuncio.timestamp = 0;//comando n�o interessa o timestamp
	
	//[SUPERVISAO][DELAY][DIAS_BATERIA (2 bytes)][NUM_TRANSMISSOES (3 bytes)][ESTADO][ESTADO][ESTADO][ESTADO]
	options[0].opcao=IBUS_ESTADO_CONTROLE_REMOTO;
	options[0].tamanho=11;
	options[0].dado=malloc(11);
	
	if(options[0].dado!=NULL)
	{
		#warning "implementar supervis�o e delay e bateria, e transmiss�es"
		options[0].dado[0]=0;//supervis�o n�o implementada ainda
		
		options[0].dado[1]=iBUSManager_DelayMemory;//delay do ultimo comando
		
		options[0].dado[2]=0;//dias com essa bateria
		options[0].dado[3]=0;
		
		qtd = iBUSenlace_GetQtdPackets();
		options[0].dado[4]=0;//num transmiss�es com essa bateria
		options[0].dado[5]=qtd>>8;
		options[0].dado[6]=qtd&0xFF;

		//Envia como est�o os bot�es
		for(aux=0;aux<4;aux++)
		{
			if(((0x01<<aux)&botao)!=0)options[0].dado[7+aux]=0x80;//bot�o pressionado
			else options[0].dado[7+aux]=0x7F;//bot�o solto a muito tempo
		}
	
		options[1].opcao=IBUS_PADDING;
		
		iBUSManager_ContaDelay=0;//conta quanto tempo levar� para ter resposta deste comando.
		
		iBUSAplicacao_sendOptions(&anuncio, options);
		
		free(options[0].dado);//jah copiou, libera
	}
}
void iBUSManager_EnviaDado(unsigned char *dados, unsigned char len)
{
	unsigned char aux;
	struct iTransportePack anuncio;
	
	anuncio.aplicacao=NULL;		
	anuncio.aplic_len=0;
	anuncio.cript_scheme=1; //esquema de criptografia padr�o de conhecimento de todos, todos podem ver esse pacote
	anuncio.id=0;//como � comando, n�o preciso me preocupar com ID, transporte define um para mim.
	anuncio.rssi = 0;//como � multicast, o sinal n�o interessa
	anuncio.modo_transmissao=0;//Channel Hopping, para transmitir nos dois canais at� que alguem responda
	for(aux=0;aux<3;aux++)anuncio.receiver_add[aux]=MULTICAST_RECEPTORES[aux];//para todos os receptores ao alcance
	
	anuncio.tipo=PACOTE_TIPO_INFORMACAO;//PACOTE_TIPO_COMANDO;//como � um comando que n�o tem resposta, vai for�ar repeti��o nos dois canais.
	anuncio.timestamp = 0;//comando n�o interessa o timestamp
	
	options[0].opcao=IBUS_INFORMA_ADC;
	options[0].tamanho=len;
	options[0].dado=malloc(len);
	options[1].opcao=IBUS_PADDING;
		
	for(aux=0;aux<len;aux++)options[0].dado[aux]=dados[aux];
	iBUSAplicacao_sendOptions(&anuncio, options);//responde o cara
	
	free(options[0].dado);
	

}

void iBUSManager_ToogleChannel(void)//for�a a pilha a trocar de um canal para o outro
{
	if(iBUSManager_CurrentChannel==0)iBUSManager_CurrentChannel=1;
	else iBUSManager_CurrentChannel=0;
	
	radio_SetChannel(iBUSManager_CurrentChannel);
}

