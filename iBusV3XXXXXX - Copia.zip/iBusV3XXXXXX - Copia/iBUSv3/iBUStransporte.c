#define IBUSTRANSPORTE_C

#include "Main\iBUSv3.h"
#include "iBUSv3/iBUSManager.h"
#include "iBUSv3/iBUSAplicacao.h"
#include "iBUStransporte.h"

#include "Sistema/System.h"
#include "Sistema/dynmem.h"

#ifdef SOU_SNIFFER
//#include "S2LP_SDK_Util.h"
#endif

struct iTransportePack *iBUSaTransmitir;
struct iTransportePack *iBUSrecebidos;

unsigned char lastID_transmitido;

void iBUStransporte_Init(void)
{
	iBUSaTransmitir=NULL;
	iBUSrecebidos=NULL;
	
	lastID_transmitido=0;
}

void iBUStransporte_Loop(void) //chamar em tempo de loop
{
	struct iTransportePack *fila;
	struct iRedePack pack;
	unsigned char aux;
	unsigned long timestamp;
	
	fila=iBUSaTransmitir;
	while(fila!=NULL)
	{
		if(fila->maquina==0)
		{//t� precisando transmitir?
			if(iBUSrede_canIsend())
			{
				//Vou transmitir!				
				timestamp=iBUSManager_GetTimestampSincronizado(fila);//pega o timestamp conforme o endere�o do receptor de destino
				
				for(aux=0;aux<3;aux++)
				{
					pack.receiver_add[aux]=fila->receiver_add[aux];
					pack.sender_add[aux]=fila->sender_add[aux];
				}
				pack.cripto_scheme=fila->cript_scheme;
				pack.len = 5 + fila->aplic_len;//aplica��o mais tipo/id (1 byte) e timestamp(4 bytes)
				
				pack.cripto = malloc(pack.len);
				
				if(pack.cripto!=NULL)
				{//alocado?
					//Preenche com o header da camada de transporte
					pack.cripto[0] = (fila->tipo<<4)|fila->id;
					pack.cripto[1] = (timestamp>>(8*3))&0xFF;
					pack.cripto[2] = (timestamp>>(8*2))&0xFF;
					pack.cripto[3] = (timestamp>>(8*1))&0xFF;
					pack.cripto[4] = (timestamp>>(8*0))&0xFF;
					for(aux=0;aux<pack.len;aux++)pack.cripto[5+aux]=fila->aplicacao[aux];
	
					iBUSrede_Send(&pack);
					
					free(pack.cripto);//libera a mem�ria
					
					//Verifica como sera o tratamento do pacote
					if((fila->tipo==PACOTE_TIPO_RESPOSTA)||(fila->tipo==PACOTE_TIPO_INFORMACAO))
					{
						fila->maquina=2;//aguardando 5 segundos para descarte
						fila->timeout=500;//RESPOSTA e INFORMACAO, mantenho na mem�ria por 5 segundos para detecta retransmiss�es de comando
					}
					else if(fila->tipo==PACOTE_TIPO_COMANDO)
					{
						fila->maquina=1;//aguardando resposta
						fila->timeout=(IBUSTRANSPORTE_TIMEOUT_RTX/10);// 270ms, era 300ms (+/-10ms) para obter resposta.
					}
					else
					{
						//n�o deveria cair aqui
						fila->maquina=2;//para descarte
						fila->timeout=0;//descarta isso o quanto antes
					}
				}
			}
			break;//cai fora do loop, n�o adianta ver os outros pacotes (Vao sendo transmitidos na ordem e que � chamado o Send)
		}
		fila = fila->next;//proximo
	}
}

void iBUStransporte_Main(void) //chamar a cada 1ms
{
	struct iTransportePack *fila, *anterior;
	static unsigned char decimos_sec=0;
	
	decimos_sec++;
	if(decimos_sec>=100)
	{
		decimos_sec=0;
		
		//tratar o que fazer a cada 100ms
	}
	
	if((decimos_sec%10)==0)//a cada 10ms
	{//0,10,20,30,40,50,60,70,80,90
		
		fila=iBUSaTransmitir;
		while(fila!=NULL)
		{
			if(fila->maquina==1)
			{//est� aguardando resposta?
				if(fila->timeout==0)
				{//estourou o timer
					fila->retx_cnt++;
					if(fila->retx_cnt>=4)
					{//ja transmiti 4 vezes. j� era. Estou fazendo isso a 1200ms no m�nimo
						fila->maquina=2;//para descarte
						fila->timeout=0;//descarta isso o quanto antes
						iBUSAplicacao_transporteResult(IBUSTRANSPORTE_RESULT_TRANSMISSAOESTOUROUTENTATIVAS);
					}
					else
					{//ainda podemos tentar enviar de novo?
						fila->maquina=0;//coloca na fila de transmiss�o novamente
						if(fila->modo_transmissao==1)
						{//Modo de transmiss�o Channel Hopping? Trocar de canal
							iBUSManager_ToogleChannel();
						}
					}
				}
				else fila->timeout--;//conta tempo para retransmiss�o
			}
			
			if(fila->maquina==2)
			{//aguardando para descarte
				if(fila->timeout==0)
				{//temos que apaga-lo
					if(fila==iBUSaTransmitir)
					{//eh o primeiro da fila a se apagar
						iBUSaTransmitir=fila->next;//transformo o pr�ximo em primeiro da fila e remove o running da fila
						anterior = NULL;//marca que apagamos o primeiro
					}
					else
					{
						anterior->next = fila->next;//remove o running da fila
					}
					//Desaloco as mem�rias desse pacote
					free(fila->aplicacao);
					free(fila);
					fila=anterior;
				}
				else fila->timeout--;//conta tempo para retransmiss�o
			}
			
			//Pr�ximo da fila
			if(fila==NULL)fila = iBUSaTransmitir;
			else
			{
				anterior = fila;
				fila = fila->next;
			}
		}
		
		//Descarta recebidos muito antigos
		fila=iBUSrecebidos;
		while(fila!=NULL)
		{
			if(fila->timeout==0)
			{//estourou o timer
					if(fila==iBUSrecebidos)
					{//eh o primeiro da fila a se apagar
						iBUSrecebidos=fila->next;//transformo o pr�ximo em primeiro da fila e remove o running da fila
						anterior = NULL;//marca que apagamos o primeiro
					}
					else
					{
						anterior->next = fila->next;//remove o running da fila
					}
					//Desaloco as mem�rias desse pacote
					free(fila->aplicacao);
					free(fila);
					fila=anterior;
			}
			else fila->timeout--;//conta tempo para retransmiss�o
			
			//Pr�ximo da fila
			if(fila==NULL)fila = iBUSrecebidos;
			else
			{
				anterior = fila;
				fila = fila->next;
			}
		}
	}
}

unsigned char iBUStransporte_isAValidyPack(unsigned char *cripto)
{//Verifica se buf contem um pacote de transporte v�lido.
	//Futuramente podemos pedir para camada superior avaliar op��es...
	if(cripto[0]<=0x2F)return 1; //TIPO 0,1 e 2 e ID 0 a F. - Tudo v�lido
	return 0;
}

struct iTransportePack *iBUStransporte_FindPack(struct iTransportePack *fila, unsigned char *receiver_add,unsigned char id, unsigned char tipo)
{
	while(fila!=NULL)
	{
		if((fila->id==id)&&(fila->tipo==tipo)&&(iBUSManager_CompararAddress(fila->receiver_add,receiver_add)))
		{
			break;//achou
		}
		
		//Pr�ximo da fila
		if(fila==NULL)fila = iBUSaTransmitir;
		else
		{
			fila = fila->next;
		}
	}
	return fila;//retorna o encontrado ou NULL se n�o achou
}


void iBUStransporte_receiveDecripto(struct iRedePack *dados)
{
	unsigned char aux;
	struct iTransportePack *received, *fila, *find;
	
	if(iBUStransporte_isAValidyPack(dados->cripto))
	{//o pacote � v�lido (bem formado)
		received = malloc(sizeof(struct iTransportePack));
		if(received!=NULL)
		{
			received->tipo=dados->cripto[0]>>4;
			received->id=dados->cripto[0]&0x0F;
			received->timestamp=dados->cripto[1];
			received->timestamp<<=8;
			received->timestamp|=dados->cripto[2];
			received->timestamp<<=8;
			received->timestamp|=dados->cripto[3];
			received->timestamp<<=8;
			received->timestamp|=dados->cripto[4];
			
			received->rssi = dados->rssi;

			//Termina de copiar o pacote
			for(aux=0;aux<3;aux++)
			{
				//A invers�o � para poder usar a mesma fun��o iBUStransporte_FindPack tanto para pacotes transmitidos como recebidos.
				received->receiver_add[aux] = dados->sender_add[aux];//inverte sender com receiver ao guardar na memoria
				received->sender_add[aux] = dados->receiver_add[aux];//inverte sender com receiver ao guardar na memoria					
			}
			
			//Verificar se o timestamp � valido
			if(
				(iBUSManager_ValidaTimestamp(received)) //timestamp coerente
				||
				iBUSManager_CompararAddress((unsigned char *)MULTICAST_DISPOSITIVOS, dados->receiver_add)
				||
				iBUSManager_CompararAddress((unsigned char *)MULTICAST_RECEPTORES, dados->receiver_add) //endere�os multicast, n�o importa timestamp
			)
			{//O timestamp est� dentro do esperado? Aceito o pacote
				
				fila = iBUStransporte_FindPack(iBUSrecebidos,received->receiver_add,received->id,received->tipo);
				if(fila!=NULL)
				{//j� recebi esse pacote antes
					if(fila->tipo==PACOTE_TIPO_COMANDO)
					{//eh um comando que j� recebi? Vamos ver se tenho uma resposta j� dada para devolver
						find = iBUStransporte_FindPack(iBUSaTransmitir,fila->receiver_add,fila->id,PACOTE_TIPO_RESPOSTA);
						if(find!=NULL)
						{//encontramos a resposta j� enviada?
							if(received->timestamp!=find->timestamp)//timestamp_recebido
							{//s� vou repetir o pacote se recebi outra requisi��o igual. Se for a mesma, ent�o � apenas uma repeti��o da camada de rede
								//em iBUSaTransmitir o timestamp salvo n�o � o que foi enviado, e sim o que foi recebido para essa resposta
								//Se n�o for resposta o valor do timestamp provavelmente � lixo.
								
								find->timestamp = received->timestamp;//atualiza, vai que tem que retransmitir de novo.

								//prepara para retx a mesma resposta (retransmiss�o de resposta)
								find->maquina=0;
								find->timeout=0;
							}
						}
					}
					free(received);
				}
				else
				{//pacote novo, salvar ele na mem�ria
					//NAO DESALOCO O PACOTE, vou guardar, o timeout que desaloca depois.
					
					//Termina de preencher
					received->aplic_len=dados->len-5;
					received->aplicacao=malloc(received->aplic_len);
					if(received->aplicacao!=NULL)
					{//tem espa�o para copiar esse pacote?
						for(aux=0;aux<received->aplic_len;aux++)received->aplicacao[aux]=dados->cripto[5+aux];
						
						received->cript_scheme = dados->cripto_scheme;
						received->next=NULL;//sou o ultimo da fila
						
						received->timeout=500;//espero 5 segundos e depois cai fora
						if(iBUSrecebidos==NULL)iBUSrecebidos=received;
						else
						{
							fila = iBUSrecebidos;
							while(fila->next!=NULL)fila=fila->next;//vai ate�o fim da fila
							fila->next=received;
						}
						
						if(received->tipo==PACOTE_TIPO_RESPOSTA)
						{//Se for uma resposta, procuro na fila de enviados para marcar como transmitido
							find = iBUStransporte_FindPack(iBUSaTransmitir,received->receiver_add,received->id,PACOTE_TIPO_COMANDO);
							if(find!=NULL)
							{
								if(find->maquina<=1)
								{//ainda estava aguardando resposta? Ou pior, j� estava marcado para retransmiss�o(0)?
									find->maquina=2;//marca para descarte
									find->timeout=500;//descarta daqui 5 segunods
									
									//Avisa camada superior que deu certo a transmiss�o
									iBUSAplicacao_transporteResult(IBUSTRANSPORTE_RESULT_TRANSMISSAOCONCLUIDASUCESSO);
								}
								else
								{
									find=NULL;//DEBUG
								}
							}
						}
						
						iBUSAplicacao_receive(received);//manda tratar o pacote recebido
					}
					else free(received);
				}
			}
			else free(received);
		}//else sem espa�o para alocar o pacote
	}
}

void iBUStransporte_redeResult(enum RESULTS result)
{
	iBUSAplicacao_transporteResult(result);
}

void iBUStransporte_Wakeup(void)
{//acorda sistema 
	iBUSrede_Wakeup();
}

extern void iBUStransporte_Shutdown(void)
{//prepara tudo para entrar em modo sleep
	struct iTransportePack *prox, *fila;
	
	iBUSrede_Shutdown();

	//libera a fila toda de repeticao	
	fila=iBUSaTransmitir;
	while(fila!=NULL)
	{
		prox = fila->next;
		//Desaloco as mem�rias desse pacote
		free(fila->aplicacao);
		free(fila);		
		fila = prox;
	}
	iBUSaTransmitir=NULL;
	
	fila=iBUSrecebidos;
	while(fila!=NULL)
	{
		prox = fila->next;
		//Desaloco as mem�rias desse pacote
		free(fila->aplicacao);
		free(fila);		
		fila = prox;
	}
	iBUSrecebidos=NULL;
}

//Interface com camadas superiores
unsigned char iBUStransporte_Send(struct iTransportePack *packet)
{//envia um pacote na camada de rede, retorna 0 se ok
	unsigned char aux;
	struct iTransportePack *copia, *fila;
	
	copia = malloc(sizeof(struct iTransportePack));
	if(copia!=NULL)
	{
		copia->aplicacao=malloc(packet->aplic_len);//tenta achar espa�o para guardar o buffer de aplica��o
		if(copia->aplicacao!=NULL)
		{
			for(aux=0;aux<3;aux++)
			{//copia os endere�os
				copia->receiver_add[aux] = packet->receiver_add[aux];
				//copia->sender_add[aux] = packet->sender_add[aux];
			}
			system_macAddress(copia->sender_add);//meu endere�o de envio � fixo
			
			copia->tipo = packet->tipo;
			for(aux=0;aux<packet->aplic_len;aux++)copia->aplicacao[aux]=packet->aplicacao[aux];
			copia->aplic_len = packet->aplic_len;
			copia->cript_scheme = packet->cript_scheme;
			copia->modo_transmissao = packet->modo_transmissao;
			
			copia->next=NULL;//estou no fim da fila
			copia->maquina=0;//entra no estado aguardando para transmitir
			copia->retx_cnt=0;//n�o retransmitiu nenhuma vez ainda
			copia->timeout=0;//nenhum timer correndo ainda
			
			if(copia->tipo==PACOTE_TIPO_RESPOSTA)
			{
				copia->id = packet->id;//resposta � direcionada a um identificador
			}
			else
			{//comandos e informa��es, tentar gerar id �nico.
				//calculando ID
				lastID_transmitido++;
				if(lastID_transmitido>15)lastID_transmitido=0;
				copia->id = lastID_transmitido;//o ID � �nico entre retransmiss�es
			}
			
			//PARA identificar se j� respondi a essa transmiss�o, a camada de aplica��o pode me informar
			//o Timestamp do pacote recebido, que salvo aqui (n�o ser� esse o usado para envio, o de envio � calculado na hora de transmitir)
			//Assim se eu receber um pacote de um repetidor al�m de identificar que j� o recebi, n�o preciso retransmitir a resposta,
			//se o timestamp for igual, pois � s� uma repeti��o e o pacote j� chegou pra mim. Caso o equipamento nao
			//receba, ele ir� repetir o pacote com novo timestamp, da� eu irei repetir a resposta.
			//   Caso a aplica��o n�o saiba o timestamp, basta retornar tudo zerado...
			copia->timestamp=packet->timestamp;//salva o timestamp recebido (se for resposta) para identificar repeti��es de pacotes
			
			
			if(iBUSaTransmitir==NULL)iBUSaTransmitir=copia;//fila vazia, assume inicio
			else
			{//varrer at� o fim da fila
				fila = iBUSaTransmitir;
				while(fila->next!=NULL)fila = fila->next;//vai at� o fim
				fila->next = copia;//adiciona
			}
			return 1;//conseguiu alocar e preencher para a fila de transmiss�o
		}
		else
		{
			free(copia);//nao deu pra alocar tudo ent�o desaloca o que conseguiu
		}
	}
	return 0;//sem memoria
}

