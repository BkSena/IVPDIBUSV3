#ifndef IBUSMANAGER_H
#define IBUSMANAGER_H

#include "iBUSAplicacao.h"

#ifdef IBUSV3_CR
#include "Sistema/teclas.h"
#endif

struct ControleEstado
{
	unsigned char intervalo_supervisao;
	unsigned char delay;
	unsigned char dias_bateria;
	unsigned char num_transmissoes;
	#ifdef IBUSV3_CR
	struct Botao estado[TECLAS_QTDTOTAL];
	#endif
};

#ifndef IBUSMANAGER_C
extern void iBUSManager_Init(void);
extern void iBUSManager_Main(void);//chamado a cada 1ms

extern unsigned char *iBUSManager_GetChaveCripto(unsigned char *rec_address);//retorna a chave criptografica privada definida no cadastro com o receptor
extern unsigned char iBUSManager_CompararAddress(unsigned char *add1, unsigned char *add2);
extern unsigned char iBUSManager_IsMyReceptor(unsigned char *rec_address);//retorna diferente de 0xFF se eh um receptor v�lido, sen�o retorna 0xFF

extern unsigned long iBUSManager_GetTimestampSincronizado(struct iTransportePack *pack);
extern unsigned char iBUSManager_ValidaTimestamp(struct iTransportePack *received);

/**
iBUSManager_TrataOption
	dados: Deve conter o pacote completo da camada de transporte recebido. Incluindo necess�riamente o timestamp
	opcao: uma das op��es recebidas no pacote. Fazer uma chamada para cada op��o recebida.
**/
extern void iBUSManager_TrataOption(struct iTransportePack *dados, struct option opcao);
extern void iBUSManager_AplicacaoResult(enum RESULTS result);

extern void iBUSManager_Wakeup(void);//acorda sistema 
extern void iBUSManager_Shutdown(void);//prepara tudo para entrar em modo sleep

//Fun��es de aplica��o
extern void iBUSManager_InformarEstado(struct ControleEstado estado);
extern void iBUSManager_AnunciarControlePresente(void);
extern void iBUSManager_CadastroAceito(struct iTransportePack *pack);
extern void iBUSManager_BotaoPressionado(struct iTransportePack *pack, unsigned char botao);
extern void iBUSManager_ToogleChannel(void);//for�a a pilha a trocar de um canal para o outro


extern void iBUSManager_EnviaDado(unsigned char *dados, unsigned char len); //utilizado para teste


#endif

#endif
