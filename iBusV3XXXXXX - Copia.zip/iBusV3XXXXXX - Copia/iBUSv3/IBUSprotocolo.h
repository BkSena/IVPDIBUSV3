#ifndef IBUSPROTOCOLO_H
#define IBUSPROTOCOLO_H

/*
OP��O: 0x00 (Padding)
TAMANHO: 0x00
PERMISS�O: Pode ser enviado com chave padr�o ou chave �nica do receptor. Para qualquer endere�o.
DESCRI��O: Op��es 0x00 s�o ignoradas, servem para fazer padding para os blocos de criptografia
*/
#define IBUS_PADDING 0x00

/*
OP��O: 0x01 (Controle Remoto Presente)
TAMANHO: 0
PERMISS�O: Pode ser enviado com chave padr�o ou chave �nica do receptor. Para qualquer endere�o.
DESCRI��O: Informa��o, enviado pelo controle indicando que est� com o r�dio ligado aguardando respostas de receptores que o possuam cadastrado ou que queiram cadastr�-lo.
*/
#define IBUS_CONTROLE_REMOTO_PRESENTE 0x01

/*
OP��O: 0x02 (Chave criptogr�fica privada)
TAMANHO: 16
PERMISS�O: Pode ser enviado com chave padr�o ou chave �nica do receptor. Endere�os MULTICAST n�o s�o permitidos.
DESCRI��O: Comando. Enviado pelo receptor, informando qual � sua chave criptogr�fica. Serve para o cadastro. Essa op��o nunca deve ser enviada a endere�os multicast. Se um controle receber essa op��o ap�s enviar o pacote de presente indica que o receptor quer que ele fa�a parte da sua rede.
*/
#define IBUS_CHAVE_CRIPTOGRAFICA_PRIVADA 0x02

/*
OP��O: 0x03 (Receptor Presente)
TAMANHO: 0
PERMISS�O: Pode ser enviado apenas com chave padr�o.
DESCRI��O: Comando. O receptor envia esse pacote a um controle, para indicar que est� a seu alcance e aguarda um comando dele. 
*/
#define IBUS_RECEPTOR_PRESENTE 0x03

/*
OP��O: 0x04 (Cadastro aceito)
TAMANHO: 0
PERMISS�O: Pode ser enviado apenas com chave unica.
DESCRI��O: Indica que a chave criptogr�fica foi salva e quem enviou esse pacote faz parte da rede agora.
*/
#define IBUS_CADASTRO_ACEITO 0x04

/*
OP��O: 0x05 (Estado do controle remoto)
TAMANHO: 8 ou mais
PERMISS�O: Pode ser enviado apenas com chave padr�o.
DESCRI��O:
	A cada altera��o do controle, ou se este for supervisionado, no envio de supervis�o.
	O controle � quem decide de que forma enviar esses comando. Mas a opera��o padr�o � a seguinte:
	O controle envia o comando cada vez que um ou mais bot�es s�o pressionados.
	N�o envia quando os bot�es s�o soltos.
	Ap�s 3 segundos segurando um ou mais bot�es o estado � reenviado com os novos valores.
	Se houver supervis�o configurada no controle, esse pacote � enviado peri�dicamente como um magn�tico, o tempo pode variar de 1 a 15 minutos conforme o tempo da rede.

[SUPERVISAO][DELAY][DIAS_BATERIA (2 bytes)][NUM_TRANSMISSOES (3 bytes)][ESTADO]

SUPERVISAO � Intervalo em minutos que esse dispositivo enviar� a pr�xima supervis�o. Se 000 indica que ele n�o enviar� supervis�o.

DELAY � Quanto tempo levou entre transmiss�o e resposta do �ltimo comando que esse dispositivo executou. Serve para medir a qualidade do canal. Um byte, ent�o se o tempo for superior a 255ms, marca 255.

DIAS_BATERIA � Quantos dias se passaram desde que detectou troca da bateria.

NUM_TRANSMISSOES � Quantas transmiss�es ocorreram desde a troca da bateria.

ESTADO � Envia um mapa de bits de como se encontra o bot�o do controle, se houver mais de um bot�o, haver� mais de um byte de estado, um para cada bot�o.
	O byte estado contem o tempo em que o bot�o encontras-se nesse estado e um bit indicando se est� pressionado ou n�o. 
	Bit 7 � Pressionado ou n�o
	Bit 0 a 6 � Tempo, em d�cimos de segundo do estado deste bot�o, sendo:
	
	0 (0000000) � O bot�o acabou de mudar de estado.
	1 a 126 � 100ms a 12,6s de bot�o nesse estado.
	127 (1111111) � O bot�o � considerado infinitamente nesse estado.
*/
#define IBUS_ESTADO_CONTROLE_REMOTO 0x05

/*
OP��O: 0x06 ( Estado do controle remoto recebido)
TAMANHO: 0
PERMISS�O: Pode ser enviado apenas com chave padr�o.
DESCRI��O: Receptor indica que recebeu o comando.
*/
#define IBUS_ESTADO_RECEBIDO 0x06

/*
OP��O: 0x07 (Aberto para cadastros)
TAMANHO:1
PERMISS�O: Pode ser enviado com chave padr�o ou chave �nica do receptor. Para qualquer endere�o.
DESCRI��O: Informa a todos os repetidores que est� aceitando dispositivos sem rede. Um byte � enviado indicando em que canal deve ocorrer o cadastro.

OP��O: 0x08 (Requisi��o de chave privada) 
TAMANHO: 0
PERMISS�O: Pode ser enviado com chave padr�o ou chave �nica do receptor. Para qualquer endere�o.
DESCRI��O: Os repetidores enviam a um receptor aberto para cadastro, para que este envie sua chave criptogr�fica privada, se aceitar eles no sistema.

OP��O: 0x09 (Estado do sensor)
TAMANHO: 8 ou mais
PERMISS�O: Pode ser enviado apenas com chave padr�o.
DESCRI��O:
[SUPERVISAO][DELAY][DIAS_BATERIA (2 bytes)][NUM_TRANSMISSOES (3 bytes)][ESTADO]

SUPERVISAO � Intervalo em minutos que esse dispositivo enviar� a pr�xima supervis�o. Se 000 indica que ele n�o enviar� supervis�o.

DELAY � Quanto tempo levou entre transmiss�o e resposta do �ltimo comando que esse dispositivo executou. Serve para medir a qualidade do canal. Um byte, ent�o se o tempo for superior a 255ms, marca 255.

DIAS_BATERIA � Quantos dias se passaram desde que detectou troca da bateria.

NUM_TRANSMISSOES � Quantas transmiss�es ocorreram desde a troca da bateria.

ESTADO � Envia um mapa de bits de como se encontra o sensor, pode ser enviado na supervis�o ou toda vez que houver uma altera��o do estado. Se houver mais de um sensor no mesmo dispositivo, envia-se mais bytes de estado.
	Bit 0 � Fechado/Aberto
	Bit 1 a 3 � Reservados
	Bit 4 � Tamper fechado/aberto
	Bit 5 � Bateria baixa 
	Bit 6 � Anti-mascara
	Bit 7 � Movimento (esse estado � tempor�rio, indica que detectou movimento)

OP��O: 0x0A (Estado recebido)
TAMANHO: 0
PERMISS�O: Pode ser enviado apenas com chave unica.
DESCRI��O: Receptor informa que o estado enviado chegou corretamente
*/
#define IBUS_INFORMA_TIMESTAMP 0x0B
/*
OP��O: 0x0B (Timestamp correto)
TAMANHO: 4 bytes
PERMISS�O: Pode ser enviado apenas com chave �nica ou chave padr�o junto com a resposta a controle remoto presente.
DESCRI��O: O receptor pode aceitar um pacote com timestamp errado e responder com esse timestamp a fim de enviar o correto.

*/


#define IBUS_INFORMA_ADC 0xAD
/*
OP��O: 0xAD (Timestamp correto)
TAMANHO: X bytes
PERMISS�O: Pode ser enviado apenas com chave �nica ou chave padr�o junto com a resposta a controle remoto presente.
DESCRI��O: O receptor pode aceitar um pacote com timestamp errado e responder com esse timestamp a fim de enviar o correto.

*/

#endif
