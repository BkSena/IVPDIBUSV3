#ifndef IBUSAPLICACAO_H
#define IBUSAPLICACAO_H

#include "iBUSv3/iBUStransporte.h"

struct option{
	unsigned char tamanho;
	unsigned char opcao;
	unsigned char *dado;
};

#ifndef IBUSAPLICACAO_C
extern void iBUSAplicacao_Init(void);//chamar no power up

#ifdef IBUSTRANSPORTE_C
extern void iBUSAplicacao_receive(struct iTransportePack *dados);
extern void iBUSAplicacao_transporteResult(enum RESULTS result);
#endif

#ifdef SOU_SNIFFER
extern void iBUSAplicacao_Snif(struct iTransportePack *dados);
#endif

#ifdef IBUSMANAGER_C
//LOW POWER routines
extern void iBUSAplicacao_Wakeup(void);//acorda sistema 
extern void iBUSAplicacao_Shutdown(void);//prepara tudo para entrar em modo sleep

//Interface com camadas superiores
/**
iBUSAplicacao_sendOptions
	resposta: Informa��es sobre para quem deve ser enviada a lista de op��es.
	Se o tipo for PACOTE_TIPO_RESPOSTA deve-se acrescentar o "timestamp" do pacote de que trata a resposta, para permitir
a camada de Transporte que verifique a diferen�a entre retransmiss�es e repeti��es:
		Retransmiss�o (quando o originador repete o comando por n�o obter resposta - timestamp muda)
		Repeti��o (quando o pacote recebido veio de um repetidor, o timestamp � o mesmo)
	Retransmiss�es demandam reenvio da resposta e repeti��es n�o.
	
	options: Lista de op��es a ser enviada
**/
extern void iBUSAplicacao_sendOptions(struct iTransportePack *resposta, struct option *options);//envia um array de options nullterminated ou o �ltimo � marcado como padding
#endif

#endif
#endif
