#define IBUSAPLICACAO_C


#include "Main\iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.
#include "Main\SysUtils.h"

#include "Main\target.h"
#include "iBUSAplicacao.h"
#include "IBUSManager.h"
#include "iBUSprotocolo.h"

#include "Sistema/dynmem.h"
#include "Sistema/system.h" //para resgatar o n�vel de bateria


#ifdef SOU_SNIFFER
//#include "S2LP_SDK_Util.h"
#endif

void iBUSAplicacao_Init(void)
{
}

void iBUSAplicacao_receive(struct iTransportePack *dados)
{
	struct option opcao;
	unsigned char pos = 5;//pula modelo, bateria, sinal
	
	if(dados->aplic_len>=5)
	{//pacote coerente
	
		//Destrinchar as op��es
		while((pos+1)<dados->aplic_len)
		{//tem uma op��o ao menos?
			if((dados->aplicacao[pos]==0)&&(dados->aplicacao[pos+1]==0))
			{//padding detectado, acabou o pacote
				break;//depois do padding n�o deve haver mais nada
			}
			else
			{//verifica se h� uma op��o v�lida aqui
				if((pos+dados->aplicacao[pos]+2)<=dados->aplic_len)
				{//recebemos uma op��o v�lida
					
					opcao.tamanho = dados->aplicacao[pos];
					opcao.opcao = dados->aplicacao[pos+1];
					opcao.dado = &dados->aplicacao[pos+2];
					iBUSManager_TrataOption(dados, opcao);
				}
			}
			pos+=dados->aplicacao[pos]+2;
		}
	}
}

void iBUSAplicacao_transporteResult(enum RESULTS result)
{
	iBUSManager_AplicacaoResult(result);
}

void iBUSAplicacao_sendOptions(struct iTransportePack *resposta, struct option *options)
{//envia um array de options onde o �ltimo � marcado como padding (opcao==0x00)
	unsigned char aux, pos, i;
	unsigned char sizeofbuf=5;
	#ifdef ALIMENTADO_POR_BATERIA
	unsigned short int bateria;
	#endif
	
	aux=0;
	while(options[aux].opcao!=IBUS_PADDING)
	{
		sizeofbuf+=(options[aux].tamanho+2);
		aux++;
	}
	
	resposta->aplicacao=malloc(sizeofbuf);
	if(resposta->aplicacao!=NULL)
	{
		resposta->aplic_len=sizeofbuf;
		
		resposta->aplicacao[0]=MODELO_EQTO>>8;
		resposta->aplicacao[1]=MODELO_EQTO&0xFF;
		#ifdef ALIMENTADO_POR_BATERIA
		bateria = system_getBatteryLevel();
		resposta->aplicacao[2]=bateria>>8;//Minha tens�o de bateria. No caso n�o temos
		resposta->aplicacao[3]=bateria;
		#else		
		resposta->aplicacao[2]=0xFF;//Minha tens�o de bateria. No caso n�o temos
		resposta->aplicacao[3]=0xFF;
		#endif
		resposta->aplicacao[4]=resposta->rssi;
		
		aux=0;
		pos=0;
		while(options[aux].opcao!=IBUS_PADDING)
		{
			resposta->aplicacao[5+pos]=options[aux].tamanho;
			resposta->aplicacao[6+pos]=options[aux].opcao;
			for(i=0;i<options[aux].tamanho;i++)resposta->aplicacao[7+pos+i]=options[aux].dado[i];
			
			pos+=(options[aux].tamanho+2);
			aux++;
		}
		
		iBUStransporte_Send(resposta);//envia o pacote. 
		free(resposta->aplicacao);
	}

}

void iBUSAplicacao_Wakeup(void)//acorda sistema 
{
	iBUStransporte_Wakeup();
}

void iBUSAplicacao_Shutdown(void)//prepara tudo para entrar em modo sleep
{
	iBUStransporte_Shutdown();
}

