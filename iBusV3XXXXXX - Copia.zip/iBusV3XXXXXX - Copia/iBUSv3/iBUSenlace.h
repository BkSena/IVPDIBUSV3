#ifndef IBUSENLACE_H
#define IBUSENLACE_H

struct iEnlacePack{
	unsigned char len;
	unsigned char *data;
	unsigned char rssi;
};

//Repostas a camada superior
#define iBUSenlace_receiveData(a) iBUSrede_receiveData(a)  //chamada a fun��o que trata do pacote recebido
#define iBUSenlace_Result(a)      iBUSrede_enlaceResult(a) //definir a fun��o que essa camada ir� chamar para tratar resultados da transmiss�o

enum RESULTS{
IBUSENLACE_RESULT_RECEPCAO_ABORTADA,
IBUSENLACE_RESULT_RECEPCAO_DESCARTADA,
IBUSENLACE_RESULT_TRANSMISSAO_OK,
IBUSTRANSPORTE_RESULT_TRANSMISSAOCONCLUIDASUCESSO,  //indica que transmitiu e recebeu confirma��o
IBUSTRANSPORTE_RESULT_TRANSMISSAOESTOUROUTENTATIVAS, //indica que desistiu de enviar o pacote
};


#ifndef IBUSENLACE_C

#ifdef iBUSv3_C
extern void iBUSenlace_Init(void);//chamar no power up
extern void iBUSenlace_Main(void);//chamar peri�dicamente (a cada 1ms)
#endif

#ifdef IBUSREDE_C
//LOW POWER routines
extern void iBUSenlace_Wakeup(void);//acorda sistema 
extern void iBUSenlace_Shutdown(void);//prepara tudo para entrar em modo sleep

//Interface com camadas superiores
extern unsigned char iBUSenlace_canIsend(void);//retorna diferente de zero se pronto para enviar pacotes.
extern unsigned char iBUSenlace_Send(struct iEnlacePack *packet);//envia um pacote na camada de enlace, retorna 0 se ok
extern void iBUSenlace_Abort(void);
#endif

#ifdef RADIO_C
extern void iBUSenlace_ReceivePacket(unsigned char *packet, unsigned char len);//R�dio informa que recebeu um pacote de dados
extern void iBUSenlace_AvisaFimTransmissao(void);
extern void iBUSenlace_CRCErrorHandle(void);//recebeu pacote com erro
#endif

extern void iBUSenlace_ResetQtdPackets(void);//zera o contador de pacotes enviados
extern unsigned short int iBUSenlace_GetQtdPackets(void);//retorna quantos pacotes j� transmitiu

#endif
#endif
