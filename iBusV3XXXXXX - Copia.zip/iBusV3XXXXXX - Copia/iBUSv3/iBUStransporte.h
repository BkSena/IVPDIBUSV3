#ifndef IBUSTRANSPORTE_H
#define IBUSTRANSPORTE_H

#include "iBUSv3/iBUSrede.h"

#define PACOTE_TIPO_COMANDO    0x0
#define PACOTE_TIPO_RESPOSTA   0x1
#define PACOTE_TIPO_INFORMACAO 0x2

#define IBUSTRANSPORTE_TIMEOUT_RTX 400//270 //em milisegundos

struct iTransportePack{
	unsigned char receiver_add[3];
	unsigned char sender_add[3];
	unsigned char cript_scheme;
	unsigned char modo_transmissao;//Normal=0 ou Channel Hopping=1
	
	unsigned char tipo:4;
	unsigned char id:4;
	unsigned char *aplicacao;
	unsigned char aplic_len;
	unsigned long int timestamp;
	
	unsigned char rssi;
	
	unsigned char maquina; //estado de transmiss�o (0-aguardando para transmitir; 1-aguardando resposta; 2-resposta ou informacao aguardando 10 segundos para descarte)
	unsigned char retx_cnt; //qtas vezes j� retransmitiu
	unsigned short int timeout;
	struct iTransportePack *next;
};

#ifndef IBUSTRANSPORTE_C
extern void iBUStransporte_Init(void);//chamar no power up
extern void iBUStransporte_Loop(void);//chamar em tempo de loop
extern void iBUStransporte_Main(void);//chamar a cada 1ms

extern unsigned char iBUStransporte_isAValidyPack(unsigned char *cripto);//Verifica se buf contem um pacote de transporte v�lido.

#ifdef IBUSREDE_C
extern void iBUStransporte_receiveDecripto(struct iRedePack *dados);
extern void iBUStransporte_redeResult(enum RESULTS result);
#endif

#ifdef SOU_SNIFFER
extern void iBUStransporte_debugaPacote(struct iRedePack *dados);
#endif

#ifdef IBUSAPLICACAO_C
//LOW POWER routines
extern void iBUStransporte_Wakeup(void);//acorda sistema 
extern void iBUStransporte_Shutdown(void);//prepara tudo para entrar em modo sleep

//Interface com camadas superiores
/**
iBUStransporte_Send
	Em packet, se este send for resposta a um comando
	devemos preencher timestamp com o valor do timestamp recebido.
	Caso contr�rio devemos preencher com 0.
	Dessa forma a camada de transporte pode diferenciar pacotes recebidos:
		Retransmiss�o (quando o originador repete o comando por n�o obter resposta - timestamp muda)
		Repeti��o (quando o pacote recebido veio de um repetidor, o timestamp � o mesmo)
	Retransmiss�es demandam reenvio da resposta e repeti��es n�o.
**/
extern unsigned char iBUStransporte_Send(struct iTransportePack *packet);//envia um pacote na camada de rede, retorna 0 se ok
#endif

#endif
#endif
