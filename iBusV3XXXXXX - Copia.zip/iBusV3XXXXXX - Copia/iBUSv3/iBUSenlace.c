#define IBUSENLACE_C

#include "Main/iBUSv3.h"

#include "iBUSenlace.h"
#include "iBUSrede.h"

#include "Radio/Radio.h"

/***************************************************************************
Com uma taxa de 10.000bps temos um byte a cada 1ms. 
***************************************************************************/

//DEFINES DO CSMA-LBT (Carrier Sense Multiple Access - Listen before talk)
#define IBUSENLACE_LBT_MAXBACKOFF_RANGE 40 //m�ximo de tempo que deve ficar esperando antes de tentar de novo

#define IBUSENLACE_LBT_MINBACKOFF_TIME 20//m�ximo de tempo que deve ficar esperando antes de tentar de novo
//15 - funciona intermitente
//17 - 1,5% - errou 3 em 200
//20 - 0% sempre funciona (100 pacotes em 100)

#define IBUSENLACE_TEMPO_CPU_ANTES_INICIAR 50 //tolerancia que damos para quem receber iniciar sua resposta
#define IBUSENLACE_LBT_MAXBACKOFF_TIME (IBUSENLACE_LBT_MINBACKOFF_TIME + IBUSENLACE_LBT_MAXBACKOFF_RANGE)

unsigned char iBUSenlace_LBT_backoff;//conta tempo aleat�rio de backoff se ouvir portadora
unsigned char iBUSenlace_randomTick;//incrementa a cada 1ms para melhorar o gerador aleat�rio
unsigned char iBUSenlace_WaitingAswer;//conta o tempo para ver se est�o respondendo (fica cuidando a portadora)
unsigned char iBUSenlace_ativo;//se diferente de zero, indica ok, se zero, estamos em shutdown mode

unsigned short int iBUSenlace_ContaTransmissoes;
#ifdef SOU_SNIFFER
unsigned short int iBUSenlace_debugTime;//para imprimir o tempo em milisegundos
#endif

void iBUSenlace_ResetQtdPackets(void);//zera o contador de pacotes enviados

void iBUSenlace_Init(void)
{
	iBUSenlace_LBT_backoff=0;
	iBUSenlace_WaitingAswer=0;
	iBUSenlace_ativo=0;//inicia desligado.
	
	iBUSenlace_ResetQtdPackets();
}

void iBUSenlace_LoadBackOff(unsigned char rssi)
{
	//Gerador aleat�riozinho para acesso ao meio
	rssi*=iBUSenlace_randomTick;//para dar aleat�riedade
	iBUSenlace_LBT_backoff=rssi%IBUSENLACE_LBT_MAXBACKOFF_RANGE;//limita o tempo de backoff.
	iBUSenlace_LBT_backoff+=IBUSENLACE_LBT_MINBACKOFF_TIME;//valores variam de IBUSENLACE_LBT_MINBACKOFF_TIME a IBUSENLACE_LBT_MINBACKOFF_TIME+IBUSENLACE_LBT_MAXBACKOFF_RANGE
}

void iBUSenlace_ReceivePacket(unsigned char *packet, unsigned char len)
{//R�dio informa que recebeu um pacote de dados
	struct iEnlacePack mypack;
	
	mypack.data=packet;
	mypack.len=len;
	mypack.rssi=radio_GetRSSI();

	//Acabei de receber um pacote, o meio vai estar livre pra todo mundo, vamos dar um tempo pra ver se conseguimos aleatoriamente entrar
	iBUSenlace_LoadBackOff(mypack.rssi);
	//Gerador aleat�riozinho para acesso ao meio
	//iBUSenlace_LBT_backoff=(mypack.rssi*iBUSenlace_randomTick)%IBUSENLACE_LBT_MAXBACKOFF_TIME;//limita o tempo de backoff.
	//iBUSenlace_LBT_backoff++;//valores variam de 1 a IBUSENLACE_LBT_MAXBACKOFF_TIME
	
	iBUSenlace_receiveData(&mypack);
}

void iBUSenlace_Main(void)
{//loop de controle de timeouts a cada 1ms
	if(iBUSenlace_ativo==0)return;
	
	iBUSenlace_randomTick++;//nunca � resetado, tah acordado incrementa, assim conforme for apertando e demorando para responder, vai virando um valor aleat�rio
	
	if(iBUSenlace_LBT_backoff!=0)iBUSenlace_LBT_backoff--;
	
	if(iBUSenlace_WaitingAswer!=0)
	{
		if(radio_portadora()==0)
		{
			iBUSenlace_WaitingAswer--;
			if(iBUSenlace_WaitingAswer==0)
			{
				iBUSenlace_Result(IBUSENLACE_RESULT_RECEPCAO_ABORTADA);
			}
		}
		else iBUSenlace_WaitingAswer=IBUSENLACE_TEMPO_CPU_ANTES_INICIAR+(2*IBUSENLACE_LBT_MAXBACKOFF_TIME);//carrega um tempo em que vai ficar cuidando se alguem ouviu (2 vezes o maximo tempo de backoff)
	}
}

void iBUSenlace_AvisaFimTransmissao(void)
{
	iBUSenlace_LoadBackOff(1);//para evitar transmitir dois pacotes um atras do outro
	iBUSenlace_Result(IBUSENLACE_RESULT_TRANSMISSAO_OK);
}

void iBUSenlace_Wakeup(void)
{//acorda sistema 
	iBUSenlace_LBT_backoff=0;
	iBUSenlace_WaitingAswer=0;
	iBUSenlace_ativo=1;//ok, podemos fazer chamadas no r�dio
	radio_powerOn();//liga o r�dio
}

void iBUSenlace_Shutdown(void)
{//prepara tudo para entrar em modo sleep
	iBUSenlace_ativo=0;//radio n�o est� operante,n�o podemos chamar nenhuma fun��o dele.
	radio_shutdown();//primeiro passo desliga o r�dio
}

unsigned char iBUSenlace_canIsend(void)
{//retorna diferente de zero se pronto para enviar pacotes.
	unsigned char rssi;
	
	if(iBUSenlace_ativo==0)return 0;//n�o pode transmitir com o r�dio inativo

	if(iBUSenlace_LBT_backoff==0)
	{//n�o estamos esperando um tempo antes de tentar de novo?
		if((rssi=radio_portadora())==0)
		{//n�o tem portadora presente
			return 1;//pode transmitir que o meio est� livre.
		}
		else
		{
			//Gerador aleat�riozinho para acesso ao meio
			iBUSenlace_LoadBackOff(rssi);

		}
	}
	return 0;//n�o pode transmitir
}

unsigned char iBUSenlace_Send(struct iEnlacePack *packet)
{//envia um pacote na camada de enlace.
	if(iBUSenlace_ativo==0)return 1;//n�o pode transmitir com o r�dio inativo
	
	//obrigat�riamente deve-se chamar iBUSenlace_canIsend antes
	if(iBUSenlace_LBT_backoff==0)
	{//n�o estamos esperando um tempo antes de tentar de novo?
		iBUSenlace_LoadBackOff(packet->rssi);//pra n�o fazer dois sends seguidos sem pausa
		iBUSenlace_WaitingAswer=IBUSENLACE_TEMPO_CPU_ANTES_INICIAR+(2*IBUSENLACE_LBT_MAXBACKOFF_TIME);//carrega um tempo em que vai ficar cuidando se alguem ouviu (2 vezes o maximo tempo de backoff)
		radio_sendPacket(packet->data,packet->len);//rssi n�o interessa, manda ver o pacote
		
		if(iBUSenlace_ContaTransmissoes!=0xFFFF)iBUSenlace_ContaTransmissoes++;//mais um pacote transmitido
		return 0;//transmiss�o iniciada com sucesso.
	}
	//terminal_Printf_E("nao tx");
	return 1;//nao deu para tx
}

void iBUSenlace_Abort(void)
{
	iBUSenlace_WaitingAswer=0;//nao vou ficar mais cuidando a portadora
}

void iBUSenlace_CRCErrorHandle(void)
{//recebeu pacote com erro
	iBUSenlace_Result(IBUSENLACE_RESULT_RECEPCAO_DESCARTADA);
}

void iBUSenlace_ResetQtdPackets(void)//zera o contador de pacotes enviados
{
	iBUSenlace_ContaTransmissoes=0;
}

unsigned short int iBUSenlace_GetQtdPackets(void)
{//retorna quantos pacotes j� transmitiu
	return iBUSenlace_ContaTransmissoes;
}
