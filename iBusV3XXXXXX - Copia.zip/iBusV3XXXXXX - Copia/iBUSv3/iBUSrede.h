#ifndef IBUSREDE_H
#define IBUSREDE_H

#include "iBUSenlace.h"

struct iRedePack{
	unsigned char receiver_add[3];
	unsigned char sender_add[3];
	unsigned char versao:4;
	unsigned char cripto_scheme:1;
	unsigned char ttl:3;
	unsigned char *cripto;
	unsigned char len;//multiplos de 16 se criptografado
	unsigned char rssi;
};

#ifndef IBUSREDE_C

extern const unsigned char MULTICAST_RECEPTORES[3];
extern const unsigned char MULTICAST_DISPOSITIVOS[3];
extern const unsigned char CHAVEPADRAO[16];

#ifdef iBUSv3_C
extern void iBUSrede_Init(void);//chamar no power up
extern void iBUSrede_Main(void);//chamar peri�dicamente (a cada 1ms)
#endif

#ifdef IBUSENLACE_C
extern void iBUSrede_receiveData(struct iEnlacePack *dados);
extern void iBUSrede_enlaceResult(enum RESULTS result);
#endif

#ifdef IBUSTRANSPORTE_C
//LOW POWER routines
extern void iBUSrede_Wakeup(void);//acorda sistema 
extern void iBUSrede_Shutdown(void);//prepara tudo para entrar em modo sleep

//Interface com camadas superiores
extern unsigned char iBUSrede_canIsend(void);//retorna diferente de zero se pronto para enviar pacotes.
extern unsigned char iBUSrede_Send(struct iRedePack *packet);//envia um pacote na camada de enlace, retorna 0 se ok
#endif

#endif
#endif
