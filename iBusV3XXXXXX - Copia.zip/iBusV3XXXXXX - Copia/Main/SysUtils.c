#define SYSUTILS_C

#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.

#include "SysUtils.h"

unsigned long Sysutils_SystemCoreClock;

//unsigned long su_en0,su_en1;

//*****************************************************************************
//
//! Enables an interrupt.
//!
//! \param ulInterrupt specifies the interrupt to be enabled.
//!
//! The specified interrupt is enabled in the interrupt controller.  Other
//! enables for the interrupt (such as at the peripheral level) are unaffected
//! by this function.
//!
//! \return None.
//
//*****************************************************************************
/*
void Sysutils_IntEnable(unsigned long ulInterrupt)
{
    //
    // Check the arguments.
    //
    //ASSERT(ulInterrupt < NUM_INTERRUPTS);

    //
    // Determine the interrupt to enable.
    //
    if(ulInterrupt == FAULT_MPU)
    {
        //
        // Enable the MemManage interrupt.
        //
        HWREG(NVIC_SYS_HND_CTRL) |= NVIC_SYS_HND_CTRL_MEM;
    }
    else if(ulInterrupt == FAULT_BUS)
    {
        //
        // Enable the bus fault interrupt.
        //
        HWREG(NVIC_SYS_HND_CTRL) |= NVIC_SYS_HND_CTRL_BUS;
    }
    else if(ulInterrupt == FAULT_USAGE)
    {
        //
        // Enable the usage fault interrupt.
        //
        HWREG(NVIC_SYS_HND_CTRL) |= NVIC_SYS_HND_CTRL_USAGE;
    }
    else if(ulInterrupt == FAULT_SYSTICK)
    {
        //
        // Enable the System Tick interrupt.
        //
        HWREG(NVIC_ST_CTRL) |= NVIC_ST_CTRL_INTEN;
    }
    else if((ulInterrupt >= 16) && (ulInterrupt <= 47))
    {
        //
        // Enable the general interrupt.
        //
        HWREG(NVIC_EN0) = 1 << (ulInterrupt - 16);
    }
    else if(ulInterrupt >= 48)
    {
        //
        // Enable the general interrupt.
        //
        HWREG(NVIC_EN1) = 1 << (ulInterrupt - 48);
    }
}
*/
/*****************************************************************************/
//
//! Disables an interrupt.
//!
//! \param ulInterrupt specifies the interrupt to be disabled.
//!
//! The specified interrupt is disabled in the interrupt controller.  Other
//! enables for the interrupt (such as at the peripheral level) are unaffected
//! by this function.
//!
//! \return None.
//
/*****************************************************************************/
/*
void Sysutils_IntDisable(unsigned long ulInterrupt)
{
    //
    // Check the arguments.
    //
    //ASSERT(ulInterrupt < NUM_INTERRUPTS);

    //
    // Determine the interrupt to disable.
    //
    if(ulInterrupt == FAULT_MPU)
    {
        //
        // Disable the MemManage interrupt.
        //
        HWREG(NVIC_SYS_HND_CTRL) &= ~(NVIC_SYS_HND_CTRL_MEM);
    }
    else if(ulInterrupt == FAULT_BUS)
    {
        //
        // Disable the bus fault interrupt.
        //
        HWREG(NVIC_SYS_HND_CTRL) &= ~(NVIC_SYS_HND_CTRL_BUS);
    }
    else if(ulInterrupt == FAULT_USAGE)
    {
        //
        // Disable the usage fault interrupt.
        //
        HWREG(NVIC_SYS_HND_CTRL) &= ~(NVIC_SYS_HND_CTRL_USAGE);
    }
    else if(ulInterrupt == FAULT_SYSTICK)
    {
        //
        // Disable the System Tick interrupt.
        //
        HWREG(NVIC_ST_CTRL) &= ~(NVIC_ST_CTRL_INTEN);
    }
    else if((ulInterrupt >= 16) && (ulInterrupt <= 47))
    {
        //
        // Disable the general interrupt.
        //
        HWREG(NVIC_DIS0) = 1 << (ulInterrupt - 16);
    }
    else if(ulInterrupt >= 48)
    {
        //
        // Disable the general interrupt.
        //
        HWREG(NVIC_DIS1) = 1 << (ulInterrupt - 48);
    }
}
*/
//*****************************************************************************/
//
// UARTX_SpeedSetup - Configura��o de velocidade da serial
// Par�metro
// Serial a ser programada: UART_0 = 0, UART_1 = 1, UART_2 = 2
// Velocidade de Opera��o Desejada
//
//*****************************************************************************/
/*
void SysUtils_UartSpeed(unsigned long uart_base_add, unsigned long speed)
{		
	unsigned long aux_long;

	speed = speed / 100;
	aux_long = SysCtlClockGet() * 100 / speed;
	//aux_long = aux_long * 10000;
	aux_long = aux_long / 16; // os par�metros s�o calculados com base no clock e na velocidade
	HWREG(uart_base_add | UARTIBRD) = aux_long / 10000; // UARTIBRD = 4
	aux_long = aux_long % 10000;
	aux_long = aux_long * 64;
	aux_long = aux_long + 5000;
	aux_long = aux_long / 10000;
	//aux_long = ( ( ( aux_long % 10000 ) * 64 ) + 5000 ) / 10000;
	HWREG(uart_base_add | UARTFBRD) =  aux_long; // UARTFBRD	 = 22
}
*/
//unsigned int SysUtils_StrCopy(unsigned char *cStrOrigem, unsigned char *cStrDestino)
//{
//	unsigned int cAux = 0;

//	do{
//		cStrDestino[cAux] = cStrOrigem[cAux];
//	}while(cStrOrigem[cAux++] != 0);

//	return cAux - 1;
//}

//unsigned int SysUtils_StrLen(const char *str1)
//{
//	unsigned int aux=0;
//	while((aux!=0xFFFF)&&(str1[aux]!='\0'))aux++;
//	return aux;
//}

//unsigned char SysUtils_IntToStr(unsigned int num, unsigned char *str)//preenche str com a representacao decimal da string e retorna qts caracteres usou
//{
//	unsigned int count=0, div=9;
//	
//	while(num>div)div = div*10 + 9;//descobrindo qtas casas tem.
//	div++;
//	div=div/10;
//	
//	while(div>0)
//	{
//		str[count]= (num/div) + '0';
//		count++;
//		num = num%div;
//		div = div/10;
//	}
//	return count;
//}

//void SysUtils_IntToHex(unsigned char num, unsigned char *str)//preenche str com 2 d�gitos de representacao hexa da string
//{
//	if(num>=0xA0){
//		str[0]=(('A'-10+(num>>4)));
//	}
//	else{
//		str[0]=(('0'+(num>>4)));
//	}
//	if((num&0x0F)>=0x0A){
//		str[1]=(('A'-10+(num&0x0F)));
//	}
//	else{
//		str[1]=(('0'+(num&0x0F)));
//	}
//}

//unsigned short int SysUtils_StrToByteArray(char *texto, unsigned char *array)
//{
//	unsigned short int pos=0;
//	unsigned char key;
//	
//	while((texto[pos]!=0)&&(texto[pos+1]!=0))
//	{//temos 2 caracteres para transformar em hexa?
//		array[pos/2] = 0;
//		do
//		{
//			key = texto[pos];
//			if((key>='0') && (key<='9'))key = key -'0';
//			else if((key>='A') && (key<='F'))key = key -'A' + 10;
//			else if((key>='a') && (key<='f'))key = key -'a' + 10;
//			else key=0;

//			array[pos/2]*=0x10;
//			array[pos/2]+=key;
//			
//			pos++;
//		}
//		while((pos%2)!=0);
//	}
//	return pos/2;//retorna tamanho do array
//}


//unsigned char *SysUtils_strstr(unsigned char *str1,const unsigned char *str2)//faz o que a funcao ansi c strstr faz
//{
//	unsigned short int pos=0, aux;
//	while(str1[pos]!=0)
//	{
//		aux=0;
//		while(str2[aux]!=0)
//		{
//			if(str1[pos+aux]!=str2[aux])break;
//			aux++;
//		}
//		if(str2[aux]==0) return &str1[pos];//detectei a string toda
//		pos++;
//		if(pos==0)return NULL;//overflow de string!
//	}
//	return NULL;
//}

//unsigned char SysUtils_strncmp(const unsigned char *str1,const unsigned char *str2, unsigned char num)//faz o que a funcao ansi c strncmp faz
//{
//unsigned char pos;
//for(pos=0;pos<num;pos++)
//{
//	if(str1[pos]!=str2[pos])break;//erro cai fora
//}
//return pos!=num;
//}

//unsigned char SysUtils_strcmp(const char * str1, const char * str2)//faz o que a fun��o ansi strcmp faz
//{
//	while((*str1)==(*str2))
//	{
//		str1++;
//		str2++;
//		if((*str1)==0)break;
//	}
//	return(*str1)-(*str2);
//}

//char * SysUtils_strchr(char * str, char character)
//{
//	while((*str)!=0)
//	{
//		if((*str)==character) return str;
//		str++;
//	}
//	return NULL;
//}

//unsigned char SysUtils_memcmp(const unsigned char * ptr1, const unsigned char * ptr2, unsigned int num)//faz o que a fun��o ansi memcmp faz
//{
//	unsigned int i = 0;
//	
//	while(i<num)
//	{
//		if(ptr1[i]!=ptr2[i])break;
//		i++;
//	}	
//	if(i==num)return 0;
//	
//	return(ptr1[i])-(ptr2[i]);
//}

/*
void SysUtils_DisableInterrupts(void)
{
	//Salva as interrup��es ligadas, para saber quais religar depois.
	su_en0 = HWREG(NVIC_ADD | EN0);
	su_en1 = HWREG(NVIC_ADD | EN1);
	
	//Desliga todas as interrup��es
	HWREG(NVIC_ADD | DIS0) = 0xFFFFFFFF;
	HWREG(NVIC_ADD | DIS1) = 0xFFFFFFFF;
}
void SysUtils_EnableInterrupts(void)
{
	//Religa todas as interrup��es
	HWREG(NVIC_ADD | EN0) = su_en0;
	HWREG(NVIC_ADD | EN1) = su_en1;
}
*/

unsigned long SysUtils_ClockGet(void)
{
	#ifdef ARRUMAR_CALCULO_CLOCK
	
  unsigned long MCGOUTClock; // Variable to store output clock frequency of the MCG module 
  unsigned int Divider;

  if ((HWREGC(MCG_ADD + MCG_C1) & 0xC0) == 0x00) //CLKS = 00 (Encoding 0 - Output of FLL or PLL)
	{// Output of FLL or PLL is selected 
    if ((HWREGC(MCG_ADD + MCG_C6) & 0x40) == 0x00) //PLLS - 0:FLL / 1:PLL
		{// FLL is selected 
      if ((HWREGC(MCG_ADD + MCG_C1) & 0x04) == 0x00) //IREFS - 0:external / 1:slow internal
			{// External reference clock is selected 
        MCGOUTClock = CPU_XTAL_CLK_HZ;                                       /* System oscillator drives MCG clock */
        Divider = (unsigned int)(1 << ((HWREGC(MCG_ADD + MCG_C1) & 0x38) >> 3));//Carrega FRDIV
        MCGOUTClock = (MCGOUTClock / Divider);  /* Calculate the divided FLL reference clock */
        if ((HWREGC(MCG_ADD + MCG_C2) & 0x30) != 0x00) 
				{//RANGE 0 � diferente de 00?
          MCGOUTClock /= 32;                                                  /* If high range is enabled, additional 32 divider is active */
        }
      } 
			else 
			{//internal slow clock selecionado
        MCGOUTClock = CPU_INT_SLOW_CLK_HZ; /* The slow internal reference clock is selected */
      }
      /* Select correct multiplier to calculate the MCG output clock  */
      switch (HWREGC(MCG_ADD + MCG_C4) & (0x80 | 0x60)) {
        case 0x00:
          MCGOUTClock *= 640;
          break;
        case 0x20:
          MCGOUTClock *= 1280;
          break;
        case 0x40:
          MCGOUTClock *= 1920;
          break;
        case 0x60:
          MCGOUTClock *= 2560;
          break;
        case 0x80:
          MCGOUTClock *= 732;
          break;
        case 0xA0:
          MCGOUTClock *= 1464;
          break;
        case 0xC0:
          MCGOUTClock *= 2197;
          break;
        case 0xE0:
          MCGOUTClock *= 2929;
          break;
        default:
          break;
      }
    }
		else
		{ // PLL is selected
      Divider = (1 + (HWREGC(MCG_ADD + MCG_C5) & 0x1F));
      MCGOUTClock = (unsigned long)(CPU_XTAL_CLK_HZ / Divider);                     /* Calculate the PLL reference clock */
      Divider = ((HWREGC(MCG_ADD + MCG_C6) & 0x1F) + 24);
      MCGOUTClock *= Divider;                       /* Calcu/late the MCG output clock */
    } /* (!((MCG->C6 & MCG_C6_PLLS_MASK) == 0x0u)) */
  }
	else if ((HWREGC(MCG_ADD + MCG_C1) & 0xC0) == 0x40) 
	{//Encoding 1 - Internal reference clock is selected
		if ((HWREGC(MCG_ADD + MCG_C2) & 0x01) == 0x00) 
		{//slow internal reference
      MCGOUTClock = CPU_INT_SLOW_CLK_HZ; //Slow internal reference clock selected
    }
		else
		{ // (!((MCG->C2 & MCG_C2_IRCS_MASK) == 0x0u))
			MCGOUTClock = CPU_INT_FAST_CLK_HZ / (1 << ((HWREGC(MCG_ADD + MCG_SC) & 0x0E) >> 1));  /* Fast internal reference clock selected */
    }
  }
	else if ((HWREGC(MCG_ADD + MCG_C1) & 0xC0) == 0x80) 
	{ //Encoding 2 - External reference clock is selected
    MCGOUTClock = CPU_XTAL_CLK_HZ; /* System oscillator drives MCG clock */
  } 
	else
	{// Reserved value - nao sei qual � o clock
		
    return 8000000;//vou retornar alguma coisa 8MHz
  }
  Sysutils_SystemCoreClock = (MCGOUTClock / (1 + ((HWREGL(SIM_ADD + SIM_CLKDIV1) & 0xF0000000) >> (7*4))));
	return Sysutils_SystemCoreClock;
  
  #endif
  #warning Arrumar clock
	//Retornando valor default, j� que, por hora, iremos apenas utilizar clock interno
	return 8000000;//vou retornar alguma coisa 8MHz
}

/*
unsigned long SysUtils_ClockBus(void)
{//retorna o clock do bus, para dar certo, ao menos uma vez tem que ser chamado a fun��o SysUtils_ClockGet
		return   (Sysutils_SystemCoreClock / (1 + ((HWREGL(SIM_ADD + SIM_CLKDIV1) & 0x00070000) >> 16)));
}

unsigned long SysUtils_GetMCGFLLCLK(void)
{
	return (Sysutils_SystemCoreClock * (1 + ((HWREGL(SIM_ADD + SIM_CLKDIV1) & 0xF0000000) >> (7*4))));
}
*/
/*
unsigned char SysUtils_SPI0(unsigned char dado)
{//escreve um dado na SPI1 e retorna o que saiu da SPI1
	unsigned char aux;
	
	for(aux=0;aux<255;aux++)if((HWREGC(SPI0_ADD + SPI_S)&0x20)!=0)break;//fica em loop ateh o buffer de transmiss�o ficar vazio
	HWREGC(SPI0_ADD + SPI_D) = dado;//escrevo o dado no SPI
	for(aux=0;aux<255;aux++)if((HWREGC(SPI0_ADD + SPI_S)&0x80)!=0)break;//fica em loop ateh o buffer de recep��o receber o byte	
	return HWREGC(SPI0_ADD + SPI_D);
}*/

//unsigned char SysUtils_SPI1(unsigned char dado)
//{//escreve um dado na SPI1 e retorna o que saiu da SPI1
//	unsigned char aux;
//	
//	/*
//	for(aux=0;aux<255;aux++)if((HWREGC(SPI1_ADD + SPI_S)&0x20)!=0)break;//fica em loop ateh o buffer de transmiss�o ficar vazio
//	HWREGC(SPI1_ADD + SPI_DL) = dado;//escrevo o dado no SPI
//	for(aux=0;aux<255;aux++)if((HWREGC(SPI1_ADD + SPI_S)&0x80)!=0)break;//fica em loop ateh o buffer de recep��o receber o byte	
//	return HWREGC(SPI1_ADD + SPI_DL);
//	*/
//	
//	for(aux = 0; aux < 255; aux++) if(SPI1->SR & SPI_SR_TXE)break;//fica em loop ateh o buffer de transmiss�o ficar vazio
//	SPI1->DR = dado;//escrevo o dado no SPI
//	for(aux = 0; aux < 255; aux++) if(SPI1->SR & SPI_SR_RXNE)break;//fica em loop ateh o buffer de recep��o receber o byte	
//	return SPI1->DR;
//}
