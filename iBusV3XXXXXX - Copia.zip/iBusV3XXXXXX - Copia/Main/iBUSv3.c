#define iBUSv3_C

//Main
#include "iBUSv3.h" //definicoes a serem incluidas a todos os arquivos.
#include "SysUtils.h"

//iBUSv3/
#include "iBUSenlace.h"
#include "iBUSrede.h"
#include "iBUStransporte.h"
#include "iBUSAplicacao.h"
#include "iBUSManager.h"

//Radio/
#include "Radio.h"

//Sistema/
#include "dynmem.h"
#include "Rijndael.h"
#include "system.h"

//S2LP_Library/
//#include "S2LP_RegMap.h"
//#include "S2LP.h"
#include "S2LP_Commands.h"
#include "S2LP_Gpio.h"
#include "S2LP_PktBasic.h"
#include "S2LP_Qi.h"
#include "S2LP_Radio.h"
#include "S2LP_Timer.h"
#include "MCU_Interface.h"
#include "S2LP_SPI.h"

//STM32F0x0_Library/
#include "HAL_GPIO.h"
#include "HAL_SPI.h"

//Configuracao/
#include "configClock.h"
#include "configUart.h"
#include "configSPI.h"
#include "configADC.h"
#include "configGPIO.h"

//Hardware/
//#include "adc.h"
#include "Pir.h"

//Terminal/
#include "Terminal.h"
#include "uart2.h"

#define MASKFLAG3MS 		0x01
#define MASKFLAGA10MS 	0x02
#define MASKFLAGB10MS 	0x04
#define MASKFLAG33MS 		0x08
#define MASKFLAG100MS 	0x10
#define MASKFLAG05S 		0x20
#define MASKFLAG1S			0x40
#define MASKFLAG1MS 		0x80

//#define SOU_RECEPTOR

unsigned char loop_flag;
unsigned char loop_1min;

unsigned char flag25ms;

unsigned char menulido;	

unsigned char PROCESSADOR;

#ifdef USE_FAKE_NUMSERIE
	const unsigned char NUMSERIE[8] = {0x15, 0x43, 0x30, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
#endif

void iBUSv3_Init(void);
void watchdog_Init(void);

int main(void)
{
	watchdog_Init();//Iniciar o watchdog no fim do startup

	//Inicializa��o
	//Main
	clock_Init();		/*Habilita o Systick*/
	iBUSv3_Init();	//Configurar Timer principal (timer de controle do loop principal)
	
	//Configuracao
	spi_Init();
	uart_Init();
	gpio_Init();
	
	//Hardware - Antes do resto, pois inicializa o hardware para outras classes
	#ifndef IBUSV3_IVPDUPLO
	HAL_SPI_Init(SERIAL_FLASH);
	#endif
	
	//Radio/
	radio_Init();

	//UARTs -  Inicia aqui, pois tem que ser antes das classes que controlam
	uart2_Init();
	
	//Terminal
	terminal_Init();

	adc_PowerUp();

	pir_Init();
	
	//iBUSv3/
	iBUSenlace_Init();
	iBUSrede_Init();
	iBUStransporte_Init();
	iBUSAplicacao_Init();
	iBUSManager_Init();
	iBUSManager_Wakeup();//acorda a pilha iBUSv3




	while(1){		
		
		//Execu��o na m�xima velocidade poss�vel
		radio_Run();
		iBUStransporte_Loop();
		uart2_Main();

		if(loop_flag&MASKFLAG1MS)//B7, Execu��o a cada 1ms
		{
			loop_flag&=(~MASKFLAG1MS);//timetick atendido
			iBUSenlace_Main();//chamar peri�dicamente (a cada 1ms)
			iBUSrede_Main();//chamar peri�dicamente (a cada 1ms)
			iBUStransporte_Main();//chamar peri�dicamente (a cada 1ms)
			iBUSManager_Main();//chamar peri�dicamente (a cada 1ms)
			
			uart2_TxLoop();//para USB-SERIAL lentas
		}
		
		if(loop_flag&MASKFLAG3MS)//B0, Execu��o a cada 3ms
		{
			loop_flag&=(~MASKFLAG3MS);//timetick atendido
			adc_FastLoop();
		}

		if(loop_flag&MASKFLAGA10MS)//B1, Execu��o a cada 10ms
		{
			loop_flag&=(~MASKFLAGA10MS);//timetick atendido
			adc_Main();//salvando as leituras de adc
			pir_Main();
			terminal_Main();
			
		}

		if(loop_flag&MASKFLAGB10MS)//B2, Execu��o a cada 10ms (segundo flag)
		{
			loop_flag&=(~MASKFLAGB10MS);//timetick atendido
			terminal_Main();
			
			
		}

		if(loop_flag&MASKFLAG33MS)//B3, Execu��o a cada 33ms
		{
			loop_flag&=(~MASKFLAG33MS);//timetick atendido
			
		}

		if(loop_flag&MASKFLAG100MS)//B4, Execu��o a cada 100ms
		{
			loop_flag&=(~MASKFLAG100MS);//timetick atendido
		}

		if(loop_flag&MASKFLAG05S)//B5, Execu��o a cada 0,5s
		{
			loop_flag&=(~MASKFLAG05S);//timetick atendido	
			HAL_GPIO_WritePin(LED1, GPIOA, GPIO_PIN_SET); /*todos os existentes em High*/
			HAL_GPIO_WritePin(LED2, GPIOA, GPIO_PIN_RESET); /*todos os existentes em High*/
			if(flag_RadioEnviado == 0){ 
				flag_RadioEnviado = 1;//se eu enviei algo para o radio vou esperar acabar a oscilacao
			}	
		}

		if(loop_flag&MASKFLAG1S)//B6, Execu��o a cada 1s
		{
			loop_flag&=(~MASKFLAG1S);//timetick atendido
			HAL_GPIO_WritePin(LED1, GPIOA, GPIO_PIN_RESET); /*todos os existentes em High*/
			HAL_GPIO_WritePin(LED2, GPIOA, GPIO_PIN_SET); /*todos os existentes em High*/
			#ifdef DEBUGTERMINAL
			terminal_Printf_E(" 1S ");
			#endif
		}
	}
}

void iBUSv3_Init(void)
{
	loop_1min = 0;
	//flag25ms = 0;
	//Definir todo mundo com prioridade bem baixa, para depois setar quem precisa de prioridade maior.
	
	NVIC->IP[0] = 0xFFFFFFFF; // WWDG_IRQn, RESERVERD, RTC_IRQn, FLASH_IRQn
	NVIC->IP[1] = 0xFFFFFFFF; // RCC_IRQn, EXTI0_1_IRQn, EXTI2_3_IRQn, EXTI4_15_IRQn
	NVIC->IP[2] = 0xFFFFFFFF; // RESERVED, DMA1_Channel1_IRQn, DMA1_Channel2_3_IRQn, DMA1_Channel4_5_IRQn
	NVIC->IP[3] = 0xFFFFFFFF; // ADC1_IRQn, TIM1_BRK_UP_TRG_COM_IRQn, TIM1_CC_IRQn, RESERVED
	NVIC->IP[4] = 0xFFFFFFFF; // TIM3_IRQn, TIM6_IRQn,TIM7_IRQn, TIM14_IRQn
	NVIC->IP[5] = 0xFFFFFFFF; // TIM15_IRQn, TIM16_IRQn, TIM17_IRQn, I2C1_IRQn
	NVIC->IP[6] = 0xFFFFFFFF; // I2C2_IRQn, SPI1_IRQn, SPI2_IRQn, USART1_IRQn
	NVIC->IP[7] = 0xFFFFFFFF; // USART2_IRQn, USART3_4_IRQn, RESERVED, USB_IRQn
	
}

unsigned short int iBUSv3_index=0;//para gerar aleat�rio no DirectLink

void iBUSv3_SysTick(void)
{//Interru��o do System Timer Tick  //Interrompido periodicamente a cada 1ms
						
	if(SysTick->CTRL){}//le o registro para limpar COUNTFLAG {} para tirar warning
	
	loop_flag|=MASKFLAG1MS;//1ms
	if(((iBUSv3_index%3)==0)&&(iBUSv3_index!=999))loop_flag|=MASKFLAG3MS;//332 estouros de 3ms e 1 estouro de 4ms.
	if(( iBUSv3_index%10)==8)loop_flag|=MASKFLAGA10MS;//Se uma fun��o for chamada nos dois flags de 10ms ir� estourar em 4ms e 6ms
	if(( iBUSv3_index%10)==2)loop_flag|=MASKFLAGB10MS;
	if(((iBUSv3_index%100)==1)||((iBUSv3_index%100)==34)||((iBUSv3_index%100)==67))loop_flag|=MASKFLAG33MS;//33ms, 33ms, 34ms
	if(( iBUSv3_index%100)==4)loop_flag|=MASKFLAG100MS;
	if(( iBUSv3_index==5)||(iBUSv3_index==505))loop_flag|=MASKFLAG05S;
	if(  iBUSv3_index==7)loop_flag|=MASKFLAG1S;

	iBUSv3_index++;
	if(iBUSv3_index>=1000)
		iBUSv3_index=0;//1 segundo rodado
}

void watchdog_Init(void){
}

//inicializa��o do core
void SystemInit(void)
{
	/* Reset the RCC clock configuration to the default reset state ------------*/
  /* Set HSION bit */
  RCC->CR |= (uint32_t)0x00000001U;
	/* Reset SW[1:0], HPRE[3:0], PPRE[2:0], ADCPRE, MCOSEL[2:0], MCOPRE[2:0] and PLLNODIV bits */
	RCC->CFGR &= (uint32_t)0x08FFB80CU;
  
  /* Reset HSEON, CSSON and PLLON bits */
  RCC->CR &= (uint32_t)0xFEF6FFFFU;

  /* Reset HSEBYP bit */
  RCC->CR &= (uint32_t)0xFFFBFFFFU;

  /* Reset PLLSRC, PLLXTPRE and PLLMUL[3:0] bits */
  RCC->CFGR &= (uint32_t)0xFFC0FFFFU;

  /* Reset PREDIV[3:0] bits */
  RCC->CFGR2 &= (uint32_t)0xFFFFFFF0U;

	/* Reset USART1SW[1:0], I2C1SW, USBSW and ADCSW bits */
  RCC->CFGR3 &= (uint32_t)0xFFFFFE6CU;

  /* Reset HSI14 bit */
  RCC->CR2 &= (uint32_t)0xFFFFFFFEU;

  /* Disable all interrupts */
  RCC->CIR = 0x00000000U;	
}


void EXTI4_15_IRQHandler(){
	NVIC->ICPR[0U] |= (uint32_t)(1UL << (((uint32_t)(int32_t)EXTI4_15_IRQn) & 0x1FUL));
	EXTI->PR |= EXTI_PR_PR10;//*LE O FLAG PARA PARAR A INTERRUP��O*
	S2LP_CallExternInterrupt();
}
//
void USART2_IRQHandler(){
	NVIC->ICPR[0U] |= (uint32_t)(1UL << (((uint32_t)(int32_t)USART2_IRQn) & 0x1FUL));
	USART2->ICR |= USART_ICR_TCCF; /* Clear transfer complete flag */
	uart2_IRQHandler();
}
//
