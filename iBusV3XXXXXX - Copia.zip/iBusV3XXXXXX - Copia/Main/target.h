//#define iBUSv3_IVP

#define VERSAO_FW_BASE 0x0000
