#ifndef SYSUTILS_H
#define SYSUTILS_H

//*****************************************************************************
//
// Macros for hardware access, both direct and via the bit-band region.
//
//*****************************************************************************
//#define HWREGL(x)	((*(volatile unsigned long *)(x)))
//#define HWREGC(x)	((*(volatile unsigned char *)(x)))

#define CPU_INT_SLOW_CLK_HZ             32768   /* Value of the slow internal oscillator clock frequency in Hz  */
#define CPU_INT_FAST_CLK_HZ             4000000 /* Value of the fast internal oscillator clock frequency in Hz  */

#ifndef SYSUTILS_C

//extern void Sysutils_IntEnable(unsigned long ulInterrupt);
//extern void Sysutils_IntDisable(unsigned long ulInterrupt);
//extern void SysUtils_UartSpeed(unsigned long uart_base_add, unsigned long speed);

//String functions
//extern unsigned int SysUtils_StrCopy(const unsigned char *cStrOrigem,unsigned char *cStrDestino);
//extern unsigned int SysUtils_StrLen(const char *str1);
//extern unsigned char SysUtils_IntToStr(unsigned int num, unsigned char *str);//preenche str com a representacao decimal da string e retorna qts caracteres usou
//extern void SysUtils_IntToHex(unsigned char num, unsigned char *str);//preenche str com 2 d�gitos de representacao hexa da string
//extern unsigned short int SysUtils_StrToByteArray(char *texto, unsigned char *array);
//extern unsigned char *SysUtils_strstr(unsigned char *str1,const unsigned char *str2);//faz o que a funcao ansi c strstr faz
//extern unsigned char SysUtils_strncmp(const unsigned char *str1,const unsigned char *str2, unsigned char num);//faz o que a funcao ansi c strncmp faz
//extern unsigned char SysUtils_strcmp(const char * str1, const char * str2);//faz o que a fun��o ansi strcmp faz
//extern char * SysUtils_strchr(const char * str, char character);//faz o que a funcao ansi strchr faz
//extern unsigned char SysUtils_memcmp(const unsigned char * ptr1, const unsigned char * ptr2, unsigned int num);//faz o que a fun��o ansi memcmp faz


//extern void SysUtils_DisableInterrupts(void);
//extern void SysUtils_EnableInterrupts(void);

extern unsigned long SysUtils_ClockGet(void);//calcula e salva o clock setado nos registros
//extern unsigned long Sysutils_SystemCoreClock;
extern unsigned long SysUtils_ClockBus(void);//retorna o clock do bus (deve chamar pelo menos uma vez clockget antes)
extern unsigned long SysUtils_GetMCGFLLCLK(void);

//extern unsigned char SysUtils_SPI1(unsigned char dado);//escreve um valor na SPI e retorna o valor lido

#endif

#endif 
