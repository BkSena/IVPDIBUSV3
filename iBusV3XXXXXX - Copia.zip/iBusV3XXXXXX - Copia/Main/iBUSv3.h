#ifndef iBUSv3_H
#define iBUSv3_H

#include "regmap.h"
#include "HAL_GPIO.h"
#include "../Main/target.h"
#include <stdint.h>

#include "../Configuracao/configGpio.h"

//ATENCAO INCLUIR NO SCATTER:
//--cpu -CortexM0+

#define DEBUGAR //descomentar esse define se em produ��o
#define DEBUGTERMINAL //descomentar esse define se em produ��o

/***************************************************************/
/*** ESCOLHA DO TARGET - somente uma op��o deve ser definida ***/
/***************************************************************/
//          Preencher o nome no arquivo TARGET.H
//#define iBUSv3_IVP
//#define iBUSv3_CR
//#define iBUSv3_MAG
//#define iBUSv3_REP
//#define iBUSv3_REC

//#define IBUSV3_RECEPTOR
#define IBUSV3_IVPDUPLO
//#define IBUSV3_MAGNETICO
//#define IBUSV3_REPETIDOR
/***************************************************************/
/***************************************************************/

//#define DEBUGPLACA 

//defini��es comuns a todos os modelos:
//#define VERSAO_FW_BASE 0x0112 - vers�o fw base definida em CreateAllTargets.bat (salva em target.h)
#define VERSAO_HW_BASE 0x0100
#define NULL 0x00

/****** OPCOES DE CLOCK ********/
/*******************************/

#define CPU_XTAL_CLK_HZ 8000000


#if defined(iBUSv3_IVP)
	
	#define MODELO_EQTO 0x1001
	
	//recursos
	#define QTDE_PGM	0
	#define QTDE_SENHA	0
	#define QTDE_SETOR	0
	
	#define VERSAO_FW	VERSAO_FW_BASE //ir� substituir a linha VW16Z, que est� na V3.33, decidido iniciar essa vers�o a partir da V5.00
	#define VERSAO_HW	VERSAO_HW_BASE //como � hardware novo, ent�o come�a do 1.
	
#elif defined(iBUSv3_CR)
	#define MODELO_EQTO 0x1001
	
	//recursos
	#define QTDE_PGM	0
	#define QTDE_SENHA	0
	#define QTDE_SETOR	0
	
	#define VERSAO_FW	VERSAO_FW_BASE //ir� substituir a linha VW16Z, que est� na V3.33, decidido iniciar essa vers�o a partir da V5.00
	#define VERSAO_HW	VERSAO_HW_BASE //como � hardware novo, ent�o come�a do 1.

#elif defined(iBUSv3_MAG)
	#define MODELO_EQTO 0x1001
	
	//recursos
	#define QTDE_PGM	0
	#define QTDE_SENHA	0
	#define QTDE_SETOR	0
	
	#define VERSAO_FW	VERSAO_FW_BASE //ir� substituir a linha VW16Z, que est� na V3.33, decidido iniciar essa vers�o a partir da V5.00
	#define VERSAO_HW	VERSAO_HW_BASE //como � hardware novo, ent�o come�a do 1.

#elif defined(iBUSv3_REP)
	#define MODELO_EQTO 0x1001
	
	//recursos
	#define QTDE_PGM	0
	#define QTDE_SENHA	0
	#define QTDE_SETOR	0
	
	#define VERSAO_FW	VERSAO_FW_BASE //ir� substituir a linha VW16Z, que est� na V3.33, decidido iniciar essa vers�o a partir da V5.00
	#define VERSAO_HW	VERSAO_HW_BASE //como � hardware novo, ent�o come�a do 1.

#elif defined(iBUSv3_REC)
	#define MODELO_EQTO 0x1001
	
	//recursos
	#define QTDE_PGM	0
	#define QTDE_SENHA	0
	#define QTDE_SETOR	0
	
	#define VERSAO_FW	VERSAO_FW_BASE //ir� substituir a linha VW16Z, que est� na V3.33, decidido iniciar essa vers�o a partir da V5.00
	#define VERSAO_HW	VERSAO_HW_BASE //como � hardware novo, ent�o come�a do 1.

#elif defined(IBUSV3_RECEPTOR)
	#define SOU_RECEPTOR
	#define MODELO_EQTO 0x3001
#elif defined(IBUSV3_IVPDUPLO)
	#define MODELO_EQTO 0x3004
#elif defined(IBUSV3_MAGNETICO)
	#define MODELO_EQTO 0x3005
#elif defined(IBUSV3_REPETIDOR)
	#define SOU_REPETIDOR //definir para que tenha comportamento de repetidor na camada de rede
	#define MODELO_EQTO 0x3002
#else
	#define MODELO_EQTO 0x0000 //desconhecido
#endif


#ifndef SCATTER //utilizado para definir o mapeamento de memoria no arquivo scatter

	#ifdef DEBUGAR
		#define DEBUG_RODRIGO	//debugs usados durante o desenvolvimento
		
		#define USE_FAKE_NUMSERIE
		
		//#define USE_SWD_DEBUG //retira o controle dos leds 1 e 2 para permitir debugar com o JTAG. Led1 e 2 n�o funcionam.
		
		//#define KITDEV //altera os registradores para usar no KIT desenvolvimento
		
	//	#define SOU_SNIFFER	//definir para imprimir via serial os pacotes recebidos
		
		#ifdef SOU_SNIFFER
		#include <stdio.h>
		#endif
		
		//#define DEBUG_DESENVOLVIMENTO //Comentar na vers�o comercial, serve para altera��es ou pendencias de desenvolvimento n�o serem esquecidas!!!!
		#define DEBUG_ECO_SERIAL //descomentar para as respostas do modulo ecoarem na serial
		//#define DEBUG_FLASH
		//#define DEBUG_ECOFLASH
	#endif //#ifdef DEBUGAR


	//Definicoe processador
	#ifndef USE_FAKE_NUMSERIE
		#define NUMSERIE (0x40000 - 8)	//por enquanto usar esses at� ter o processador certo
	#else
		extern const unsigned char NUMSERIE[8];
	#endif
	
	#define DATAFABR (0x40000 -12)	//DEBUG
	
	#ifndef iBUSv3_C
		extern unsigned short int iBUSv3_index;//para gerar aleat�rio
	#endif
		
#endif //#ifndef SCATTER //utilizado para definir o mapeamento de memoria no arquivo scatter

#endif //#ifndef iBUSv3_H
