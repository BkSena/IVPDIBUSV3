#ifndef TERMINAL_H
#define TERMINAL_H


#define TERMINAL_END       1
#define TERMINAL_ERRO      2
#define TERMINAL_ESPERA    3
#define TERMINAL_CONTINUA  4

extern void terminal_Controle(unsigned char evento);//informa terminal que comunica��o encerrou; informa se fim (1) ou erro(0)
extern unsigned char terminal_Transmite(unsigned char aux);//transmite dados via terminal
extern void Terminal_Rx(unsigned char dado);//recebe os dados da serial

extern void terminal_Init(void);//inicializacao do terminal
extern void terminal_Main(void);//controla o terminal na interface serial 5ms

extern void terminal_Printf_E(const unsigned char *mensagem);
extern unsigned char terminal_Tx(unsigned char dado);
extern void DebugHex_E(unsigned char c);
extern void DebugDec_E(unsigned int  c);


#endif
