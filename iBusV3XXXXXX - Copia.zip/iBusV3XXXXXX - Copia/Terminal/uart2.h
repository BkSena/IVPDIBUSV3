#ifndef UART2_H
#define UART2_H

#include "iBUsv3.h"

#include "Terminal/Terminal.h"				//incluir a classe q usa a UART1



#define UART2_BUFFERLEN	254					//definir o tamanho desejado para os buffers de tx e rx

#define UART2_BAUDRATE 115200				//definir aqui a velocidade de quem for usar a UART1


#define uart2_Rx(dado) Terminal_Rx(dado)	//definir aqui qual fun��o da classe respons�vel por tratar bytes recebidos pela UART1



extern void uart2_Init(void);//power up
extern void uart2_Main(void);//chamar em tempo de loop para tratar RX

extern void uart2_Open(void);//Configura a porta serial e ajusta todos os pinos para suas fun��es
extern void uart2_Close(void);//Desabilita serial e coloca todos os IOs em tristate	(RX, TX, CTS e RTS)
extern unsigned char uart2_Tx(unsigned char dado);//enviar via serial, retorna dif. de zero se OK, zero se buffer full
extern unsigned char uart2_BufEmpty(void);//retorna dif. de zero se buffer vazio

extern void uart2_TxLoop(void);//a cada 1ms para ser lento e ficar compativel com USB-Seriais lentas.

extern void uart2_IRQHandler(void);


#endif
