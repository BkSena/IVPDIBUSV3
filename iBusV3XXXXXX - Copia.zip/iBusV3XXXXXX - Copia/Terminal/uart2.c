#define UART2_C

#include "iBUsv3.h"
#include "uart2.h"

#define UART2_BUFFERRX	UART2_BUFFERLEN
#define UART2_BUFFERTX	UART2_BUFFERLEN

void uart2_Close(void);

unsigned char uart2_rxin, uart2_rxout, uart2_txin, uart2_txout;//ponteiros do buffer interno
unsigned char uart2_bufRx[UART2_BUFFERRX];
unsigned char uart2_bufTx[UART2_BUFFERTX];

unsigned char uart2_Tx(unsigned char dado);

void uart2_Init(void)
{//power up
	unsigned short int br;
	unsigned long pri;
	
	//No power up, a serial sai no modo fechado, todos os pinos em tristate
	//uart2_Close();
	
	
	//Inicializa��es do software
	uart2_rxin=0;//ponteiro de entrada do buffer de rx
  uart2_rxout=0;//ponteiro de saida do buffer de rx
  uart2_txin=0;
	uart2_txout=0;
	
	
	USART2->CR1 &= ~(USART_CR1_TXEIE); //desabilita interrup��o por tx
	
}



void uart2_Main(void)
{//chamar em tempo de loop para tratar RX
	if(uart2_rxin>=UART2_BUFFERRX)uart2_rxin=0;//protecao contra dados inconsistentes.
	
	while(uart2_rxin!=uart2_rxout)
	{
		uart2_Tx(uart2_bufRx[uart2_rxout]);
		uart2_Rx(uart2_bufRx[uart2_rxout]);
		uart2_rxout++;
		if(uart2_rxout>=UART2_BUFFERRX)uart2_rxout=0;
	}
	
	if(uart2_txin!=uart2_txout){//tem caracter para enviar
			USART2->CR1 |= (USART_CR1_TXEIE); //habilita interrup��o por tx
	}

	
}

void uart2_TxLoop(void)
{
		if(uart2_txin!=uart2_txout)//tem caracter para enviar
		{
			if((USART2->ISR & USART_ISR_TC) == USART_ISR_TC)
			{//buffer de tx vazio?
				USART2->TDR = uart2_bufTx[uart2_txout];//coloca no buffer da uart o dado.
				uart2_txout++;
				if(uart2_txout>=UART2_BUFFERTX)uart2_txout=0;			
			}
		}
}

void uart2_Open(void)
{//Configura a porta serial e ajusta todos os pinos para suas fun��es

	//Inicializa��es do software
	uart2_rxin=0;//ponteiro de entrada do buffer de rx
	uart2_rxout=0;//ponteiro de saida do buffer de rx
	uart2_txin=0;
	uart2_txout=0;
	
	USART2->CR1 &= ~(USART_CR1_TXEIE); //desabilita interrup��o por tx
	
}
//

unsigned char uart2_Tx(unsigned char dado)
{//enviar via serial, retorna dif. de zero se OK, zero se buffer full
	
	unsigned char buf_len;
	
	//Calcula o tamanho do buffer
	if(uart2_txout>uart2_txin)buf_len = uart2_txout-uart2_txin-1;
	else buf_len = UART2_BUFFERTX - 1 - uart2_txin + uart2_txout;
	
	if(buf_len>0){//s� grava se h� espa�o
		//coloca no buffer
		uart2_bufTx[uart2_txin]=dado;
		uart2_txin++;
		if(uart2_txin>=UART2_BUFFERTX)uart2_txin=0;
	
		
		USART2->CR1 |= (USART_CR1_TXEIE); //habilita interrup��o por tx
	
		return 1;
	}
	
	return 0;
}
//
void uart2_IRQHandler(void)
{//Tratamento da interrup��o serial
	unsigned char BufRxLen;
	
	unsigned char status1;
	
	
	status1 = USART2->ISR;//carrega o flag de interrup��o

	if((status1 & USART_ISR_RXNE)!=0x00){//Rx interrupt, RXNE = 1
		
		//Calcula o tamanho do buffer
		if(uart2_rxout>uart2_rxin)BufRxLen = uart2_rxout-uart2_rxin;
		else BufRxLen = UART2_BUFFERRX - 1 - uart2_rxin + uart2_rxout;
	
		if(BufRxLen>0){//tem espaco no buffer? Pelo menos para mais um?
			uart2_bufRx[uart2_rxin]=USART2->RDR;//l� o dado
			
			uart2_rxin++;
			if(uart2_rxin>=UART2_BUFFERRX)uart2_rxin=0;

			//#ifdef UART2_CTS_PIN //Tem pino de CTS essa serial
			//if(BufRxLen>(UART2_BUFFERRX/10))HWREGL(FGPIO_A_ADD + (UART2_CTS_PORT * 0x40) + GPIO_PCOR) = ((unsigned long)0x01)<<UART2_CTS_PIN;//zera CTS//tem espa�o no buffer posso receber mais bytes
			//else HWREGL(FGPIO_A_ADD + (UART2_CTS_PORT * 0x40) + GPIO_PSOR) = ((unsigned long)0x01)<<UART2_CTS_PIN;//seta CTS//n�o recebo mais bytes (meu buffer s� tem 10% do buffer livre)
			//#endif
		}
	}
	
	if((status1 & USART_ISR_TXE)!=0x00){//Tx interrupt, TXE =1   envia byte do buffer
	//if((USART2->ISR & USART_ISR_TC) == USART_ISR_TC){
		USART2->CR1 &= ~(USART_CR1_TXEIE); //desabilita interrup��o por tx
	
		if(uart2_txin!=uart2_txout){//tem caracter para enviar
			USART2->TDR = uart2_bufTx[uart2_txout];//coloca no buffer da uart o dado.
			
			uart2_txout++;
			if(uart2_txout>=UART2_BUFFERTX)uart2_txout=0;
		}
		else
		{
			USART2->CR1 &= ~(USART_CR1_TXEIE); //desabilita interrup��o por tx
		}
	}
	else
	{
		USART2->CR1 &= ~(USART_CR1_TXEIE); //desabilita interrup��o por tx
	}
}

//

unsigned char uart2_BufEmpty(void)
{//retorna dif. de zero se buffer vazio
	return (uart2_txin == uart2_txout);
}
