#define PRINTUART_C

#include "iBUsv3.h"
#include "Terminal/Terminal.h"
#include "uart2.h"


#define TERMINAL_TIMEOUT 7000                   //timeout do terminal (x 10ms) > 70 segundos
#define TERMINAL_RTSMAX 200						//timeout do terminal com RTS ativo.

unsigned char cmd_index;
unsigned short int terminal_Timeout;

const unsigned char resp_ok[]="OK\r";
const unsigned char resperr[]="ERROR\r";
const unsigned char respend[]="END\r";

unsigned char terminal_Conectado;
unsigned char terminal_Falha;

/*-----------------------------------------------------------------------------
Prototipo de fun��es
-----------------------------------------------------------------------------*/

void terminal_Init(void);//inicia a sessao do terminal
void terminal_Main(void);//controla o terminal na interface serial
void terminal_Printf_E(const unsigned char *mensagem);
void terminal_Comando(unsigned char aux);
//unsigned char terminal_Tx(unsigned char dado);
void DebugHex_E(unsigned char c);
void terminal_Reset(void);//envia info via terminal

#define incr_ptr(a,b) {a++;if(a>=b){a=0;}}

/*-----------------------------------------------------------------------------
Fun��es publicas
-----------------------------------------------------------------------------*/
void terminal_Init(void){//inicia a sessao do terminal
	
	cmd_index=0;
	terminal_Conectado=0;
	terminal_Timeout=0;
	terminal_Falha=0;
	
	//configura os pinos para operar dentro da UART	
	uart2_Open();//come�a a operar


}
//
void terminal_Main(void){//controla a leitura de dados da serial e escrita no terminal

	if(terminal_Timeout){//se tem processo em andamento
		terminal_Timeout++;//incrementa timeout	
	}
	
	if(terminal_Timeout == TERMINAL_TIMEOUT) /*(terminal_Timeout>TERMINAL_RTSMAX)||*/
	{
		terminal_Falha=1;	
	}
	
	if(terminal_Falha){//falha: encerra comunica��o, retorna informa��o de erro
		//if(terminal_Conectado)download_StartDownload(DOWNLOAD_FIM);		
		terminal_Reset();
	}
	

}
//

void Terminal_Rx(unsigned char dado)
{//sem falha, trata caracter
	unsigned short int info;
}



//
void terminal_Reset(void){//envia info via terminal
	cmd_index=0;
	terminal_Conectado=0;
	terminal_Timeout=0;
	terminal_Falha=0;
}
//


unsigned char terminal_Tx(unsigned char dado){//grava byte no buffer de opera��es
	//#ifdef DEBUG_BYPASS_TERMINAL_MODULO
	//return 0;
	//#else
	terminal_Timeout=1;//evita erro por timeout
	return uart2_Tx(dado);
	//#endif
}
//

unsigned char terminal_Transmite(unsigned char aux){//envia info via terminal
	terminal_Timeout=1;//evita erro por timeout
	return terminal_Tx(aux);
}


void terminal_Printf_E(const unsigned char *mensagem){//envia via serial uma mensagem
	unsigned short int aux=0;
	unsigned int i = 0;

	while((mensagem[aux]!='\0')){
		//if((USART1->ISR & USART_ISR_TC) == USART_ISR_TC)
		//{
		/* clear transfer complete flag and fill TDR with a new char */
			//for(i=0; i<0x3F; i++){}
		
		terminal_Tx(mensagem[aux]);
		aux++;
	//	}
	}
	USART2->ICR |= USART_ICR_TCCF; /* Clear transfer complete flag */
	//USART1->CR1 &= ~USART_ISR_TXE; /*Desabilita interrup��o usart1*/
}
//

void DebugHex_E(unsigned char c){
	
	unsigned char buf[2];
	
		if(c>=0xA0){
			buf[0] = (('A'-10+(c>>4)));
		}
		else{
			buf[0] =(('0'+(c>>4)));
		}
	
		if((c&0x0F)>=0x0A){
			buf[1] =(('A'-10+(c&0x0F)));
		}
		else{
			buf[1] =(('0'+(c&0x0F)));
		}
	terminal_Printf_E(buf);
}
//

void DebugDec_E(unsigned int c){
	
	unsigned char tam;
	unsigned char buf[1];

	if(c > 9999)tam = 5;
	else if (c > 999) tam = 4;
	else if (c > 99) tam = 3;
	else if (c > 9) tam = 2;
	else tam = 1;	

	switch (tam){
		case 5:
			buf[0] = ('0'+(c/10000));
			terminal_Printf_E(buf);
		case 4:
			buf[0] = ('0'+((c%10000)/1000)); 
			terminal_Printf_E(buf);
		case 3:
			buf[0] = ('0'+((c%1000)/100));
			terminal_Printf_E(buf);
		case 2:
			buf[0] = ('0'+((c%100)/10)); 
			terminal_Printf_E(buf);
		case 1:
			buf[0] = ('0'+(c%10));
			terminal_Printf_E(buf);
			break;
		}
}
//
